package com.example.fintracker

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.fintracker.ui.BudgetsFragment
import com.example.fintracker.ui.ReportsFragment
import com.example.fintracker.ui.TransactionsFragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    private val permLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            (supportFragmentManager.findFragmentById(R.id.fragmentContainer) as? TransactionsFragment)?.scanSms()
        } else {
            Toast.makeText(this, "SMS permission needed to auto-import", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, TransactionsFragment()).commit()
        }

        findViewById<BottomNavigationView>(R.id.bottomNav).setOnItemSelectedListener { item ->
            val f = when (item.itemId) {
                R.id.nav_transactions -> TransactionsFragment()
                R.id.nav_reports     -> ReportsFragment()
                R.id.nav_budgets     -> BudgetsFragment()
                else                 -> TransactionsFragment()
            }
            supportFragmentManager.beginTransaction().replace(R.id.fragmentContainer, f).commit()
            true
        }

        if (!hasSmsPermission()) permLauncher.launch(Manifest.permission.READ_SMS)
    }

    fun hasSmsPermission() = ContextCompat.checkSelfPermission(
        this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED
    fun requestSms() = permLauncher.launch(Manifest.permission.READ_SMS)
}
