package com.example.fintracker

import android.Manifest
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.fintracker.data.FinanceRepository
import com.example.fintracker.server.FinanceWebServer
import com.example.fintracker.ui.BudgetsFragment
import com.example.fintracker.ui.LearningFragment
import com.example.fintracker.ui.ReportsFragment
import com.example.fintracker.ui.TransactionsFragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : AppCompatActivity() {

    private var webServer: FinanceWebServer? = null
    private val PORT = 8080

    private val permLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            (supportFragmentManager.findFragmentById(R.id.fragmentContainer) as? TransactionsFragment)?.scanSms()
        } else {
            Toast.makeText(this, "SMS permission needed to auto-import", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, TransactionsFragment()).commit()
        }

        findViewById<BottomNavigationView>(R.id.bottomNav).setOnItemSelectedListener { item ->
            val f = when (item.itemId) {
                R.id.nav_transactions -> TransactionsFragment()
                R.id.nav_reports     -> ReportsFragment()
                R.id.nav_budgets     -> BudgetsFragment()
                R.id.nav_learning    -> LearningFragment()
                else                 -> TransactionsFragment()
            }
            supportFragmentManager.beginTransaction().replace(R.id.fragmentContainer, f).commit()
            true
        }

        if (!hasSmsPermission()) permLauncher.launch(Manifest.permission.READ_SMS)
        startWebServer()
    }

    private fun startWebServer() {
        try {
            val repo = FinanceRepository(this)
            webServer = FinanceWebServer(repo, this, PORT)
            webServer?.start()
            val ip = getLocalIpAddress()
            val toolbar = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.toolbar)
            toolbar?.subtitle = if (ip != null) "Web: http://$ip:$PORT" else "Web server on port $PORT"
            Toast.makeText(this, "📡 Dashboard: http://${ip ?: "device-ip"}:$PORT", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Web server error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun getLocalIpAddress(): String? {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                val addrs = iface.inetAddresses
                while (addrs.hasMoreElements()) {
                    val addr = addrs.nextElement()
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        return addr.hostAddress
                    }
                }
            }
        } catch (e: Exception) { }
        return null
    }

    override fun onDestroy() {
        super.onDestroy()
        webServer?.stop()
    }

    fun hasSmsPermission() = ContextCompat.checkSelfPermission(
        this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED
    fun requestSms() = permLauncher.launch(Manifest.permission.READ_SMS)
}
