package com.example.fintracker
import android.graphics.Color
import android.view.*
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.fintracker.data.TransactionEntity
import java.text.SimpleDateFormat
import java.util.*

class TransactionAdapter(
    val items: MutableList<TransactionEntity>,
    private val splitIds: Set<Long> = emptySet(),
    private val onCategoryClick: (TransactionEntity) -> Unit,
    private val onLongPress: (TransactionEntity, Int) -> Unit
) : RecyclerView.Adapter<TransactionAdapter.VH>() {
    private val fmt = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: TextView = v.findViewById(R.id.tvTypeIcon)
        val sender: TextView = v.findViewById(R.id.tvSender)
        val date: TextView = v.findViewById(R.id.tvDate)
        val amount: TextView = v.findViewById(R.id.tvAmount)
        val category: TextView = v.findViewById(R.id.tvCategory)
        val splitBadge: TextView = v.findViewById(R.id.tvSplitBadge)
        val balance: TextView = v.findViewById(R.id.tvBalance)
        val message: TextView = v.findViewById(R.id.tvMessage)
    }
    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_transaction, p, false))
    override fun onBindViewHolder(h: VH, pos: Int) {
        val t = items[pos]
        when (t.type) {
            "DEBIT" -> { h.icon.text="↑"; h.icon.setBackgroundResource(R.drawable.circle_bg_red)
                h.amount.text="- ₹${"%,.2f".format(t.amount)}"; h.amount.setTextColor(Color.parseColor("#D32F2F")) }
            "CREDIT" -> { h.icon.text="↓"; h.icon.setBackgroundResource(R.drawable.circle_bg_green)
                h.amount.text="+ ₹${"%,.2f".format(t.amount)}"; h.amount.setTextColor(Color.parseColor("#2E7D32")) }
            else -> { h.icon.text="•"; h.icon.setBackgroundResource(R.drawable.circle_bg)
                h.amount.text="₹${"%,.2f".format(t.amount)}"; h.amount.setTextColor(Color.parseColor("#757575")) }
        }
        h.sender.text = when {
            t.source == "MANUAL" -> "✏️ Manual"
            t.payee.isNotEmpty() -> "${t.payee.replaceFirstChar { it.uppercase() }}  •  ${t.sender}"
            else -> t.sender
        }
        h.date.text = fmt.format(Date(t.date))
        h.category.text = t.category
        h.balance.text = t.balance?.let { "Bal: ₹${"%,.0f".format(it)}" } ?: ""
        // Show flag + message
        h.message.text = if (t.flag.isNotEmpty()) "[${t.flag}]  ${t.rawMessage}" else t.rawMessage
        when {
            t.subCategory.isNotEmpty() -> { h.splitBadge.text = "21b3 ${t.subCategory}"; h.splitBadge.visibility = View.VISIBLE; h.splitBadge.setBackgroundResource(R.drawable.chip_bg); h.splitBadge.setTextColor(android.graphics.Color.parseColor("#1565C0")) }
            t.id in splitIds -> { h.splitBadge.text = "2702Fe0f Split"; h.splitBadge.visibility = View.VISIBLE; h.splitBadge.setBackgroundResource(R.drawable.chip_bg_orange); h.splitBadge.setTextColor(android.graphics.Color.parseColor("#E65100")) }
            else -> h.splitBadge.visibility = View.GONE
        }
        h.category.setOnClickListener { onCategoryClick(t) }
        h.itemView.setOnLongClickListener { onLongPress(t, pos); true }
    }
    override fun getItemCount() = items.size
    fun removeAt(pos: Int) { items.removeAt(pos); notifyItemRemoved(pos) }
}
