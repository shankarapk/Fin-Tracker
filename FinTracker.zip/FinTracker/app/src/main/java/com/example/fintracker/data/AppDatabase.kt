package com.example.fintracker.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.*

@Database(entities = [TransactionEntity::class, CategoryEntity::class, BudgetEntity::class, SplitEntity::class],
    version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun transactionDao(): TransactionDao
    abstract fun categoryDao(): CategoryDao
    abstract fun budgetDao(): BudgetDao
    abstract fun splitDao(): SplitDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        val DEFAULT_CATEGORIES = listOf(
            CategoryEntity("Food & Dining", "swiggy,zomato,restaurant,cafe,food,dine,eatery,bakery,hotel,dominos,pizza,burger,kfc,mcdonalds", "#FF7043", "🍔"),
            CategoryEntity("Shopping", "amazon,flipkart,myntra,mall,store,retail,shop,meesho,ajio,nykaa", "#AB47BC", "🛍️"),
            CategoryEntity("Bills & Utilities", "electricity,recharge,broadband,dth,gas,water bill,bill payment,postpaid,bsnl,airtel,jio,vodafone,vi,bescom,msedcl", "#5C6BC0", "💡"),
            CategoryEntity("Transport", "uber,ola,fuel,petrol,diesel,metro,irctc,fastag,parking,rapido,bus,auto,cab", "#26A69A", "🚗"),
            CategoryEntity("Entertainment", "netflix,prime,hotstar,spotify,movie,bookmyshow,cinema,youtube,gaming", "#EC407A", "🎬"),
            CategoryEntity("Health", "pharmacy,hospital,clinic,medical,doctor,apollo,medplus,chemist,lab,diagnostics", "#66BB6A", "💊"),
            CategoryEntity("Transfer", "upi,neft,imps,rtgs,transfer,sent to,p2p,phonepay,gpay,paytm", "#42A5F5", "💸"),
            CategoryEntity("Salary & Income", "salary,credited interest,refund,cashback,reversal,bonus,stipend", "#4CAF50", "💰"),
            CategoryEntity("Groceries", "bigbasket,blinkit,grofers,dmart,reliance fresh,more,grocery,supermarket,vegetables,fruits", "#FF9800", "🥬"),
            CategoryEntity("Others", "", "#9E9E9E", "📦")
        )

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
                    override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                        db.execSQL("""CREATE TABLE IF NOT EXISTS splits (
                            id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                            transactionId INTEGER NOT NULL,
                            category TEXT NOT NULL,
                            amount REAL NOT NULL,
                            note TEXT NOT NULL DEFAULT '',
                            FOREIGN KEY(transactionId) REFERENCES transactions(id) ON DELETE CASCADE)""")
                        db.execSQL("CREATE INDEX IF NOT EXISTS index_splits_transactionId ON splits(transactionId)")
                    }
                }
                val instance = Room.databaseBuilder(
                    context.applicationContext, AppDatabase::class.java, "fintracker.db"
                ).addMigrations(MIGRATION_1_2).build()
                INSTANCE = instance
                CoroutineScope(Dispatchers.IO).launch {
                    if (instance.categoryDao().getAll().isEmpty())
                        instance.categoryDao().insertAll(DEFAULT_CATEGORIES)
                }
                instance
            }
        }
    }
}
