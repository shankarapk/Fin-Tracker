package com.example.fintracker.data

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.*

@Database(
    entities = [TransactionEntity::class, CategoryEntity::class, BudgetEntity::class,
                SplitEntity::class, SenderCategoryMap::class, DeletedSmsKey::class,
                SubCategoryEntity::class],
    version = 7, exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun transactionDao(): TransactionDao
    abstract fun categoryDao(): CategoryDao
    abstract fun budgetDao(): BudgetDao
    abstract fun splitDao(): SplitDao
    abstract fun senderCategoryDao(): SenderCategoryDao
    abstract fun deletedSmsKeyDao(): DeletedSmsKeyDao
    abstract fun subCategoryDao(): SubCategoryDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        val DEFAULT_CATEGORIES = listOf(
            CategoryEntity("Food & Dining", "swiggy,zomato,restaurant,cafe,food,dine,eatery,bakery,hotel,dominos,pizza,burger,kfc,mcdonalds", "#FF7043", "🍔"),
            CategoryEntity("Shopping", "amazon,flipkart,myntra,mall,store,retail,shop,meesho,ajio,nykaa", "#AB47BC", "🛍️"),
            CategoryEntity("Bills & Utilities", "electricity,recharge,broadband,dth,gas,water bill,bill payment,postpaid,bsnl,airtel,jio,vodafone,bescom,msedcl", "#5C6BC0", "💡"),
            CategoryEntity("Transport", "uber,ola,fuel,petrol,diesel,metro,irctc,fastag,parking,rapido,bus,auto,cab", "#26A69A", "🚗"),
            CategoryEntity("Entertainment", "netflix,prime,hotstar,spotify,movie,bookmyshow,cinema,youtube,gaming", "#EC407A", "🎬"),
            CategoryEntity("Health", "pharmacy,hospital,clinic,medical,doctor,apollo,medplus,chemist,lab,diagnostics", "#66BB6A", "💊"),
            CategoryEntity("Transfer", "upi,neft,imps,rtgs,transfer,sent to,p2p,phonepay,gpay,paytm", "#42A5F5", "💸"),
            CategoryEntity("Salary & Income", "salary,credited interest,refund,cashback,reversal,bonus,stipend", "#4CAF50", "💰"),
            CategoryEntity("Groceries", "bigbasket,blinkit,grofers,dmart,reliance fresh,more,grocery,supermarket,vegetables,fruits", "#FF9800", "🥬"),
            CategoryEntity("Others", "", "#9E9E9E", "📦")
        )

        val DEFAULT_SUB_CATEGORIES = listOf(
            // Food & Dining
            SubCategoryEntity(name="Swiggy",       parentCategory="Food & Dining", keywords="swiggy",                emoji="🛵"),
            SubCategoryEntity(name="Zomato",       parentCategory="Food & Dining", keywords="zomato",                emoji="🔴"),
            SubCategoryEntity(name="Restaurant",   parentCategory="Food & Dining", keywords="restaurant,hotel,dine", emoji="🍽️"),
            SubCategoryEntity(name="Bakery/Cafe",  parentCategory="Food & Dining", keywords="cafe,bakery,coffee",    emoji="☕"),
            SubCategoryEntity(name="Fast Food",    parentCategory="Food & Dining", keywords="kfc,mcdonalds,burger,pizza,dominos", emoji="🍔"),
            // Shopping
            SubCategoryEntity(name="Amazon",       parentCategory="Shopping", keywords="amazon",          emoji="📦"),
            SubCategoryEntity(name="Flipkart",     parentCategory="Shopping", keywords="flipkart",        emoji="🛒"),
            SubCategoryEntity(name="Clothing",     parentCategory="Shopping", keywords="myntra,ajio,nykaa,clothing,fashion", emoji="👗"),
            SubCategoryEntity(name="Electronics",  parentCategory="Shopping", keywords="electronics,mobile,laptop,croma,vijay sales", emoji="📱"),
            SubCategoryEntity(name="Mall/Retail",  parentCategory="Shopping", keywords="mall,store,retail,reliance", emoji="🏬"),
            // Bills & Utilities
            SubCategoryEntity(name="Mobile Recharge", parentCategory="Bills & Utilities", keywords="recharge,postpaid,prepaid,airtel,jio,vodafone,bsnl,vi", emoji="📱"),
            SubCategoryEntity(name="Electricity",  parentCategory="Bills & Utilities", keywords="electricity,bescom,msedcl,torrent,tata power", emoji="⚡"),
            SubCategoryEntity(name="Internet",     parentCategory="Bills & Utilities", keywords="broadband,internet,wifi,fibernet", emoji="🌐"),
            SubCategoryEntity(name="DTH/Cable",    parentCategory="Bills & Utilities", keywords="dth,tatasky,dishtv,cable",          emoji="📺"),
            SubCategoryEntity(name="Gas/Water",    parentCategory="Bills & Utilities", keywords="gas,lpg,water bill,piped gas",       emoji="🔥"),
            // Transport
            SubCategoryEntity(name="Cab",          parentCategory="Transport", keywords="uber,ola,rapido,cab,taxi", emoji="🚕"),
            SubCategoryEntity(name="Fuel",         parentCategory="Transport", keywords="petrol,diesel,fuel,hp,indian oil,bharat petroleum", emoji="⛽"),
            SubCategoryEntity(name="Metro/Bus",    parentCategory="Transport", keywords="metro,bus,bmtc,best,ksrtc,dtc", emoji="🚇"),
            SubCategoryEntity(name="Train/Flight", parentCategory="Transport", keywords="irctc,train,flight,spicejet,indigo,air india", emoji="✈️"),
            SubCategoryEntity(name="FASTag",       parentCategory="Transport", keywords="fastag,toll,highway",     emoji="🛣️"),
            // Entertainment
            SubCategoryEntity(name="OTT",          parentCategory="Entertainment", keywords="netflix,prime,hotstar,zee5,sony liv,disney", emoji="📺"),
            SubCategoryEntity(name="Music",        parentCategory="Entertainment", keywords="spotify,gaana,jiosaavn,wynk", emoji="🎵"),
            SubCategoryEntity(name="Movies",       parentCategory="Entertainment", keywords="movie,bookmyshow,cinema,pvr,inox",  emoji="🎬"),
            SubCategoryEntity(name="Gaming",       parentCategory="Entertainment", keywords="gaming,steam,playstation,xbox,game", emoji="🎮"),
            // Health
            SubCategoryEntity(name="Pharmacy",     parentCategory="Health", keywords="pharmacy,medicine,chemist,medplus,apollo pharmacy,netmeds", emoji="💊"),
            SubCategoryEntity(name="Hospital",     parentCategory="Health", keywords="hospital,clinic,doctor,consultation", emoji="🏥"),
            SubCategoryEntity(name="Lab/Tests",    parentCategory="Health", keywords="lab,diagnostic,test,scan,thyrocare,lal path", emoji="🧪"),
            SubCategoryEntity(name="Fitness",      parentCategory="Health", keywords="gym,fitness,cult,yoga,crossfit",  emoji="💪"),
            // Transfer
            SubCategoryEntity(name="UPI Transfer", parentCategory="Transfer", keywords="upi,gpay,phonepe,paytm,bhim",  emoji="📲"),
            SubCategoryEntity(name="Bank Transfer",parentCategory="Transfer", keywords="neft,imps,rtgs",               emoji="🏦"),
            SubCategoryEntity(name="Own Account",  parentCategory="Transfer", keywords="own account,self transfer",    emoji="🔄"),
            // Groceries
            SubCategoryEntity(name="BigBasket",    parentCategory="Groceries", keywords="bigbasket",    emoji="🧺"),
            SubCategoryEntity(name="Blinkit",      parentCategory="Groceries", keywords="blinkit,grofers", emoji="🟡"),
            SubCategoryEntity(name="DMart/Supermarket", parentCategory="Groceries", keywords="dmart,reliance fresh,more,supermarket", emoji="🏪"),
            SubCategoryEntity(name="Vegetables",   parentCategory="Groceries", keywords="vegetables,fruits,sabzi,kirana", emoji="🥬")
        )

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS splits (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    transactionId INTEGER NOT NULL,
                    category TEXT NOT NULL,
                    amount REAL NOT NULL,
                    note TEXT NOT NULL DEFAULT '',
                    FOREIGN KEY(transactionId) REFERENCES transactions(id) ON DELETE CASCADE)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_splits_transactionId ON splits(transactionId)")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS sender_category_map (
                    sender TEXT PRIMARY KEY NOT NULL,
                    category TEXT NOT NULL,
                    learnedAt INTEGER NOT NULL DEFAULT 0)""")
            }
        }

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE transactions ADD COLUMN payee TEXT NOT NULL DEFAULT ''")
            }
        }

        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS deleted_sms_keys (
                    `key` TEXT PRIMARY KEY NOT NULL, deletedAt INTEGER NOT NULL DEFAULT 0)""")
            }
        }

        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Add subCategory column to transactions
                db.execSQL("ALTER TABLE transactions ADD COLUMN subCategory TEXT NOT NULL DEFAULT ''")
                // Create sub_categories table
                db.execSQL("""CREATE TABLE IF NOT EXISTS sub_categories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    name TEXT NOT NULL,
                    parentCategory TEXT NOT NULL,
                    keywords TEXT NOT NULL DEFAULT '',
                    emoji TEXT NOT NULL DEFAULT '',
                    FOREIGN KEY(parentCategory) REFERENCES categories(name) ON DELETE CASCADE)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_sub_categories_parentCategory ON sub_categories(parentCategory)")
            }
        }

        private val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE transactions ADD COLUMN flag TEXT NOT NULL DEFAULT ''")
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext, AppDatabase::class.java, "fintracker.db"
                ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7).build()
                INSTANCE = instance
                CoroutineScope(Dispatchers.IO).launch {
                    if (instance.categoryDao().getAll().isEmpty())
                        instance.categoryDao().insertAll(DEFAULT_CATEGORIES)
                    if (instance.subCategoryDao().getAll().isEmpty())
                        instance.subCategoryDao().insertAll(DEFAULT_SUB_CATEGORIES)
                }
                instance
            }
        }
    }
}
