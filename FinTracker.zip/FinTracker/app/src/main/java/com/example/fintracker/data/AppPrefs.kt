package com.example.fintracker.data

import android.content.Context
import java.util.Calendar

/**
 * App-level settings stored in SharedPreferences.
 * reportStartDate: reports ignore any transaction before this timestamp.
 * Default = 1 August 2026, 00:00 local time.
 */
object AppPrefs {
    private const val PREFS = "fintracker_prefs"
    private const val KEY_REPORT_START = "report_start_date"

    /** Default cutoff: 1 Aug 2026 00:00:00 */
    fun defaultReportStart(): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.YEAR, 2026)
        c.set(Calendar.MONTH, Calendar.AUGUST)
        c.set(Calendar.DAY_OF_MONTH, 1)
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0);      c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    fun getReportStart(ctx: Context): Long {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return p.getLong(KEY_REPORT_START, defaultReportStart())
    }

    fun setReportStart(ctx: Context, millis: Long) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putLong(KEY_REPORT_START, millis).apply()
    }
}
