package com.example.fintracker.data

object Categorizer {
    /**
     * Priority order:
     * 1. Payee→category map (learned from user corrections on specific merchants)
     * 2. Keyword matching on message body + sender
     * 3. Fallback to "Others"
     *
     * The key insight: sender like "VM-HDFCBK" is always the same (the bank).
     * What identifies the transaction is the PAYEE extracted from the SMS body —
     * e.g. "swiggy", "amazon", "john doe", "own account".
     */
    suspend fun categorize(
        text: String,
        sender: String,
        type: String,
        categories: List<CategoryEntity>,
        senderCategoryDao: SenderCategoryDao
    ): Pair<String, String> {  // returns (category, payee)

        // Extract payee from SMS body first
        val payee = PayeeExtractor.extract(text) ?: ""

        // 1. Check learned payee→category mapping
        if (payee.isNotEmpty()) {
            val learned = senderCategoryDao.get(payee)
            if (learned != null) return learned.category to payee
        }

        // 2. Keyword matching on full message text
        val haystack = (text + " " + sender).lowercase()
        for (cat in categories) {
            if (cat.keywords.isBlank()) continue
            val kws = cat.keywords.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            if (kws.any { haystack.contains(it) }) return cat.name to payee
        }

        return "Others" to payee
    }

    fun normalizeSender(sender: String): String =
        sender.trim().uppercase().replace(Regex("-[A-Z]$"), "").take(20)
}
