package com.example.fintracker.data

object Categorizer {
    fun categorize(text: String, sender: String, type: String, categories: List<CategoryEntity>): String {
        if (type == "CREDIT") {
            val lower = (text + " " + sender).lowercase()
            if (categories.any { it.name == "Salary & Income" }) {
                val incomeKw = categories.find { it.name == "Salary & Income" }?.keywords?.split(",") ?: emptyList()
                if (incomeKw.any { lower.contains(it.trim()) }) return "Salary & Income"
            }
        }
        val haystack = (text + " " + sender).lowercase()
        for (cat in categories) {
            if (cat.keywords.isBlank()) continue
            val kws = cat.keywords.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            if (kws.any { haystack.contains(it) }) return cat.name
        }
        return "Others"
    }
}
