package com.example.fintracker.data

object Categorizer {
    /**
     * Returns (category, subCategory, payee)
     *
     * Priority:
     * 1. Learned payee → category mapping
     * 2. Sub-category keyword match (most specific)
     * 3. Category keyword match (broader)
     * 4. Fallback "Others"
     */
    suspend fun categorize(
        text: String,
        sender: String,
        type: String,
        categories: List<CategoryEntity>,
        senderCategoryDao: SenderCategoryDao,
        subCategoryDao: SubCategoryDao? = null
    ): Triple<String, String, String> {  // category, subCategory, payee

        val payee    = PayeeExtractor.extract(text) ?: ""
        val haystack = (text + " " + sender).lowercase()

        // 1. Learned payee mapping (user taught this)
        if (payee.isNotEmpty()) {
            val learned = senderCategoryDao.get(payee)
            if (learned != null) {
                // Also try to match sub-category
                val sub = subCategoryDao?.let { matchSubCategory(haystack, learned.category, it) } ?: ""
                return Triple(learned.category, sub, payee)
            }
        }

        // 2. Sub-category keyword match (more specific than category)
        if (subCategoryDao != null) {
            val allSubs = subCategoryDao.getAll()
            for (sub in allSubs) {
                if (sub.keywords.isBlank()) continue
                val kws = sub.keywords.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                if (kws.any { haystack.contains(it) }) {
                    return Triple(sub.parentCategory, sub.name, payee)
                }
            }
        }

        // 3. Category keyword match
        for (cat in categories) {
            if (cat.keywords.isBlank()) continue
            val kws = cat.keywords.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            if (kws.any { haystack.contains(it) }) {
                val sub = subCategoryDao?.let { matchSubCategory(haystack, cat.name, it) } ?: ""
                return Triple(cat.name, sub, payee)
            }
        }

        return Triple("Others", "", payee)
    }

    private suspend fun matchSubCategory(haystack: String, parentCat: String, subCategoryDao: SubCategoryDao): String {
        val subs = subCategoryDao.getForCategory(parentCat)
        for (sub in subs) {
            if (sub.keywords.isBlank()) continue
            val kws = sub.keywords.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            if (kws.any { haystack.contains(it) }) return sub.name
        }
        return ""
    }

    fun normalizeSender(sender: String): String =
        sender.trim().uppercase().replace(Regex("-[A-Z]$"), "").take(20)
}
