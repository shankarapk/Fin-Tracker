package com.example.fintracker.data

import java.text.SimpleDateFormat
import java.util.*

object CsvExporter {

    private val dateFmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())

    private fun esc(v: Any?): String {
        val s = v?.toString() ?: ""
        return "\"" + s.replace("\"", "\"\"").replace("\n", " ").replace("\r", " ") + "\""
    }

    private fun row(vararg cells: Any?) = cells.joinToString(",") { esc(it) } + "\n"

    fun transactions(txns: List<TransactionEntity>): String {
        val sb = StringBuilder()
        sb.append(row("Date", "Payee", "Sender", "Type", "Amount", "Category",
            "Sub-Category", "Flag", "Balance", "Account", "Source", "Message"))
        txns.forEach { t ->
            sb.append(row(
                dateFmt.format(Date(t.date)),
                t.payee, t.sender, t.type, t.amount,
                t.category, t.subCategory, t.flag,
                t.balance ?: "", t.account ?: "", t.source, t.rawMessage
            ))
        }
        return sb.toString()
    }

    fun categoryReport(totals: List<Pair<String, Double>>): String {
        val sb = StringBuilder()
        val grand = totals.sumOf { it.second }
        sb.append(row("Category", "Amount", "Percent"))
        totals.forEach { (name, amt) ->
            val pct = if (grand > 0) String.format("%.1f%%", (amt / grand) * 100) else "0%"
            sb.append(row(name, amt, pct))
        }
        sb.append(row("TOTAL", grand, "100%"))
        return sb.toString()
    }

    fun periodReport(periodLabel: String, rows: List<Triple<String, Double, Double>>): String {
        val sb = StringBuilder()
        sb.append(row(periodLabel, "Debit", "Credit", "Net"))
        rows.forEach { (label, debit, credit) ->
            sb.append(row(label, debit, credit, credit - debit))
        }
        val td = rows.sumOf { it.second }
        val tc = rows.sumOf { it.third }
        sb.append(row("TOTAL", td, tc, tc - td))
        return sb.toString()
    }

    private fun subCategoryRows(rows: List<Pair<String, Double>>): String {
        val sb = StringBuilder()
        val grand = rows.sumOf { it.second }
        sb.append(row("Sub-Category", "Amount", "Percent"))
        rows.forEach { (name, amt) ->
            val pct = if (grand > 0) String.format("%.1f%%", (amt / grand) * 100) else "0%"
            sb.append(row(name, amt, pct))
        }
        sb.append(row("TOTAL", grand, "100%"))
        return sb.toString()
    }

    fun flagReport(txns: List<TransactionEntity>): String {
        val debits = txns.filter { it.type == "DEBIT" }
        val grand = debits.sumOf { it.amount }
        val byFlag = debits.groupBy { it.flag.ifEmpty { "UNTAGGED" } }
            .mapValues { (_, l) -> Pair(l.sumOf { it.amount }, l.size) }
            .entries.sortedByDescending { it.value.first }

        val sb = StringBuilder()
        sb.append(row("Flag", "Amount", "Count", "Percent"))
        byFlag.forEach { e ->
            val pct = if (grand > 0) String.format("%.1f%%", (e.value.first / grand) * 100) else "0%"
            sb.append(row(e.key, e.value.first, e.value.second, pct))
        }
        sb.append(row("TOTAL", grand, debits.size, "100%"))
        return sb.toString()
    }

    fun merchantReport(txns: List<TransactionEntity>, limit: Int = 50): String {
        val byPayee = txns.filter { it.type == "DEBIT" && it.payee.isNotEmpty() }
            .groupBy { it.payee }
            .mapValues { (_, l) -> Pair(l.sumOf { it.amount }, l.size) }
            .entries.sortedByDescending { it.value.first }
            .take(limit)

        val sb = StringBuilder()
        sb.append(row("Merchant", "Total Spend", "Transactions", "Average"))
        byPayee.forEach { e ->
            sb.append(row(e.key, e.value.first, e.value.second, e.value.first / e.value.second))
        }
        return sb.toString()
    }

    fun settingsBackup(
        learned: List<SenderCategoryMap>,
        categories: List<CategoryEntity>,
        subCategories: List<SubCategoryEntity>,
        budgets: List<BudgetEntity>
    ): String {
        val sb = StringBuilder()
        sb.append(row("SECTION", "F1", "F2", "F3", "F4"))
        learned.forEach       { sb.append(row("LEARNED", it.sender, it.category, "", "")) }
        categories.forEach    { sb.append(row("CATEGORY", it.name, it.keywords, it.colorHex, it.emoji)) }
        subCategories.forEach { sb.append(row("SUBCATEGORY", it.name, it.parentCategory, it.keywords, it.emoji)) }
        budgets.forEach       { sb.append(row("BUDGET", it.category, it.monthlyLimit, "", "")) }
        return sb.toString()
    }

    data class Backup(
        val learned: List<SenderCategoryMap>,
        val categories: List<CategoryEntity>,
        val subCategories: List<SubCategoryEntity>,
        val budgets: List<BudgetEntity>
    )

    fun parseBackup(csv: String): Backup {
        val learned = mutableListOf<SenderCategoryMap>()
        val cats    = mutableListOf<CategoryEntity>()
        val subs    = mutableListOf<SubCategoryEntity>()
        val budgets = mutableListOf<BudgetEntity>()

        csv.lines().drop(1).filter { it.isNotBlank() }.forEach { line ->
            val f = splitCsvLine(line)
            if (f.size < 5) return@forEach
            when (f[0]) {
                "LEARNED"     -> if (f[1].isNotBlank()) learned.add(SenderCategoryMap(f[1], f[2]))
                "CATEGORY"    -> if (f[1].isNotBlank()) cats.add(CategoryEntity(f[1], f[2], if (f[3].isBlank()) "#9E9E9E" else f[3], f[4]))
                "SUBCATEGORY" -> if (f[1].isNotBlank()) subs.add(SubCategoryEntity(name = f[1], parentCategory = f[2], keywords = f[3], emoji = f[4]))
                "BUDGET"      -> f[2].toDoubleOrNull()?.let { budgets.add(BudgetEntity(f[1], it)) }
            }
        }
        return Backup(learned, cats, subs, budgets)
    }

    private fun splitCsvLine(line: String): List<String> {
        val out = mutableListOf<String>()
        val cur = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < line.length) {
            val ch = line[i]
            when {
                ch == '"' && inQuotes && i + 1 < line.length && line[i + 1] == '"' -> { cur.append('"'); i++ }
                ch == '"' -> inQuotes = !inQuotes
                ch == ',' && !inQuotes -> { out.add(cur.toString()); cur.clear() }
                else -> cur.append(ch)
            }
            i++
        }
        out.add(cur.toString())
        return out
    }

    // ── Compatibility wrappers used by ReportsFragment ───────────────────────

    /** Same as periodReport but with (rows, label) argument order. */
    fun trendReport(rows: List<Triple<String, Double, Double>>, periodLabel: String): String =
        periodReport(periodLabel, rows)

    /** Sub-category breakdown computed directly from transactions. */
    fun subCategoryReport(txns: List<TransactionEntity>): String {
        val rows = txns.filter { it.type == "DEBIT" }
            .groupBy { it.subCategory.ifEmpty { "Uncategorized" } }
            .mapValues { (_, l) -> l.sumOf { it.amount } }
            .entries.sortedByDescending { it.value }
            .map { it.key to it.value }
        return subCategoryRows(rows)
    }

    /** Settings backup with (categories, subCategories, budgets, learned) argument order. */
    fun backup(
        categories: List<CategoryEntity>,
        subCategories: List<SubCategoryEntity>,
        budgets: List<BudgetEntity>,
        learned: List<SenderCategoryMap>
    ): String = settingsBackup(learned, categories, subCategories, budgets)
}
