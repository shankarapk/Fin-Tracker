package com.example.fintracker.data

import androidx.room.*

@Dao
interface TransactionDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(transactions: List<TransactionEntity>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(transaction: TransactionEntity): Long

    @Query("SELECT * FROM transactions ORDER BY date DESC")
    suspend fun getAll(): List<TransactionEntity>

    @Query("SELECT rawMessage || '|' || date FROM transactions WHERE source = 'SMS'")
    suspend fun getAllSmsKeys(): List<String>

    @Query("SELECT * FROM transactions WHERE date >= :start AND date < :end ORDER BY date DESC")
    suspend fun getBetween(start: Long, end: Long): List<TransactionEntity>

    @Query("UPDATE transactions SET category = :category WHERE id = :id")
    suspend fun setCategory(id: Long, category: String)

    @Query("UPDATE transactions SET category = :category, type = :type WHERE id = :id")
    suspend fun setCategoryAndType(id: Long, category: String, type: String)

    @Query("UPDATE transactions SET subCategory = :subCat WHERE id = :id")
    suspend fun setSubCategory(id: Long, subCat: String)

    @Query("UPDATE transactions SET flag = :flag WHERE id = :id")
    suspend fun setFlag(id: Long, flag: String)

    @Query("UPDATE transactions SET category = :cat, subCategory = :subCat, type = :type WHERE id = :id")
    suspend fun setCatSubCatType(id: Long, cat: String, subCat: String, type: String)

    @Query("UPDATE transactions SET category = :cat, subCategory = :subCat, type = :type, flag = :flag WHERE id = :id")
    suspend fun setAll(id: Long, cat: String, subCat: String, type: String, flag: String)

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT * FROM transactions WHERE id = :id")
    suspend fun getById(id: Long): TransactionEntity?
}

@Dao
interface CategoryDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(categories: List<CategoryEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(category: CategoryEntity)

    @Query("SELECT * FROM categories ORDER BY name ASC")
    suspend fun getAll(): List<CategoryEntity>

    @Query("DELETE FROM categories WHERE name = :name")
    suspend fun delete(name: String)
}

@Dao
interface BudgetDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(budget: BudgetEntity)

    @Query("SELECT * FROM budgets")
    suspend fun getAll(): List<BudgetEntity>

    @Query("DELETE FROM budgets WHERE category = :category")
    suspend fun delete(category: String)
}

@Dao
interface SplitDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(splits: List<SplitEntity>)

    @Query("SELECT * FROM splits WHERE transactionId = :txnId")
    suspend fun getForTransaction(txnId: Long): List<SplitEntity>

    @Query("SELECT * FROM splits")
    suspend fun getAll(): List<SplitEntity>

    @Query("DELETE FROM splits WHERE transactionId = :txnId")
    suspend fun deleteForTransaction(txnId: Long)
}

@Dao
interface SenderCategoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(map: SenderCategoryMap)

    @Query("SELECT * FROM sender_category_map WHERE sender = :sender LIMIT 1")
    suspend fun get(sender: String): SenderCategoryMap?

    @Query("SELECT * FROM sender_category_map ORDER BY learnedAt DESC")
    suspend fun getAll(): List<SenderCategoryMap>

    @Query("DELETE FROM sender_category_map WHERE sender = :sender")
    suspend fun delete(sender: String)
}

@Dao
interface DeletedSmsKeyDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(key: DeletedSmsKey)

    @Query("SELECT key FROM deleted_sms_keys")
    suspend fun getAllKeys(): List<String>
}

@Dao
interface SubCategoryDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(subCats: List<SubCategoryEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(subCat: SubCategoryEntity)

    @Query("SELECT * FROM sub_categories WHERE parentCategory = :parentCat ORDER BY name ASC")
    suspend fun getForCategory(parentCat: String): List<SubCategoryEntity>

    @Query("SELECT * FROM sub_categories ORDER BY parentCategory, name ASC")
    suspend fun getAll(): List<SubCategoryEntity>

    @Query("DELETE FROM sub_categories WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("UPDATE transactions SET subCategory = :subCat WHERE id = :id")
    suspend fun setSubCategoryOnTxn(id: Long, subCat: String)
}
