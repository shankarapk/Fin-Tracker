package com.example.fintracker.data

import androidx.room.*

@Dao
interface TransactionDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(transactions: List<TransactionEntity>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(transaction: TransactionEntity): Long

    // Main list: show originals + manual entries; hide split children
    @Query("SELECT * FROM transactions WHERE isOriginal = 1 ORDER BY date DESC")
    suspend fun getVisible(): List<TransactionEntity>

    // All transactions (for reports/summaries) — exclude original of a split, include split children
    @Query("""
        SELECT * FROM transactions 
        WHERE (splitGroupId = 0) OR (splitGroupId != 0 AND isOriginal = 0)
        ORDER BY date DESC
    """)
    suspend fun getForReports(): List<TransactionEntity>

    @Query("SELECT rawMessage || '|' || date FROM transactions WHERE source = 'SMS'")
    suspend fun getAllSmsKeys(): List<String>

    @Query("SELECT * FROM transactions WHERE date >= :start AND date < :end AND ((splitGroupId = 0) OR (splitGroupId != 0 AND isOriginal = 0))")
    suspend fun getBetween(start: Long, end: Long): List<TransactionEntity>

    @Query("UPDATE transactions SET category = :category WHERE id = :id")
    suspend fun setCategory(id: Long, category: String)

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM transactions WHERE splitGroupId = :groupId")
    suspend fun deleteSplitGroup(groupId: Long)

    @Query("SELECT * FROM transactions WHERE splitGroupId = :groupId AND isOriginal = 0")
    suspend fun getSplitChildren(groupId: Long): List<TransactionEntity>
}

@Dao
interface CategoryDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(categories: List<CategoryEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(category: CategoryEntity)

    @Query("SELECT * FROM categories ORDER BY name ASC")
    suspend fun getAll(): List<CategoryEntity>

    @Query("DELETE FROM categories WHERE name = :name")
    suspend fun delete(name: String)
}

@Dao
interface BudgetDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(budget: BudgetEntity)

    @Query("SELECT * FROM budgets")
    suspend fun getAll(): List<BudgetEntity>

    @Query("DELETE FROM budgets WHERE category = :category")
    suspend fun delete(category: String)
}

@Dao
interface SplitDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(splits: List<SplitEntity>)

    @Query("SELECT * FROM splits WHERE transactionId = :txnId")
    suspend fun getForTransaction(txnId: Long): List<SplitEntity>

    @Query("SELECT * FROM splits")
    suspend fun getAll(): List<SplitEntity>

    @Query("DELETE FROM splits WHERE transactionId = :txnId")
    suspend fun deleteForTransaction(txnId: Long)
}
