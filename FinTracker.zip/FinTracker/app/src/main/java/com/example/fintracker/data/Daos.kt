package com.example.fintracker.data

import androidx.room.*

@Dao
interface TransactionDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(transactions: List<TransactionEntity>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(transaction: TransactionEntity): Long

    @Query("SELECT * FROM transactions ORDER BY date DESC")
    suspend fun getAll(): List<TransactionEntity>

    @Query("SELECT rawMessage || '|' || date FROM transactions WHERE source = 'SMS'")
    suspend fun getAllSmsKeys(): List<String>

    @Query("SELECT * FROM transactions WHERE date >= :start AND date < :end ORDER BY date DESC")
    suspend fun getBetween(start: Long, end: Long): List<TransactionEntity>

    @Query("UPDATE transactions SET category = :category WHERE id = :id")
    suspend fun setCategory(id: Long, category: String)

    @Query("UPDATE transactions SET category = :category, type = :type WHERE id = :id")
    suspend fun setCategoryAndType(id: Long, category: String, type: String)

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT * FROM transactions WHERE id = :id")
    suspend fun getById(id: Long): TransactionEntity?
}

@Dao
interface CategoryDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(categories: List<CategoryEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(category: CategoryEntity)

    @Query("SELECT * FROM categories ORDER BY name ASC")
    suspend fun getAll(): List<CategoryEntity>

    @Query("DELETE FROM categories WHERE name = :name")
    suspend fun delete(name: String)
}

@Dao
interface BudgetDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(budget: BudgetEntity)

    @Query("SELECT * FROM budgets")
    suspend fun getAll(): List<BudgetEntity>

    @Query("DELETE FROM budgets WHERE category = :category")
    suspend fun delete(category: String)
}

@Dao
interface SplitDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(splits: List<SplitEntity>)

    @Query("SELECT * FROM splits WHERE transactionId = :txnId")
    suspend fun getForTransaction(txnId: Long): List<SplitEntity>

    @Query("SELECT * FROM splits")
    suspend fun getAll(): List<SplitEntity>

    @Query("DELETE FROM splits WHERE transactionId = :txnId")
    suspend fun deleteForTransaction(txnId: Long)
}

@Dao
interface SenderCategoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(map: SenderCategoryMap)

    @Query("SELECT * FROM sender_category_map WHERE sender = :sender LIMIT 1")
    suspend fun get(sender: String): SenderCategoryMap?

    @Query("SELECT * FROM sender_category_map ORDER BY learnedAt DESC")
    suspend fun getAll(): List<SenderCategoryMap>

    @Query("DELETE FROM sender_category_map WHERE sender = :sender")
    suspend fun delete(sender: String)
}
