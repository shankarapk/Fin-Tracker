package com.example.fintracker.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "transactions",
    indices = [Index(value = ["rawMessage", "date"], unique = true)])
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sender: String,
    val date: Long,
    val type: String,
    val amount: Double,
    val balance: Double?,
    val account: String?,
    val rawMessage: String,
    val category: String = "Uncategorized",
    val source: String = "SMS",       // SMS | MANUAL | SPLIT
    val splitGroupId: Long = 0L,      // non-zero = belongs to a split group
    val isOriginal: Boolean = true    // false = this row is a split child (hidden in main list)
)

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey val name: String,
    val keywords: String,
    val colorHex: String,
    val emoji: String = ""
)

@Entity(tableName = "budgets")
data class BudgetEntity(
    @PrimaryKey val category: String,
    val monthlyLimit: Double
)

@Entity(tableName = "splits",
    foreignKeys = [ForeignKey(entity = TransactionEntity::class,
        parentColumns = ["id"], childColumns = ["transactionId"],
        onDelete = ForeignKey.CASCADE)],
    indices = [Index("transactionId")])
data class SplitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val transactionId: Long,
    val category: String,
    val amount: Double,
    val note: String = ""
)
