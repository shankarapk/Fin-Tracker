package com.example.fintracker.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "transactions",
    indices = [Index(value = ["rawMessage", "date"], unique = true)])
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sender: String,
    val date: Long,
    val type: String,
    val amount: Double,
    val balance: Double?,
    val account: String?,
    val rawMessage: String,
    val category: String = "Uncategorized",
    val source: String = "SMS",
    val payee: String = "",
    val subCategory: String = "",
    val flag: String = ""   // SPEND, SAVINGS, INVESTMENT, NEED, WANT — user-defined label
)

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey val name: String,
    val keywords: String,
    val colorHex: String,
    val emoji: String = ""
)

@Entity(tableName = "budgets")
data class BudgetEntity(
    @PrimaryKey val category: String,
    val monthlyLimit: Double
)

@Entity(tableName = "splits",
    foreignKeys = [ForeignKey(entity = TransactionEntity::class,
        parentColumns = ["id"], childColumns = ["transactionId"],
        onDelete = ForeignKey.CASCADE)],
    indices = [Index("transactionId")])
data class SplitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val transactionId: Long,
    val category: String,
    val amount: Double,
    val note: String = ""
)

/** Smart learning: remembers which category a payee/merchant belongs to */
@Entity(tableName = "sender_category_map")
data class SenderCategoryMap(
    @PrimaryKey val sender: String,   // payee name (normalized) e.g. "swiggy", "amazon"
    val category: String,
    val learnedAt: Long = System.currentTimeMillis()
)

/** Blocklist: deleted SMS keys that should never be re-imported on future scans */
@Entity(tableName = "deleted_sms_keys")
data class DeletedSmsKey(
    @PrimaryKey val key: String,        // "rawMessage|date"
    val deletedAt: Long = System.currentTimeMillis()
)

/** Sub-category belonging to a parent category */
@Entity(tableName = "sub_categories",
    foreignKeys = [ForeignKey(entity = CategoryEntity::class,
        parentColumns = ["name"], childColumns = ["parentCategory"],
        onDelete = ForeignKey.CASCADE)],
    indices = [Index("parentCategory")])
data class SubCategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val parentCategory: String,
    val keywords: String = "",
    val emoji: String = ""
)
