package com.example.fintracker.data

import android.content.Context
import android.net.Uri
import com.example.fintracker.server.DataChangeNotifier
import java.util.Calendar

class FinanceRepository(context: Context) {
    private val db  = AppDatabase.getInstance(context)
    private val ctx = context.applicationContext

    // ── Sub-Categories ───────────────────────────────────────────────────────
    suspend fun getSubCategories(parentCat: String) = db.subCategoryDao().getForCategory(parentCat)
    suspend fun getAllSubCategories()               = db.subCategoryDao().getAll()

    suspend fun addSubCategory(name: String, parentCat: String, keywords: String, emoji: String) {
        db.subCategoryDao().insert(SubCategoryEntity(
            name = name, parentCategory = parentCat,
            keywords = keywords.lowercase(), emoji = emoji
        ))
        DataChangeNotifier.notify("categories")
    }

    suspend fun deleteSubCategory(id: Long) {
        db.subCategoryDao().delete(id)
        DataChangeNotifier.notify("categories")
    }

    suspend fun updateSubCategory(id: Long, subCat: String) {
        db.transactionDao().setSubCategory(id, subCat)
        DataChangeNotifier.notify("transactions")
    }

    /** Update category + subCategory + type together */
    suspend fun updateTransactionFull(id: Long, category: String, subCategory: String, type: String) {
        db.transactionDao().setCatSubCatType(id, category, subCategory, type)
        val txn = db.transactionDao().getById(id) ?: return
        if (txn.source == "SMS") learnSenderCategory(txn, category)
        DataChangeNotifier.notify("transactions")
    }

    // ── Categories ──────────────────────────────────────────────────────────
    suspend fun getCategories() = db.categoryDao().getAll()

    suspend fun addCategory(name: String, keywords: String, colorHex: String, emoji: String) {
        db.categoryDao().insert(CategoryEntity(name, keywords, colorHex, emoji))
        DataChangeNotifier.notify("categories")
    }

    suspend fun deleteCategory(name: String) {
        db.categoryDao().delete(name)
        db.budgetDao().delete(name)
        DataChangeNotifier.notify("categories")
    }

    // ── Smart payee learning ─────────────────────────────────────────────────
    suspend fun learnSenderCategory(txn: TransactionEntity, category: String) {
        val payee = txn.payee.takeIf { it.isNotEmpty() }
            ?: PayeeExtractor.extract(txn.rawMessage)
            ?: return
        db.senderCategoryDao().upsert(SenderCategoryMap(payee, category))
    }

    suspend fun getSenderMappings() = db.senderCategoryDao().getAll()
    suspend fun deleteSenderMapping(sender: String) = db.senderCategoryDao().delete(sender)

    // ── SMS scanning ─────────────────────────────────────────────────────────
    suspend fun scanSms(): Int {
        // Dedup set = already imported + permanently deleted (blocklisted)
        val existing  = db.transactionDao().getAllSmsKeys().toHashSet()
        val blocklist = db.deletedSmsKeyDao().getAllKeys().toHashSet()
        val skip      = existing + blocklist

        val categories = db.categoryDao().getAll()
        val uri        = Uri.parse("content://sms/inbox")
        val cursor     = ctx.contentResolver.query(uri, arrayOf("address", "body", "date"), null, null, "date DESC")
        val newItems   = mutableListOf<TransactionEntity>()
        cursor?.use {
            val ai = it.getColumnIndexOrThrow("address")
            val bi = it.getColumnIndexOrThrow("body")
            val di = it.getColumnIndexOrThrow("date")
            while (it.moveToNext()) {
                val sender = it.getString(ai) ?: "Unknown"
                val body   = it.getString(bi) ?: continue
                val date   = it.getLong(di)
                if ("$body|$date" in skip) continue   // skip already imported OR blocklisted
                val parsed = SmsParser.parse(body) ?: continue
                val (cat, subCat, payee) = Categorizer.categorize(
                    body, sender, parsed.type, categories,
                    db.senderCategoryDao(), db.subCategoryDao()
                )
                newItems.add(TransactionEntity(
                    sender = sender, date = date, type = parsed.type,
                    amount = parsed.amount, balance = parsed.balance,
                    account = parsed.account, rawMessage = body,
                    category = cat, source = "SMS", payee = payee,
                    subCategory = subCat
                ))
            }
        }
        if (newItems.isNotEmpty()) {
            db.transactionDao().insertAll(newItems)
            DataChangeNotifier.notify("transactions")
        }
        return newItems.size
    }

    // ── Manual entries ───────────────────────────────────────────────────────
    suspend fun addManual(type: String, amount: Double, category: String, note: String,
                          date: Long = System.currentTimeMillis(), flag: String = "") {
        db.transactionDao().insert(TransactionEntity(
            sender = "Manual", date = date, type = type, amount = amount,
            balance = null, account = null, rawMessage = note,
            category = category, source = "MANUAL", payee = "", flag = flag
        ))
        DataChangeNotifier.notify("transactions")
    }

    /** Update category + learn payee */
    suspend fun updateCategory(id: Long, category: String) {
        db.transactionDao().setCategory(id, category)
        val txn = db.transactionDao().getById(id) ?: return
        if (txn.source == "SMS") learnSenderCategory(txn, category)
        DataChangeNotifier.notify("transactions")
    }

    suspend fun setFlag(id: Long, flag: String) {
        db.transactionDao().setFlag(id, flag)
        DataChangeNotifier.notify("transactions")
    }

    /** Update category + subCategory + type + flag together */
    suspend fun updateTransactionFull(id: Long, category: String, subCategory: String, type: String, flag: String = "") {
        db.transactionDao().setAll(id, category, subCategory, type, flag)
        val txn = db.transactionDao().getById(id) ?: return
        if (txn.source == "SMS") learnSenderCategory(txn, category)
        DataChangeNotifier.notify("transactions")
    }

    suspend fun deleteTransaction(id: Long) {
        val txn = db.transactionDao().getById(id)
        // If it's an SMS transaction, add to blocklist so it's never re-imported
        if (txn != null && txn.source == "SMS") {
            db.deletedSmsKeyDao().insert(
                DeletedSmsKey(key = "${txn.rawMessage}|${txn.date}")
            )
        }
        db.transactionDao().deleteById(id)
        DataChangeNotifier.notify("transactions")
    }

    // ── Splits ───────────────────────────────────────────────────────────────
    suspend fun saveSplits(transactionId: Long, splits: List<SplitEntity>) {
        db.splitDao().deleteForTransaction(transactionId)
        db.splitDao().insertAll(splits.map { it.copy(transactionId = transactionId) })
        DataChangeNotifier.notify("splits")
    }

    suspend fun getSplitsForTransaction(txnId: Long) = db.splitDao().getForTransaction(txnId)
    suspend fun getAllSplits() = db.splitDao().getAll()

    // ── Queries ──────────────────────────────────────────────────────────────
    suspend fun getAllTransactions()       = db.transactionDao().getAll()
    suspend fun getTransactionById(id: Long) = db.transactionDao().getById(id)

    suspend fun getCurrentMonthTransactions(): List<TransactionEntity> {
        val (s, e) = monthRange(0); return db.transactionDao().getBetween(s, e)
    }

    suspend fun getTransactionsBetween(start: Long, end: Long) =
        db.transactionDao().getBetween(start, end)

    suspend fun getLastNWeeksTotals(n: Int): List<Triple<String, Double, Double>> {
        val cal = Calendar.getInstance()
        return (n - 1 downTo 0).map { i ->
            val c = cal.clone() as Calendar
            c.add(Calendar.WEEK_OF_YEAR, -i)
            c.set(Calendar.DAY_OF_WEEK, c.firstDayOfWeek)
            c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0)
            val start = c.timeInMillis
            val label = "W${c.get(Calendar.WEEK_OF_YEAR)}"
            c.add(Calendar.WEEK_OF_YEAR, 1)
            val txns = db.transactionDao().getBetween(start, c.timeInMillis)
            Triple(label, txns.filter { it.type == "DEBIT" }.sumOf { it.amount },
                txns.filter { it.type == "CREDIT" }.sumOf { it.amount })
        }
    }

    suspend fun getLastNMonthsTotals(n: Int): List<Triple<String, Double, Double>> {
        val cal = Calendar.getInstance()
        return (n - 1 downTo 0).map { i ->
            val c = cal.clone() as Calendar
            c.add(Calendar.MONTH, -i)
            c.set(Calendar.DAY_OF_MONTH, 1); c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0)
            val start = c.timeInMillis
            val label = android.text.format.DateFormat.format("MMM", c).toString()
            c.add(Calendar.MONTH, 1)
            val txns = db.transactionDao().getBetween(start, c.timeInMillis)
            Triple(label, txns.filter { it.type == "DEBIT" }.sumOf { it.amount },
                txns.filter { it.type == "CREDIT" }.sumOf { it.amount })
        }
    }

    suspend fun getCurrentWeekTransactions(): List<TransactionEntity> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        val start = cal.timeInMillis
        cal.add(Calendar.WEEK_OF_YEAR, 1)
        return db.transactionDao().getBetween(start, cal.timeInMillis)
    }

    fun categoryTotals(txns: List<TransactionEntity>): List<Pair<String, Double>> =
        txns.filter { it.type == "DEBIT" }
            .groupBy { it.category }
            .mapValues { (_, l) -> l.sumOf { it.amount } }
            .entries.sortedByDescending { it.value }
            .map { it.key to it.value }

    // ── Budgets ──────────────────────────────────────────────────────────────
    suspend fun getBudgets() = db.budgetDao().getAll()

    suspend fun setBudget(cat: String, limit: Double) {
        db.budgetDao().upsert(BudgetEntity(cat, limit))
        DataChangeNotifier.notify("budgets")
    }

    suspend fun deleteBudget(cat: String) {
        db.budgetDao().delete(cat)
        DataChangeNotifier.notify("budgets")
    }

    suspend fun getBudgetProgress(): Map<String, Triple<Double, Double, Double?>> {
        val txns    = getCurrentMonthTransactions().filter { it.type == "DEBIT" }
        val spent   = txns.groupBy { it.category }.mapValues { (_, l) -> l.sumOf { it.amount } }
        val budgets = getBudgets().associateBy { it.category }
        val cats    = getCategories().map { it.name }
        return cats.associateWith { cat ->
            Triple(spent[cat] ?: 0.0, (spent[cat] ?: 0.0), budgets[cat]?.monthlyLimit)
        }.filter { (_, v) -> v.first > 0 || v.third != null }
    }

    private fun monthRange(offset: Int): Pair<Long, Long> {
        val c = Calendar.getInstance()
        c.add(Calendar.MONTH, offset)
        c.set(Calendar.DAY_OF_MONTH, 1); c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0)
        val s = c.timeInMillis; c.add(Calendar.MONTH, 1); return s to c.timeInMillis
    }
}
