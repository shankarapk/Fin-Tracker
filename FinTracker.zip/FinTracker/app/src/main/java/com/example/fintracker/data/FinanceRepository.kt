package com.example.fintracker.data

import android.content.Context
import android.net.Uri
import java.util.Calendar

class FinanceRepository(context: Context) {
    private val db = AppDatabase.getInstance(context)
    private val ctx = context.applicationContext

    suspend fun getCategories() = db.categoryDao().getAll()
    suspend fun addCategory(name: String, keywords: String, colorHex: String, emoji: String) =
        db.categoryDao().insert(CategoryEntity(name, keywords, colorHex, emoji))
    suspend fun deleteCategory(name: String) { db.categoryDao().delete(name); db.budgetDao().delete(name) }

    suspend fun scanSms(): Int {
        // Build dedup set: "rawMessage|date"
        val existing = db.transactionDao().getAllSmsKeys().toHashSet()
        val categories = db.categoryDao().getAll()
        val uri = Uri.parse("content://sms/inbox")
        val cursor = ctx.contentResolver.query(uri, arrayOf("address","body","date"), null, null, "date DESC")
        val newItems = mutableListOf<TransactionEntity>()
        cursor?.use {
            val ai = it.getColumnIndexOrThrow("address")
            val bi = it.getColumnIndexOrThrow("body")
            val di = it.getColumnIndexOrThrow("date")
            while (it.moveToNext()) {
                val sender = it.getString(ai) ?: "Unknown"
                val body = it.getString(bi) ?: continue
                val date = it.getLong(di)
                val key = "$body|$date"
                if (key in existing) continue
                val parsed = SmsParser.parse(body) ?: continue
                val cat = Categorizer.categorize(body, sender, parsed.type, categories)
                newItems.add(TransactionEntity(
                    sender = sender, date = date, type = parsed.type,
                    amount = parsed.amount, balance = parsed.balance,
                    account = parsed.account, rawMessage = body,
                    category = cat, source = "SMS"
                ))
            }
        }
        if (newItems.isNotEmpty()) db.transactionDao().insertAll(newItems)
        return newItems.size
    }

    suspend fun addManual(type: String, amount: Double, category: String, note: String, date: Long = System.currentTimeMillis()) {
        db.transactionDao().insert(TransactionEntity(
            sender = "Manual", date = date, type = type, amount = amount,
            balance = null, account = null, rawMessage = note, category = category, source = "MANUAL"
        ))
    }

    suspend fun updateCategory(id: Long, cat: String) = db.transactionDao().setCategory(id, cat)
    suspend fun getAllTransactions() = db.transactionDao().getAll()
    suspend fun getCurrentMonthTransactions(): List<TransactionEntity> {
        val (s, e) = monthRange(0); return db.transactionDao().getBetween(s, e)
    }

    suspend fun getLastNMonthsTotals(n: Int): List<Triple<String, Double, Double>> {
        val cal = Calendar.getInstance()
        return (n-1 downTo 0).map { i ->
            val c = cal.clone() as Calendar
            c.add(Calendar.MONTH, -i)
            c.set(Calendar.DAY_OF_MONTH, 1); c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0)
            val start = c.timeInMillis
            val label = android.text.format.DateFormat.format("MMM", c).toString()
            c.add(Calendar.MONTH, 1)
            val txns = db.transactionDao().getBetween(start, c.timeInMillis)
            Triple(label, txns.filter { it.type=="DEBIT" }.sumOf { it.amount },
                txns.filter { it.type=="CREDIT" }.sumOf { it.amount })
        }
    }

    suspend fun getBudgets() = db.budgetDao().getAll()
    suspend fun setBudget(cat: String, limit: Double) = db.budgetDao().upsert(BudgetEntity(cat, limit))
    suspend fun deleteBudget(cat: String) = db.budgetDao().delete(cat)

    suspend fun getBudgetProgress(): Map<String, Triple<Double, Double, Double?>> {
        val txns = getCurrentMonthTransactions().filter { it.type == "DEBIT" }
        val spent = txns.groupBy { it.category }.mapValues { (_, l) -> l.sumOf { it.amount } }
        val budgets = getBudgets().associateBy { it.category }
        val cats = getCategories().map { it.name }
        return cats.associateWith { cat ->
            Triple(spent[cat] ?: 0.0, (spent[cat] ?: 0.0), budgets[cat]?.monthlyLimit)
        }.filter { (_, v) -> v.first > 0 || v.third != null }
    }

    private fun monthRange(offset: Int): Pair<Long, Long> {
        val c = Calendar.getInstance()
        c.add(Calendar.MONTH, offset)
        c.set(Calendar.DAY_OF_MONTH, 1); c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0)
        val s = c.timeInMillis; c.add(Calendar.MONTH, 1); return s to c.timeInMillis
    }
}

    // ---- Report helpers ----

    /** Returns transactions for the current ISO week (Mon–Sun) */
    suspend fun getCurrentWeekTransactions(): List<TransactionEntity> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_WEEK, cal.firstDayOfWeek)
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        val start = cal.timeInMillis
        cal.add(Calendar.WEEK_OF_YEAR, 1)
        return db.transactionDao().getBetween(start, cal.timeInMillis)
    }

    /** Returns (weekLabel, debit, credit) for last N weeks */
    suspend fun getLastNWeeksTotals(n: Int): List<Triple<String, Double, Double>> {
        val cal = Calendar.getInstance()
        return (n - 1 downTo 0).map { i ->
            val c = cal.clone() as Calendar
            c.add(Calendar.WEEK_OF_YEAR, -i)
            c.set(Calendar.DAY_OF_WEEK, c.firstDayOfWeek)
            c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0)
            val start = c.timeInMillis
            val label = "W${c.get(Calendar.WEEK_OF_YEAR)}"
            c.add(Calendar.WEEK_OF_YEAR, 1)
            val txns = db.transactionDao().getBetween(start, c.timeInMillis)
            Triple(label,
                txns.filter { it.type == "DEBIT" }.sumOf { it.amount },
                txns.filter { it.type == "CREDIT" }.sumOf { it.amount })
        }
    }

    /** Category-wise totals for given transaction list */
    fun categoryTotals(txns: List<TransactionEntity>): List<Pair<String, Double>> =
        txns.filter { it.type == "DEBIT" }
            .groupBy { it.category }
            .mapValues { (_, l) -> l.sumOf { it.amount } }
            .entries.sortedByDescending { it.value }
            .map { it.key to it.value }
