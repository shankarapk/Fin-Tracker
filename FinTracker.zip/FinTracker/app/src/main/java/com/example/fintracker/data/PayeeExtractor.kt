package com.example.fintracker.data

import java.util.regex.Pattern

/**
 * Extracts the payee/merchant from a bank SMS body.
 * Indian bank SMS formats vary widely but follow common patterns.
 *
 * Examples:
 *   "Rs.500 debited for purchase at Swiggy" → "swiggy"
 *   "paid to John Doe via UPI" → "john doe"
 *   "sent to rahul@okicici" → "rahul"
 *   "transferred to own account XX1234" → "own account"
 *   "NEFT to ABC Company Ltd" → "abc company ltd"
 *   "payment to Amazon India" → "amazon india"
 *   "pos purchase at Big Bazaar" → "big bazaar"
 */
object PayeeExtractor {

    // Ordered by specificity — first match wins
    private val PATTERNS = listOf(
        // UPI: "to rahul@okicici" or "to 9876543210@paytm"
        Pattern.compile("(?:sent|paid|transfer(?:red)?|payment)\\s+to\\s+([a-z0-9._\\-]+@[a-z]+)", Pattern.CASE_INSENSITIVE),
        // "paid to <Name>" (name before via/on/for)
        Pattern.compile("(?:paid|sent|payment(?:\\s+of)?|transfer(?:red)?)\\s+to\\s+([a-zA-Z][a-zA-Z0-9 .&'\\-]{2,30})(?:\\s+(?:via|on|for|ref|upi|neft|imps|using|through))?", Pattern.CASE_INSENSITIVE),
        // "purchase at <Merchant>"
        Pattern.compile("purchase(?:\\s+at)?\\s+([a-zA-Z][a-zA-Z0-9 .&'\\-]{2,30})", Pattern.CASE_INSENSITIVE),
        // "at <Merchant>" (POS / card swipe)
        Pattern.compile("\\bat\\s+([a-zA-Z][a-zA-Z0-9 .&'\\-]{2,30})(?:\\s+on)?", Pattern.CASE_INSENSITIVE),
        // "towards <Merchant/purpose>"
        Pattern.compile("towards\\s+([a-zA-Z][a-zA-Z0-9 .&'\\-]{2,30})", Pattern.CASE_INSENSITIVE),
        // "for <Merchant>" - "for Swiggy order"
        Pattern.compile("(?:debited\\s+)?for\\s+([a-zA-Z][a-zA-Z0-9 .&'\\-]{2,20})(?:\\s+(?:order|purchase|payment|txn))?", Pattern.CASE_INSENSITIVE),
        // "NEFT/IMPS to <Name>"
        Pattern.compile("(?:neft|imps|rtgs)\\s+(?:to|from)\\s+([a-zA-Z][a-zA-Z0-9 .&'\\-]{2,30})", Pattern.CASE_INSENSITIVE),
        // "trf to own a/c" or "own account"
        Pattern.compile("(own\\s+a(?:ccount|/c))", Pattern.CASE_INSENSITIVE)
    )

    // Strip noise words that aren't meaningful payee identifiers
    private val STOP_WORDS = setOf(
        "your", "the", "this", "from", "with", "has", "been", "bank", "account",
        "card", "linked", "mobile", "number", "ref", "no", "using", "net", "banking"
    )

    /**
     * Returns normalized payee string, or null if none found.
     * e.g. "paid to SWIGGY INDIA PVT" → "swiggy india pvt"
     */
    fun extract(smsBody: String): String? {
        val body = smsBody.replace(Regex("[\\r\\n]+"), " ").trim()

        for (pattern in PATTERNS) {
            val m = pattern.matcher(body)
            if (m.find()) {
                val raw = m.group(1)?.trim() ?: continue
                val normalized = normalize(raw)
                if (normalized.length >= 3 && !isNoise(normalized)) {
                    return normalized
                }
            }
        }
        return null
    }

    /** Normalizes payee: lowercase, strip UPI suffix, trim */
    fun normalize(raw: String): String {
        return raw
            .lowercase()
            .replace(Regex("@[a-z]+$"), "")  // remove @okicici, @paytm etc
            .replace(Regex("\\b(pvt|ltd|llp|inc|corp|private|limited)\\b"), "")
            .replace(Regex("[^a-z0-9 &.'-]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun isNoise(text: String): Boolean {
        val words = text.split(" ")
        return words.all { it in STOP_WORDS } || text.matches(Regex("[0-9 ]+"))
    }
}
