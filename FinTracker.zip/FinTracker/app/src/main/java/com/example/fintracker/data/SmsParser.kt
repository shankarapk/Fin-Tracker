package com.example.fintracker.data

import java.util.regex.Pattern

object SmsParser {
    private val DEBIT_KEYWORDS = listOf("debited","debit","spent","paid","withdrawn","purchase","sent","deducted","payment of","payment done")
    private val CREDIT_KEYWORDS = listOf("credited","credit","received","deposited","refund","cashback","reversed")

    private val AMOUNT_PATTERN = Pattern.compile(
        "(?:rs\\.?|inr|₹)\\s?([0-9][0-9,]*(?:\\.\\d{1,2})?)",
        Pattern.CASE_INSENSITIVE
    )
    private val BALANCE_PATTERN = Pattern.compile(
        "(?:avl|available|avbl|bal)\\.?\\s*(?:bal(?:ance)?)?\\.?:?\\s*(?:rs\\.?|inr|₹)?\\s?([0-9][0-9,]*(?:\\.\\d{1,2})?)",
        Pattern.CASE_INSENSITIVE
    )
    private val ACCOUNT_PATTERN = Pattern.compile(
        "(?:a/?c|account|card|ac)\\s*(?:no\\.?)?\\s*[xX*]*\\s*([0-9]{3,6})",
        Pattern.CASE_INSENSITIVE
    )

    data class ParsedSms(val type: String, val amount: Double, val balance: Double?, val account: String?)

    fun parse(body: String): ParsedSms? {
        val m = AMOUNT_PATTERN.matcher(body)
        if (!m.find()) return null
        val amount = m.group(1)?.replace(",", "")?.toDoubleOrNull() ?: return null
        val lower = body.lowercase()
        if (lower.contains("otp") || lower.contains("one time")) return null

        val type = when {
            DEBIT_KEYWORDS.any { lower.contains(it) } -> "DEBIT"
            CREDIT_KEYWORDS.any { lower.contains(it) } -> "CREDIT"
            else -> {
                if (!lower.contains("a/c") && !lower.contains("txn") && !lower.contains("upi")) return null
                "UNKNOWN"
            }
        }

        val bm = BALANCE_PATTERN.matcher(body)
        var balance: Double? = null
        while (bm.find()) {
            val v = bm.group(1)?.replace(",", "")?.toDoubleOrNull()
            if (v != null && v != amount) { balance = v; break }
        }

        val am = ACCOUNT_PATTERN.matcher(body)
        val account = if (am.find()) am.group(1) else null
        return ParsedSms(type, amount, balance, account)
    }
}
