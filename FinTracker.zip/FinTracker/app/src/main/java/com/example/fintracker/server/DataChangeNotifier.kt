package com.example.fintracker.server

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * Singleton change bus.
 * - Repository calls notify() whenever data changes (add, edit, delete, scan)
 * - SSE endpoint sends event to all connected web browsers
 * - Android fragments collect the flow and refresh their UI
 */
object DataChangeNotifier {

    // Flow that fragments observe for live UI refresh
    private val _changes = MutableSharedFlow<String>(extraBufferCapacity = 1)
    val changes = _changes.asSharedFlow()

    // SSE listeners: each is a callback that writes "data: ping\n\n" to the browser
    private val sseListeners = mutableListOf<(String) -> Unit>()

    fun notify(event: String = "update") {
        _changes.tryEmit(event)
        synchronized(sseListeners) {
            sseListeners.toList().forEach { it(event) }
        }
    }

    fun addSseListener(listener: (String) -> Unit) {
        synchronized(sseListeners) { sseListeners.add(listener) }
    }

    fun removeSseListener(listener: (String) -> Unit) {
        synchronized(sseListeners) { sseListeners.remove(listener) }
    }
}
