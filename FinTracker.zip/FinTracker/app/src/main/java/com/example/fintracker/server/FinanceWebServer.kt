package com.example.fintracker.server

import android.content.Context
import com.example.fintracker.data.CsvExporter
import com.example.fintracker.data.FinanceRepository
import fi.iki.elonen.NanoHTTPD
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class FinanceWebServer(
    private val repo: FinanceRepository,
    private val context: Context,
    port: Int = 8080
) : NanoHTTPD(port) {

    override fun serve(session: IHTTPSession): Response {
        return try {
            // Parse POST body if needed
            val body = mutableMapOf<String, String>()
            if (session.method == Method.POST) {
                session.parseBody(body)
            }

            when {
                session.uri == "/" || session.uri == "/index.html" -> serveDashboard()
                session.uri == "/api/events"             -> serveSSE()
                session.uri == "/api/summary"            -> serveJson(getSummary())
                session.uri == "/api/transactions"       -> serveJson(getTransactions(session))
                session.uri == "/api/monthly"            -> serveJson(getMonthly())
                session.uri == "/api/categories"         -> serveJson(getCategories())
                // Edit endpoints (POST)
                session.uri == "/api/update-category"    -> serveJson(updateCategory(body))
                session.uri == "/api/update-transaction" -> serveJson(updateTransaction(body))
                session.uri == "/api/subcategories"      -> serveJson(getSubCategories(session))
                session.uri == "/api/add-subcategory"    -> serveJson(addSubCategory(body))
                session.uri == "/api/delete-subcategory" -> serveJson(deleteSubCategory(body))
                session.uri == "/api/delete-transaction" -> serveJson(deleteTransaction(body))
                session.uri == "/api/add-transaction"    -> serveJson(addTransaction(body))
                session.uri == "/api/set-flag"           -> serveJson(setFlag(body))
                session.uri == "/api/report/yearly"      -> serveJson(getYearlyReport())
                session.uri == "/api/report/flags"       -> serveJson(getFlagsReport())
                session.uri == "/api/report/topmerchants"-> serveJson(getTopMerchants(session))
                session.uri == "/api/report/daily"       -> serveJson(getDailyPattern(session))
                session.uri == "/api/report/subcats"     -> serveJson(getSubCatReport(session))
                session.uri == "/api/learnings"          -> serveJson(getLearnings())
                session.uri.startsWith("/export/")       -> serveCsv(session)
                session.uri == "/api/report-start"       -> serveJson(getReportStart())
                session.uri == "/api/set-report-start"   -> serveJson(setReportStart(body))
                else -> newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "Not found")
            }
        } catch (e: Exception) {
            serveJson("""{"ok":false,"error":"${e.message?.replace("\"","'")}"}""")
        }
    }

    // ── HTML ─────────────────────────────────────────────────────────────────

    private fun serveDashboard(): Response {
        val html = context.assets.open("dashboard.html").bufferedReader().readText()
        val r = newFixedLengthResponse(Response.Status.OK, "text/html", html)
        r.addHeader("Cache-Control", "no-cache")
        return r
    }

    /** Server-Sent Events endpoint — keeps connection open and pushes live updates */
    private fun serveSSE(): Response {
        val pipe = java.io.PipedOutputStream()
        val input = java.io.PipedInputStream(pipe)
        val writer = java.io.PrintWriter(pipe, true)

        val listener: (String) -> Unit = { event ->
            try { writer.write("data: $event\n\n"); writer.flush() } catch (_: Exception) {}
        }

        DataChangeNotifier.addSseListener(listener)

        // Send initial heartbeat
        writer.write("data: connected\n\n")
        writer.flush()

        val r = newChunkedResponse(Response.Status.OK, "text/event-stream", input)
        r.addHeader("Cache-Control", "no-cache")
        r.addHeader("Connection", "keep-alive")
        r.addHeader("Access-Control-Allow-Origin", "*")

        // Remove listener when connection closes (checked via thread)
        Thread {
            try { while (writer.checkError().not()) { Thread.sleep(5000); writer.write(": heartbeat\n\n"); writer.flush() } }
            catch (_: Exception) { }
            finally { DataChangeNotifier.removeSseListener(listener) }
        }.also { it.isDaemon = true }.start()

        return r
    }

    private fun serveJson(json: String): Response {
        val r = newFixedLengthResponse(Response.Status.OK, "application/json", json)
        r.addHeader("Access-Control-Allow-Origin", "*")
        r.addHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        r.addHeader("Access-Control-Allow-Headers", "Content-Type")
        return r
    }

    // ── READ APIs ─────────────────────────────────────────────────────────────

    private fun getSummary(): String = runBlocking {
        val txns      = repo.getCurrentMonthTransactions()
        val all       = repo.getReportTransactions()
        val debit     = txns.filter { it.type == "DEBIT"  }.sumOf { it.amount }
        val credit    = txns.filter { it.type == "CREDIT" }.sumOf { it.amount }
        val allDebit  = all.filter  { it.type == "DEBIT"  }.sumOf { it.amount }
        val allCredit = all.filter  { it.type == "CREDIT" }.sumOf { it.amount }
        val catTotals = repo.categoryTotals(txns)
        val monthly   = repo.getLastNMonthsTotals(6)

        val obj = JSONObject()
        obj.put("thisMonthDebit",    debit)
        obj.put("thisMonthCredit",   credit)
        obj.put("thisMonthNet",      credit - debit)
        obj.put("totalTransactions", all.size)
        obj.put("allTimeDebit",      allDebit)
        obj.put("allTimeCredit",     allCredit)

        val cats = JSONArray()
        catTotals.forEach { (name, amt) ->
            val c = JSONObject(); c.put("name", name); c.put("amount", amt); cats.put(c)
        }
        obj.put("categoryTotals", cats)

        val mon = JSONArray()
        monthly.forEach { (label, d, cr) ->
            val m = JSONObject(); m.put("month", label); m.put("debit", d); m.put("credit", cr); mon.put(m)
        }
        obj.put("monthly", mon)
        obj.toString()
    }

    private fun getTransactions(session: IHTTPSession): String = runBlocking {
        val limit = session.parameters["limit"]?.firstOrNull()?.toIntOrNull() ?: 100
        val fmt   = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        val arr   = JSONArray()
        repo.getAllTransactions().take(limit).forEach { t ->
            val obj = JSONObject()
            obj.put("id",       t.id)
            obj.put("sender",   t.sender)
            obj.put("payee",    t.payee)
            obj.put("date",     fmt.format(Date(t.date)))
            obj.put("type",     t.type)
            obj.put("amount",   t.amount)
            obj.put("category", t.category)
            obj.put("subCategory", t.subCategory)
            obj.put("flag",       t.flag)
            obj.put("balance",  t.balance ?: 0)
            obj.put("note",     t.rawMessage.take(100))
            arr.put(obj)
        }
        arr.toString()
    }

    private fun getMonthly(): String = runBlocking {
        val arr = JSONArray()
        repo.getLastNMonthsTotals(12).forEach { (label, d, cr) ->
            val m = JSONObject(); m.put("month", label); m.put("debit", d); m.put("credit", cr); arr.put(m)
        }
        arr.toString()
    }

    private fun getCategories(): String = runBlocking {
        val arr = JSONArray()
        repo.getCategories().forEach { c ->
            val o = JSONObject(); o.put("name", c.name); o.put("emoji", c.emoji); o.put("color", c.colorHex); arr.put(o)
        }
        arr.toString()
    }

    // ── WRITE APIs ────────────────────────────────────────────────────────────

    private fun getSubCategories(session: IHTTPSession): String = runBlocking {
        val cat = session.parameters["cat"]?.firstOrNull() ?: ""
        val arr = JSONArray()
        repo.getSubCategories(cat).forEach { s ->
            val o = JSONObject(); o.put("id", s.id); o.put("name", s.name); o.put("emoji", s.emoji)
            o.put("keywords", s.keywords); arr.put(o)
        }
        arr.toString()
    }

    /** POST /api/update-transaction  body: {"id":123,"category":"Food","subCategory":"Swiggy","type":"DEBIT"} */
    private fun updateTransaction(body: Map<String, String>): String = runBlocking {
        val json   = JSONObject(body["postData"] ?: return@runBlocking error("No body"))
        val id     = json.getLong("id")
        val cat    = json.getString("category")
        val subCat = json.optString("subCategory", "")
        val type   = json.getString("type")
        if (type !in listOf("DEBIT", "CREDIT", "UNKNOWN")) return@runBlocking error("Invalid type")
        if (cat.isBlank()) return@runBlocking error("Category required")
        val flag   = json.optString("flag", "")
        repo.updateTransactionFull(id, cat, subCat, type, flag)
        """{"ok":true}"""
    }

    /** POST /api/update-category  body: {"id": 123, "category": "Food & Dining"} */
    private fun updateCategory(body: Map<String, String>): String = runBlocking {
        val json = JSONObject(body["postData"] ?: return@runBlocking error("No body"))
        val id   = json.getLong("id")
        val cat  = json.getString("category")
        if (cat.isBlank()) return@runBlocking error("Category required")
        repo.updateCategory(id, cat)   // also triggers smart payee learning
        """{"ok":true}"""
    }

    /** POST /api/delete-transaction  body: {"id": 123} */
    private fun deleteTransaction(body: Map<String, String>): String = runBlocking {
        val json = JSONObject(body["postData"] ?: return@runBlocking error("No body"))
        val id   = json.getLong("id")
        repo.deleteTransaction(id)
        """{"ok":true}"""
    }

    /** POST /api/add-transaction  body: {"type":"DEBIT","amount":500,"category":"Food","note":"Lunch"} */
    private fun addTransaction(body: Map<String, String>): String = runBlocking {
        val json   = JSONObject(body["postData"] ?: return@runBlocking error("No body"))
        val type   = json.getString("type")
        val amount = json.getDouble("amount")
        val cat    = json.getString("category")
        val note   = json.optString("note", "Manual entry from web")

        if (type !in listOf("DEBIT", "CREDIT")) return@runBlocking error("Invalid type")
        if (amount <= 0 || amount > 99_999_999) return@runBlocking error("Invalid amount")
        if (cat.isBlank()) return@runBlocking error("Category required")

        val flag   = json.optString("flag", "")
        repo.addManual(type, amount, cat, note.take(200), flag = flag)
        """{"ok":true}"""
    }

    private fun error(msg: String) = """{"ok":false,"error":"$msg"}"""


    // ── CSV export ───────────────────────────────────────────────────────────

    /** GET /export/{type}.csv — streams a CSV download */
    private fun serveCsv(session: IHTTPSession): Response = runBlocking {
        val kind = session.uri.removePrefix("/export/").removeSuffix(".csv")
        val stamp = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())

        val (csv, name) = when (kind) {
            "transactions" -> CsvExporter.transactions(repo.getReportTransactions()) to "transactions_$stamp.csv"
            "all-transactions" -> CsvExporter.transactions(repo.getAllTransactions()) to "all_transactions_$stamp.csv"
            "categories"   -> CsvExporter.categoryReport(
                                repo.categoryTotals(repo.getReportTransactions())) to "category_report_$stamp.csv"
            "subcategories"-> CsvExporter.subCategoryReport(repo.getReportTransactions()) to "subcategory_report_$stamp.csv"
            "monthly"      -> CsvExporter.trendReport(repo.getLastNMonthsTotals(12), "Month") to "monthly_report_$stamp.csv"
            "weekly"       -> CsvExporter.trendReport(repo.getLastNWeeksTotals(12), "Week") to "weekly_report_$stamp.csv"
            "flags"        -> CsvExporter.flagReport(repo.getReportTransactions()) to "flag_report_$stamp.csv"
            "merchants"    -> CsvExporter.merchantReport(repo.getReportTransactions()) to "merchant_report_$stamp.csv"
            "backup"       -> CsvExporter.backup(
                                repo.getCategories(), repo.getAllSubCategories(),
                                repo.getBudgets(), repo.getSenderMappings()) to "fintracker_backup_$stamp.csv"
            else -> return@runBlocking newFixedLengthResponse(
                Response.Status.NOT_FOUND, MIME_PLAINTEXT, "Unknown export type")
        }

        val r = newFixedLengthResponse(Response.Status.OK, "text/csv; charset=utf-8", csv)
        r.addHeader("Content-Disposition", "attachment; filename=\"$name\"")
        r.addHeader("Access-Control-Allow-Origin", "*")
        r
    }

    /** GET /api/report-start */
    private fun getReportStart(): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val o = JSONObject()
        o.put("millis", repo.reportStart)
        o.put("date", fmt.format(Date(repo.reportStart)))
        return o.toString()
    }

    /** POST /api/set-report-start  body: {"date":"2026-08-01"} */
    private fun setReportStart(body: Map<String, String>): String {
        val json = JSONObject(body["postData"] ?: return error("No body"))
        val dateStr = json.getString("date")
        return try {
            val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val d = fmt.parse(dateStr) ?: return error("Bad date")
            val c = Calendar.getInstance()
            c.time = d
            c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0)
            c.set(Calendar.SECOND, 0);      c.set(Calendar.MILLISECOND, 0)
            repo.setReportStart(c.timeInMillis)
            """{"ok":true}"""
        } catch (e: Exception) { error("Invalid date format, use YYYY-MM-DD") }
    }

    /** POST /api/add-subcategory  body: {"name":"Swiggy","parent":"Food & Dining","keywords":"swiggy","emoji":"🛵"} */
    private fun addSubCategory(body: Map<String, String>): String = runBlocking {
        val json     = JSONObject(body["postData"] ?: return@runBlocking error("No body"))
        val rawName  = json.getString("name").trim()
        val name     = rawName.replace(Regex("[^\\w\\s&\\-]"), "").take(30).trim()
        val parent   = json.getString("parent")
        val keywords = json.optString("keywords", "").take(500).lowercase().trim()
        val emoji    = json.optString("emoji", "").trim().ifEmpty { "📌" }
        if (name.isBlank())   return@runBlocking error("Name required")
        if (parent.isBlank()) return@runBlocking error("Parent category required")
        repo.addSubCategory(name, parent, keywords, emoji)
        """{"ok":true}"""
    }

    /** POST /api/delete-subcategory  body: {"id":5} */
    private fun deleteSubCategory(body: Map<String, String>): String = runBlocking {
        val json = JSONObject(body["postData"] ?: return@runBlocking error("No body"))
        repo.deleteSubCategory(json.getLong("id"))
        """{"ok":true}"""
    }

    private fun getLearnings(): String = runBlocking {
        val arr = JSONArray()
        repo.getSenderMappings().sortedBy { it.sender }.forEach { m ->
            val o = JSONObject(); o.put("payee", m.sender); o.put("category", m.category)
            o.put("learnedAt", java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault()).format(java.util.Date(m.learnedAt)))
            arr.put(o)
        }
        arr.toString()
    }

    /** POST /api/set-flag  body: {"id":123,"flag":"SAVINGS"} */
    private fun setFlag(body: Map<String, String>): String = runBlocking {
        val json = JSONObject(body["postData"] ?: return@runBlocking error("No body"))
        val id   = json.getLong("id")
        val flag = json.optString("flag", "")
        repo.setFlag(id, flag)
        """{"ok":true}"""
    }

    /** GET /api/report/yearly — year-month grid of debit/credit/savings */
    private fun getYearlyReport(): String = runBlocking {
        val all  = repo.getReportTransactions()
        val cal  = android.icu.util.Calendar.getInstance()
        val year = cal.get(android.icu.util.Calendar.YEAR)
        val arr  = JSONArray()
        for (month in 0..11) {
            val c = android.icu.util.Calendar.getInstance()
            c.set(android.icu.util.Calendar.YEAR, year); c.set(android.icu.util.Calendar.MONTH, month)
            c.set(android.icu.util.Calendar.DAY_OF_MONTH, 1); c.set(android.icu.util.Calendar.HOUR_OF_DAY, 0); c.set(android.icu.util.Calendar.MINUTE, 0); c.set(android.icu.util.Calendar.SECOND, 0)
            val start = c.timeInMillis; c.add(android.icu.util.Calendar.MONTH, 1); val end = c.timeInMillis
            val txns = all.filter { it.date >= maxOf(start, repo.reportStart) && it.date < end }
            val debit   = txns.filter { it.type == "DEBIT"  }.sumOf { it.amount }
            val credit  = txns.filter { it.type == "CREDIT" }.sumOf { it.amount }
            val savings = txns.filter { it.flag == "SAVINGS" || it.flag == "INVESTMENT" }.sumOf { it.amount }
            val spend   = txns.filter { it.flag == "SPEND" || it.flag == "NEED" || it.flag == "WANT" }.sumOf { it.amount }
            val o = JSONObject()
            o.put("month", android.text.format.DateFormat.format("MMM", c.time).toString())
            o.put("debit", debit); o.put("credit", credit)
            o.put("savings", savings); o.put("spend", spend)
            o.put("count", txns.size)
            arr.put(o)
        }
        arr.toString()
    }

    /** GET /api/report/flags — breakdown by flag type */
    private fun getFlagsReport(): String = runBlocking {
        val all = repo.getReportTransactions()
        val thisMonth = repo.getCurrentMonthTransactions()
        val flagOrder = listOf("SPEND", "NEED", "WANT", "SAVINGS", "INVESTMENT", "TRANSFER", "")

        fun flagLabel(f: String) = when(f) {
            "SPEND" -> "💸 Spend"; "NEED" -> "✅ Need"; "WANT" -> "🛍️ Want"
            "SAVINGS" -> "💰 Savings"; "INVESTMENT" -> "📈 Investment"
            "TRANSFER" -> "🔄 Transfer"; else -> "🏷️ Untagged"
        }

        val arr = JSONArray()
        flagOrder.forEach { flag ->
            val txns = all.filter { it.flag == flag && it.type == "DEBIT" }
            val monthTxns = thisMonth.filter { it.flag == flag && it.type == "DEBIT" }
            if (txns.isNotEmpty()) {
                val o = JSONObject()
                o.put("flag", flag); o.put("label", flagLabel(flag))
                o.put("total", txns.sumOf { it.amount })
                o.put("thisMonth", monthTxns.sumOf { it.amount })
                o.put("count", txns.size)
                arr.put(o)
            }
        }
        arr.toString()
    }

    /** GET /api/report/topmerchants?limit=10 */
    private fun getTopMerchants(session: IHTTPSession): String = runBlocking {
        val limit = session.parameters["limit"]?.firstOrNull()?.toIntOrNull() ?: 10
        val all = repo.getReportTransactions().filter { it.type == "DEBIT" && it.payee.isNotEmpty() }
        val byPayee = all.groupBy { it.payee }
            .mapValues { (_, list) -> Pair(list.sumOf { it.amount }, list.size) }
            .entries.sortedByDescending { it.value.first }.take(limit)
        val arr = JSONArray()
        byPayee.forEach { (payee, data) ->
            val o = JSONObject()
            o.put("payee", payee.replaceFirstChar { it.uppercase() })
            o.put("total", data.first); o.put("count", data.second)
            arr.put(o)
        }
        arr.toString()
    }

    /** GET /api/report/daily — spending by day of week */
    private fun getDailyPattern(session: IHTTPSession): String = runBlocking {
        val all = repo.getReportTransactions().filter { it.type == "DEBIT" }
        val cal = java.util.Calendar.getInstance()
        val days = arrayOf("Sun","Mon","Tue","Wed","Thu","Fri","Sat")
        val totals = DoubleArray(7)
        val counts = IntArray(7)
        all.forEach { t ->
            cal.timeInMillis = t.date
            val dow = cal.get(java.util.Calendar.DAY_OF_WEEK) - 1
            totals[dow] += t.amount; counts[dow]++
        }
        val arr = JSONArray()
        for (i in 0..6) {
            val o = JSONObject(); o.put("day", days[i]); o.put("total", totals[i]); o.put("count", counts[i]); arr.put(o)
        }
        arr.toString()
    }

    /** GET /api/report/subcats?cat=Food+%26+Dining */
    private fun getSubCatReport(session: IHTTPSession): String = runBlocking {
        val cat = session.parameters["cat"]?.firstOrNull() ?: ""
        val all = repo.getReportTransactions().filter { it.type == "DEBIT" && (cat.isEmpty() || it.category == cat) }
        val bySub = all.groupBy { it.subCategory.ifEmpty { "Uncategorized" } }
            .mapValues { (_, l) -> l.sumOf { it.amount } }
            .entries.sortedByDescending { it.value }
        val arr = JSONArray()
        bySub.forEach { (sub, amt) ->
            val o = JSONObject(); o.put("subCategory", sub); o.put("amount", amt); arr.put(o)
        }
        arr.toString()
    }
}
