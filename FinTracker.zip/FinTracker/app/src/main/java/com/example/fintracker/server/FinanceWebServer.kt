package com.example.fintracker.server

import android.content.Context
import com.example.fintracker.data.FinanceRepository
import fi.iki.elonen.NanoHTTPD
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class FinanceWebServer(
    private val repo: FinanceRepository,
    private val context: Context,
    port: Int = 8080
) : NanoHTTPD(port) {

    override fun serve(session: IHTTPSession): Response {
        return try {
            when {
                session.uri == "/" || session.uri == "/index.html" -> serveDashboard()
                session.uri == "/api/summary"      -> serveJson(getSummary())
                session.uri == "/api/transactions" -> serveJson(getTransactions(session))
                session.uri == "/api/monthly"      -> serveJson(getMonthly())
                session.uri == "/api/categories"   -> serveJson(getCategories())
                else -> newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "Not found")
            }
        } catch (e: Exception) {
            newFixedLengthResponse(Response.Status.INTERNAL_ERROR, MIME_PLAINTEXT, e.message ?: "Error")
        }
    }

    private fun serveDashboard(): Response {
        val html = context.assets.open("dashboard.html").bufferedReader().readText()
        val r = newFixedLengthResponse(Response.Status.OK, "text/html", html)
        r.addHeader("Cache-Control", "no-cache")
        return r
    }

    private fun serveJson(json: String): Response {
        val r = newFixedLengthResponse(Response.Status.OK, "application/json", json)
        r.addHeader("Access-Control-Allow-Origin", "*")
        return r
    }

    private fun getSummary(): String = runBlocking {
        val txns = repo.getCurrentMonthTransactions()
        val all  = repo.getAllTransactions()
        val debit  = txns.filter { it.type == "DEBIT"  }.sumOf { it.amount }
        val credit = txns.filter { it.type == "CREDIT" }.sumOf { it.amount }
        val allDebit  = all.filter { it.type == "DEBIT"  }.sumOf { it.amount }
        val allCredit = all.filter { it.type == "CREDIT" }.sumOf { it.amount }
        val catTotals = repo.categoryTotals(txns)
        val monthly   = repo.getLastNMonthsTotals(6)

        val obj = JSONObject()
        obj.put("thisMonthDebit",  debit)
        obj.put("thisMonthCredit", credit)
        obj.put("thisMonthNet",    credit - debit)
        obj.put("totalTransactions", all.size)
        obj.put("allTimeDebit",  allDebit)
        obj.put("allTimeCredit", allCredit)

        val cats = JSONArray()
        catTotals.forEach { (name, amt) ->
            val c = JSONObject(); c.put("name", name); c.put("amount", amt); cats.put(c)
        }
        obj.put("categoryTotals", cats)

        val mon = JSONArray()
        monthly.forEach { (label, d, cr) ->
            val m = JSONObject(); m.put("month", label); m.put("debit", d); m.put("credit", cr); mon.put(m)
        }
        obj.put("monthly", mon)
        obj.toString()
    }

    private fun getTransactions(session: IHTTPSession): String = runBlocking {
        val limit = session.parameters["limit"]?.firstOrNull()?.toIntOrNull() ?: 50
        val txns  = repo.getAllTransactions().take(limit)
        val fmt   = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        val arr   = JSONArray()
        txns.forEach { t ->
            val obj = JSONObject()
            obj.put("id",       t.id)
            obj.put("sender",   t.sender)
            obj.put("payee",    t.payee)
            obj.put("date",     fmt.format(Date(t.date)))
            obj.put("type",     t.type)
            obj.put("amount",   t.amount)
            obj.put("category", t.category)
            obj.put("balance",  t.balance ?: 0)
            obj.put("note",     t.rawMessage.take(80))
            arr.put(obj)
        }
        arr.toString()
    }

    private fun getMonthly(): String = runBlocking {
        val monthly = repo.getLastNMonthsTotals(12)
        val arr = JSONArray()
        monthly.forEach { (label, d, cr) ->
            val m = JSONObject(); m.put("month", label); m.put("debit", d); m.put("credit", cr); arr.put(m)
        }
        arr.toString()
    }

    private fun getCategories(): String = runBlocking {
        val arr = JSONArray()
        repo.getCategories().forEach { c ->
            val o = JSONObject(); o.put("name", c.name); o.put("emoji", c.emoji); o.put("color", c.colorHex); arr.put(o)
        }
        arr.toString()
    }
}
