package com.example.fintracker.server

import android.content.Context
import com.example.fintracker.data.FinanceRepository
import fi.iki.elonen.NanoHTTPD
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class FinanceWebServer(
    private val repo: FinanceRepository,
    private val context: Context,
    port: Int = 8080
) : NanoHTTPD(port) {

    override fun serve(session: IHTTPSession): Response {
        return try {
            // Parse POST body if needed
            val body = mutableMapOf<String, String>()
            if (session.method == Method.POST) {
                session.parseBody(body)
            }

            when {
                session.uri == "/" || session.uri == "/index.html" -> serveDashboard()
                session.uri == "/api/summary"            -> serveJson(getSummary())
                session.uri == "/api/transactions"       -> serveJson(getTransactions(session))
                session.uri == "/api/monthly"            -> serveJson(getMonthly())
                session.uri == "/api/categories"         -> serveJson(getCategories())
                // Edit endpoints (POST)
                session.uri == "/api/update-category"    -> serveJson(updateCategory(body))
                session.uri == "/api/delete-transaction" -> serveJson(deleteTransaction(body))
                session.uri == "/api/add-transaction"    -> serveJson(addTransaction(body))
                else -> newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "Not found")
            }
        } catch (e: Exception) {
            serveJson("""{"ok":false,"error":"${e.message?.replace("\"","'")}"}""")
        }
    }

    // ── HTML ─────────────────────────────────────────────────────────────────

    private fun serveDashboard(): Response {
        val html = context.assets.open("dashboard.html").bufferedReader().readText()
        val r = newFixedLengthResponse(Response.Status.OK, "text/html", html)
        r.addHeader("Cache-Control", "no-cache")
        return r
    }

    private fun serveJson(json: String): Response {
        val r = newFixedLengthResponse(Response.Status.OK, "application/json", json)
        r.addHeader("Access-Control-Allow-Origin", "*")
        r.addHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        r.addHeader("Access-Control-Allow-Headers", "Content-Type")
        return r
    }

    // ── READ APIs ─────────────────────────────────────────────────────────────

    private fun getSummary(): String = runBlocking {
        val txns      = repo.getCurrentMonthTransactions()
        val all       = repo.getAllTransactions()
        val debit     = txns.filter { it.type == "DEBIT"  }.sumOf { it.amount }
        val credit    = txns.filter { it.type == "CREDIT" }.sumOf { it.amount }
        val allDebit  = all.filter  { it.type == "DEBIT"  }.sumOf { it.amount }
        val allCredit = all.filter  { it.type == "CREDIT" }.sumOf { it.amount }
        val catTotals = repo.categoryTotals(txns)
        val monthly   = repo.getLastNMonthsTotals(6)

        val obj = JSONObject()
        obj.put("thisMonthDebit",    debit)
        obj.put("thisMonthCredit",   credit)
        obj.put("thisMonthNet",      credit - debit)
        obj.put("totalTransactions", all.size)
        obj.put("allTimeDebit",      allDebit)
        obj.put("allTimeCredit",     allCredit)

        val cats = JSONArray()
        catTotals.forEach { (name, amt) ->
            val c = JSONObject(); c.put("name", name); c.put("amount", amt); cats.put(c)
        }
        obj.put("categoryTotals", cats)

        val mon = JSONArray()
        monthly.forEach { (label, d, cr) ->
            val m = JSONObject(); m.put("month", label); m.put("debit", d); m.put("credit", cr); mon.put(m)
        }
        obj.put("monthly", mon)
        obj.toString()
    }

    private fun getTransactions(session: IHTTPSession): String = runBlocking {
        val limit = session.parameters["limit"]?.firstOrNull()?.toIntOrNull() ?: 100
        val fmt   = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        val arr   = JSONArray()
        repo.getAllTransactions().take(limit).forEach { t ->
            val obj = JSONObject()
            obj.put("id",       t.id)
            obj.put("sender",   t.sender)
            obj.put("payee",    t.payee)
            obj.put("date",     fmt.format(Date(t.date)))
            obj.put("type",     t.type)
            obj.put("amount",   t.amount)
            obj.put("category", t.category)
            obj.put("balance",  t.balance ?: 0)
            obj.put("note",     t.rawMessage.take(100))
            arr.put(obj)
        }
        arr.toString()
    }

    private fun getMonthly(): String = runBlocking {
        val arr = JSONArray()
        repo.getLastNMonthsTotals(12).forEach { (label, d, cr) ->
            val m = JSONObject(); m.put("month", label); m.put("debit", d); m.put("credit", cr); arr.put(m)
        }
        arr.toString()
    }

    private fun getCategories(): String = runBlocking {
        val arr = JSONArray()
        repo.getCategories().forEach { c ->
            val o = JSONObject(); o.put("name", c.name); o.put("emoji", c.emoji); o.put("color", c.colorHex); arr.put(o)
        }
        arr.toString()
    }

    // ── WRITE APIs ────────────────────────────────────────────────────────────

    /** POST /api/update-category  body: {"id": 123, "category": "Food & Dining"} */
    private fun updateCategory(body: Map<String, String>): String = runBlocking {
        val json = JSONObject(body["postData"] ?: return@runBlocking error("No body"))
        val id   = json.getLong("id")
        val cat  = json.getString("category")
        if (cat.isBlank()) return@runBlocking error("Category required")
        repo.updateCategory(id, cat)   // also triggers smart payee learning
        """{"ok":true}"""
    }

    /** POST /api/delete-transaction  body: {"id": 123} */
    private fun deleteTransaction(body: Map<String, String>): String = runBlocking {
        val json = JSONObject(body["postData"] ?: return@runBlocking error("No body"))
        val id   = json.getLong("id")
        repo.deleteTransaction(id)
        """{"ok":true}"""
    }

    /** POST /api/add-transaction  body: {"type":"DEBIT","amount":500,"category":"Food","note":"Lunch"} */
    private fun addTransaction(body: Map<String, String>): String = runBlocking {
        val json   = JSONObject(body["postData"] ?: return@runBlocking error("No body"))
        val type   = json.getString("type")
        val amount = json.getDouble("amount")
        val cat    = json.getString("category")
        val note   = json.optString("note", "Manual entry from web")

        if (type !in listOf("DEBIT", "CREDIT")) return@runBlocking error("Invalid type")
        if (amount <= 0 || amount > 99_999_999) return@runBlocking error("Invalid amount")
        if (cat.isBlank()) return@runBlocking error("Category required")

        repo.addManual(type, amount, cat, note.take(200))
        """{"ok":true}"""
    }

    private fun error(msg: String) = """{"ok":false,"error":"$msg"}"""
}
