package com.example.fintracker.server

import com.example.fintracker.data.FinanceRepository
import fi.iki.elonen.NanoHTTPD
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class FinanceWebServer(private val repo: FinanceRepository, port: Int = 8080) : NanoHTTPD(port) {

    override fun serve(session: IHTTPSession): Response {
        return try {
            when {
                session.uri == "/" || session.uri == "/index.html" -> serveHtml()
                session.uri == "/api/summary" -> serveJson(getSummary())
                session.uri == "/api/transactions" -> serveJson(getTransactions(session))
                session.uri == "/api/monthly" -> serveJson(getMonthly())
                session.uri == "/api/categories" -> serveJson(getCategories())
                else -> newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "Not found")
            }
        } catch (e: Exception) {
            newFixedLengthResponse(Response.Status.INTERNAL_ERROR, MIME_PLAINTEXT, e.message ?: "Error")
        }
    }

    private fun serveJson(json: String): Response {
        val r = newFixedLengthResponse(Response.Status.OK, "application/json", json)
        r.addHeader("Access-Control-Allow-Origin", "*")
        return r
    }

    private fun serveHtml(): Response {
        val html = buildDashboardHtml()
        val r = newFixedLengthResponse(Response.Status.OK, "text/html", html)
        r.addHeader("Cache-Control", "no-cache")
        return r
    }

    private fun getSummary(): String = runBlocking {
        val txns = repo.getCurrentMonthTransactions()
        val all = repo.getAllTransactions()
        val debit = txns.filter { it.type == "DEBIT" }.sumOf { it.amount }
        val credit = txns.filter { it.type == "CREDIT" }.sumOf { it.amount }
        val allDebit = all.filter { it.type == "DEBIT" }.sumOf { it.amount }
        val allCredit = all.filter { it.type == "CREDIT" }.sumOf { it.amount }
        val catTotals = repo.categoryTotals(txns)
        val monthly = repo.getLastNMonthsTotals(6)

        val obj = JSONObject()
        obj.put("thisMonthDebit", debit)
        obj.put("thisMonthCredit", credit)
        obj.put("thisMonthNet", credit - debit)
        obj.put("totalTransactions", all.size)
        obj.put("allTimeDebit", allDebit)
        obj.put("allTimeCredit", allCredit)

        val cats = JSONArray()
        catTotals.forEach { (name, amt) ->
            val c = JSONObject(); c.put("name", name); c.put("amount", amt); cats.put(c)
        }
        obj.put("categoryTotals", cats)

        val mon = JSONArray()
        monthly.forEach { (label, d, cr) ->
            val m = JSONObject(); m.put("month", label); m.put("debit", d); m.put("credit", cr); mon.put(m)
        }
        obj.put("monthly", mon)
        obj.toString()
    }

    private fun getTransactions(session: IHTTPSession): String = runBlocking {
        val params = session.parameters
        val limit = params["limit"]?.firstOrNull()?.toIntOrNull() ?: 50
        val txns = repo.getAllTransactions().take(limit)
        val fmt = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        val arr = JSONArray()
        txns.forEach { t ->
            val obj = JSONObject()
            obj.put("id", t.id)
            obj.put("sender", t.sender)
            obj.put("date", fmt.format(Date(t.date)))
            obj.put("type", t.type)
            obj.put("amount", t.amount)
            obj.put("category", t.category)
            obj.put("balance", t.balance ?: 0)
            obj.put("note", t.rawMessage.take(80))
            arr.put(obj)
        }
        arr.toString()
    }

    private fun getMonthly(): String = runBlocking {
        val monthly = repo.getLastNMonthsTotals(12)
        val arr = JSONArray()
        monthly.forEach { (label, d, cr) ->
            val m = JSONObject(); m.put("month", label); m.put("debit", d); m.put("credit", cr); arr.put(m)
        }
        arr.toString()
    }

    private fun getCategories(): String = runBlocking {
        val cats = repo.getCategories()
        val arr = JSONArray()
        cats.forEach { c ->
            val obj = JSONObject()
            obj.put("name", c.name); obj.put("emoji", c.emoji); obj.put("color", c.colorHex)
            arr.put(obj)
        }
        arr.toString()
    }

    private fun buildDashboardHtml(): String = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Finance Tracker Dashboard</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
         background: #F0F4F8; color: #1A1A2E; }
  .header { background: #1976D2; color: white; padding: 16px 24px;
            display: flex; align-items: center; justify-content: space-between; }
  .header h1 { font-size: 22px; }
  .header .subtitle { font-size: 12px; opacity: 0.8; }
  .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
  .cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }
  .card { background: white; border-radius: 14px; padding: 18px;
          box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
  .card .label { font-size: 12px; color: #9E9E9E; margin-bottom: 6px; }
  .card .value { font-size: 22px; font-weight: bold; }
  .card.red { background: #C62828; color: white; }
  .card.red .label { color: #FFCDD2; }
  .card.green { background: #2E7D32; color: white; }
  .card.green .label { color: #C8E6C9; }
  .card.blue { background: #1565C0; color: white; }
  .card.blue .label { color: #BBDEFB; }
  .row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 24px; }
  @media (max-width: 768px) { .row { grid-template-columns: 1fr; } }
  .chart-card { background: white; border-radius: 14px; padding: 20px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
  .chart-card h3 { font-size: 15px; font-weight: 600; margin-bottom: 16px; color: #424242; }
  .table-card { background: white; border-radius: 14px; padding: 20px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 24px; }
  .table-card h3 { font-size: 15px; font-weight: 600; margin-bottom: 16px; color: #424242; }
  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th { text-align: left; padding: 10px 12px; background: #F5F5F5;
       color: #757575; font-weight: 600; border-bottom: 1px solid #E0E0E0; }
  td { padding: 10px 12px; border-bottom: 1px solid #F5F5F5; }
  tr:hover td { background: #F9F9F9; }
  .badge { display: inline-block; padding: 2px 10px; border-radius: 12px;
           font-size: 11px; font-weight: 600; }
  .badge.debit { background: #FFEBEE; color: #C62828; }
  .badge.credit { background: #E8F5E9; color: #2E7D32; }
  .amount.debit { color: #C62828; font-weight: 600; }
  .amount.credit { color: #2E7D32; font-weight: 600; }
  .refresh-btn { background: rgba(255,255,255,0.2); border: 1px solid rgba(255,255,255,0.5);
                 color: white; padding: 8px 16px; border-radius: 8px; cursor: pointer;
                 font-size: 13px; }
  .refresh-btn:hover { background: rgba(255,255,255,0.3); }
  .cat-row { display: flex; align-items: center; margin-bottom: 10px; }
  .cat-bar-wrap { flex: 1; margin: 0 12px; background: #F5F5F5; border-radius: 4px; height: 8px; }
  .cat-bar { height: 8px; border-radius: 4px; }
  .cat-pct { font-size: 11px; color: #9E9E9E; width: 36px; text-align: right; }
  .cat-amt { font-size: 13px; font-weight: 600; color: #C62828; width: 90px; text-align: right; }
  .loading { text-align: center; padding: 40px; color: #9E9E9E; }
  .filter-row { display: flex; gap: 10px; margin-bottom: 16px; flex-wrap: wrap; }
  select, input { padding: 8px 12px; border: 1px solid #E0E0E0; border-radius: 8px;
                  font-size: 13px; outline: none; background: white; }
  select:focus, input:focus { border-color: #1976D2; }
</style>
</head>
<body>
<div class="header">
  <div>
    <h1>💰 Finance Tracker</h1>
    <div class="subtitle">Local Dashboard — Connected via WiFi</div>
  </div>
  <button class="refresh-btn" onclick="loadAll()">🔄 Refresh</button>
</div>

<div class="container">
  <!-- Summary Cards -->
  <div class="cards" id="summaryCards">
    <div class="loading">Loading...</div>
  </div>

  <!-- Charts Row -->
  <div class="row">
    <div class="chart-card">
      <h3>📊 Monthly Spend (Last 6 Months)</h3>
      <canvas id="barChart" height="200"></canvas>
    </div>
    <div class="chart-card">
      <h3>🥧 This Month by Category</h3>
      <canvas id="pieChart" height="200"></canvas>
    </div>
  </div>

  <!-- Category Breakdown -->
  <div class="chart-card" style="margin-bottom:24px">
    <h3>🏷️ This Month — Category Breakdown</h3>
    <div id="catBreakdown"><div class="loading">Loading...</div></div>
  </div>

  <!-- Transactions Table -->
  <div class="table-card">
    <h3>📋 Recent Transactions</h3>
    <div class="filter-row">
      <select id="filterType" onchange="filterTable()">
        <option value="">All Types</option>
        <option value="DEBIT">Debit</option>
        <option value="CREDIT">Credit</option>
      </select>
      <input type="text" id="filterSearch" placeholder="Search sender / category..."
             oninput="filterTable()">
    </div>
    <div style="overflow-x:auto">
      <table>
        <thead>
          <tr><th>Date</th><th>Sender</th><th>Type</th><th>Amount</th><th>Category</th><th>Note</th></tr>
        </thead>
        <tbody id="txnTable"><tr><td colspan="6" style="text-align:center;padding:20px;color:#9E9E9E">Loading...</td></tr></tbody>
      </table>
    </div>
  </div>
</div>

<script>
let allTxns = [];
let barChartInst = null;
let pieChartInst = null;
const COLORS = ['#FF7043','#AB47BC','#5C6BC0','#26A69A','#EC407A','#42A5F5','#66BB6A','#FF9800','#9E9E9E','#8D6E63'];

async function loadAll() {
  try {
    const [summary, txns] = await Promise.all([
      fetch('/api/summary').then(r => r.json()),
      fetch('/api/transactions?limit=200').then(r => r.json())
    ]);
    allTxns = txns;
    renderSummary(summary);
    renderCharts(summary);
    renderCategoryBreakdown(summary.categoryTotals);
    renderTable(txns);
  } catch(e) {
    document.getElementById('summaryCards').innerHTML =
      '<div style="color:red;padding:20px">Error loading data: ' + e.message + '</div>';
  }
}

function fmt(n) {
  return '₹' + Number(n).toLocaleString('en-IN', {maximumFractionDigits: 0});
}

function renderSummary(s) {
  document.getElementById('summaryCards').innerHTML = `
    <div class="card red"><div class="label">This Month Debit</div><div class="value">${fmt(s.thisMonthDebit)}</div></div>
    <div class="card green"><div class="label">This Month Credit</div><div class="value">${fmt(s.thisMonthCredit)}</div></div>
    <div class="card ${s.thisMonthNet >= 0 ? 'blue' : 'red'}">
      <div class="label">Net Savings</div>
      <div class="value">${s.thisMonthNet >= 0 ? '+' : ''}${fmt(s.thisMonthNet)}</div>
    </div>
    <div class="card"><div class="label">Total Transactions</div><div class="value">${s.totalTransactions}</div></div>
    <div class="card"><div class="label">All Time Debit</div><div class="value" style="font-size:18px">${fmt(s.allTimeDebit)}</div></div>
    <div class="card"><div class="label">All Time Credit</div><div class="value" style="font-size:18px">${fmt(s.allTimeCredit)}</div></div>
  `;
}

function renderCharts(s) {
  // Bar chart
  if (barChartInst) barChartInst.destroy();
  const bCtx = document.getElementById('barChart').getContext('2d');
  barChartInst = new Chart(bCtx, {
    type: 'bar',
    data: {
      labels: s.monthly.map(m => m.month),
      datasets: [
        { label: 'Debit', data: s.monthly.map(m => m.debit), backgroundColor: '#EF5350' },
        { label: 'Credit', data: s.monthly.map(m => m.credit), backgroundColor: '#66BB6A' }
      ]
    },
    options: { responsive: true, plugins: { legend: { position: 'top' } },
               scales: { y: { ticks: { callback: v => '₹' + (v/1000).toFixed(0) + 'K' } } } }
  });

  // Pie chart
  if (pieChartInst) pieChartInst.destroy();
  const pCtx = document.getElementById('pieChart').getContext('2d');
  pieChartInst = new Chart(pCtx, {
    type: 'doughnut',
    data: {
      labels: s.categoryTotals.map(c => c.name),
      datasets: [{ data: s.categoryTotals.map(c => c.amount), backgroundColor: COLORS }]
    },
    options: { responsive: true, plugins: { legend: { position: 'bottom', labels: { font: { size: 11 } } } } }
  });
}

function renderCategoryBreakdown(cats) {
  if (!cats || cats.length === 0) {
    document.getElementById('catBreakdown').innerHTML = '<p style="color:#9E9E9E">No data</p>';
    return;
  }
  const grand = cats.reduce((s, c) => s + c.amount, 0);
  document.getElementById('catBreakdown').innerHTML = cats.map((c, i) => {
    const pct = grand > 0 ? Math.round((c.amount / grand) * 100) : 0;
    return `<div class="cat-row">
      <span style="width:120px;font-size:13px">${c.name}</span>
      <div class="cat-bar-wrap"><div class="cat-bar" style="width:${pct}%;background:${COLORS[i % COLORS.length]}"></div></div>
      <span class="cat-pct">${pct}%</span>
      <span class="cat-amt">${fmt(c.amount)}</span>
    </div>`;
  }).join('');
}

function renderTable(txns) {
  if (!txns.length) {
    document.getElementById('txnTable').innerHTML =
      '<tr><td colspan="6" style="text-align:center;padding:20px;color:#9E9E9E">No transactions</td></tr>';
    return;
  }
  document.getElementById('txnTable').innerHTML = txns.map(t => `
    <tr>
      <td style="white-space:nowrap;font-size:12px">${t.date}</td>
      <td style="font-weight:600">${t.sender}</td>
      <td><span class="badge ${t.type.toLowerCase()}">${t.type}</span></td>
      <td class="amount ${t.type.toLowerCase()}">${t.type === 'DEBIT' ? '-' : '+'}${fmt(t.amount)}</td>
      <td>${t.category}</td>
      <td style="color:#9E9E9E;font-size:12px;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${t.note}</td>
    </tr>
  `).join('');
}

function filterTable() {
  const type = document.getElementById('filterType').value;
  const search = document.getElementById('filterSearch').value.toLowerCase();
  const filtered = allTxns.filter(t => {
    const matchType = !type || t.type === type;
    const matchSearch = !search || t.sender.toLowerCase().includes(search) ||
                        t.category.toLowerCase().includes(search) ||
                        t.note.toLowerCase().includes(search);
    return matchType && matchSearch;
  });
  renderTable(filtered);
}

loadAll();
// Auto-refresh every 30 seconds
setInterval(loadAll, 30000);
</script>
</body>
</html>
""".trimIndent()
}
