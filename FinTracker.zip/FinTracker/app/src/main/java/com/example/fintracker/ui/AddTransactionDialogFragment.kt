package com.example.fintracker.ui
import android.app.Dialog
import android.os.Bundle
import android.widget.*
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.lifecycleScope
import com.example.fintracker.R
import com.example.fintracker.data.FinanceRepository
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.launch

class AddTransactionDialogFragment : DialogFragment() {
    override fun onCreateDialog(s: Bundle?): Dialog {
        val repo = FinanceRepository(requireContext())
        val v = layoutInflater.inflate(R.layout.dialog_add_transaction, null)
        val dialog = BottomSheetDialog(requireContext())
        dialog.setContentView(v)
        val spinner = v.findViewById<Spinner>(R.id.spinnerCategory)
        val etAmount = v.findViewById<TextInputEditText>(R.id.etAmount)
        val etNote = v.findViewById<TextInputEditText>(R.id.etNote)
        val rbDebit = v.findViewById<RadioButton>(R.id.rbDebit)
        lifecycleScope.launch {
            val cats = repo.getCategories()
            spinner.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, cats.map { "${it.emoji} ${it.name}" })
        }
        v.findViewById<android.widget.Button>(R.id.btnSave).setOnClickListener {
            val amount = etAmount.text?.toString()?.toDoubleOrNull()
            if (amount == null || amount <= 0 || amount > 99_999_999) {
                Toast.makeText(requireContext(), "Enter a valid amount", Toast.LENGTH_SHORT).show(); return@setOnClickListener
            }
            val note = etNote.text?.toString()?.trim()?.take(200)?.takeIf { it.isNotBlank() } ?: "Manual entry"
            lifecycleScope.launch {
                val cats = repo.getCategories()
                val cat = cats.getOrNull(spinner.selectedItemPosition)?.name ?: "Others"
                val type = if (rbDebit.isChecked) "DEBIT" else "CREDIT"
                repo.addManual(type, amount, cat, note)
                (parentFragment as? TransactionsFragment)?.loadList()
                dialog.dismiss()
            }
        }
        return dialog
    }
}
