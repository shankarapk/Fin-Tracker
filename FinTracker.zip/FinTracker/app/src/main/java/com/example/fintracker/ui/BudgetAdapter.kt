package com.example.fintracker.ui

import android.content.res.ColorStateList
import android.graphics.Color
import android.view.*
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import com.example.fintracker.R
import com.example.fintracker.data.CategoryEntity

class BudgetAdapter(
    private val cats: List<CategoryEntity>,
    private val progress: Map<String, Triple<Double, Double, Double?>>,
    private val onClick: (CategoryEntity) -> Unit
) : RecyclerView.Adapter<BudgetAdapter.VH>() {

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val emoji: TextView = v.findViewById(R.id.tvEmoji)
        val cat: TextView = v.findViewById(R.id.tvCategory)
        val amounts: TextView = v.findViewById(R.id.tvAmounts)
        val bar: ProgressBar = v.findViewById(R.id.progressBar)
        val alert: TextView = v.findViewById(R.id.tvAlert)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_budget, p, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        val cat = cats[pos]
        val (spent, _, limit) = progress[cat.name] ?: Triple(0.0, 0.0, null)

        h.emoji.text = cat.emoji.ifEmpty { "📦" }
        h.cat.text = cat.name

        if (limit != null) {
            val pct = ((spent / limit) * 100).toInt().coerceIn(0, 100)
            h.bar.visibility = View.VISIBLE
            h.bar.progress = pct
            h.amounts.text = "₹${"%,.0f".format(spent)} / ₹${"%,.0f".format(limit)}"
            when {
                spent > limit -> {
                    h.alert.visibility = View.VISIBLE
                    h.alert.text = "⚠️ Over budget by ₹${"%,.0f".format(spent - limit)}"
                    h.bar.progressTintList = ColorStateList.valueOf(Color.parseColor("#D32F2F"))
                }
                pct >= 80 -> {
                    h.alert.visibility = View.VISIBLE
                    h.alert.setTextColor(Color.parseColor("#F57C00"))
                    h.alert.text = "⚡ ${pct}% used — approaching limit"
                    h.bar.progressTintList = ColorStateList.valueOf(Color.parseColor("#FF9800"))
                }
                else -> {
                    h.alert.visibility = View.GONE
                    h.bar.progressTintList = ColorStateList.valueOf(Color.parseColor("#2E7D32"))
                }
            }
        } else {
            h.bar.progress = 0
            h.bar.visibility = if (spent > 0) View.VISIBLE else View.GONE
            h.amounts.text = if (spent > 0) "₹${"%,.0f".format(spent)} spent • tap to set limit" else "Tap to set limit"
            h.alert.visibility = View.GONE
        }
        h.itemView.setOnClickListener { onClick(cat) }
    }

    override fun getItemCount() = cats.size
}
