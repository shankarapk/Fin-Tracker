package com.example.fintracker.ui
import android.app.AlertDialog; import android.os.Bundle; import android.view.*; import android.widget.*
import androidx.fragment.app.Fragment; import androidx.lifecycle.lifecycleScope; import androidx.recyclerview.widget.LinearLayoutManager; import androidx.recyclerview.widget.RecyclerView
import com.example.fintracker.R; import com.example.fintracker.data.FinanceRepository; import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.launch

class BudgetsFragment : Fragment() {
    private lateinit var repo: FinanceRepository
    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?) = i.inflate(R.layout.fragment_budgets, c, false)
    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s); repo = FinanceRepository(requireContext())
        val rv = v.findViewById<RecyclerView>(R.id.recyclerView); rv.layoutManager = LinearLayoutManager(requireContext())
        v.findViewById<MaterialButton>(R.id.btnManageCategories).setOnClickListener { showCategoryManager() }
        loadData(rv)
    }
    private fun loadData(rv: RecyclerView) {
        lifecycleScope.launch {
            val cats = repo.getCategories(); val progress = repo.getBudgetProgress()
            rv.adapter = BudgetAdapter(cats, progress) { cat ->
                val input = EditText(requireContext()); input.hint = "Monthly limit (₹)"; input.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
                progress[cat.name]?.third?.let { input.setText(it.toString()) }
                AlertDialog.Builder(requireContext()).setTitle("${cat.emoji} ${cat.name} Budget").setView(input)
                    .setPositiveButton("Save") { _, _ -> val value = input.text.toString().toDoubleOrNull(); if (value != null && value > 0) lifecycleScope.launch { repo.setBudget(cat.name, value); loadData(rv) } }
                    .setNegativeButton("Remove") { _, _ -> lifecycleScope.launch { repo.deleteBudget(cat.name); loadData(rv) } }
                    .setNeutralButton("Cancel", null).show()
            }
        }
    }
    private fun showCategoryManager() {
        lifecycleScope.launch {
            val cats = repo.getCategories(); val defaultCats = listOf("Food & Dining","Shopping","Bills & Utilities","Transport","Entertainment","Health","Transfer","Salary & Income","Groceries","Others")
            AlertDialog.Builder(requireContext()).setTitle("Manage Categories")
                .setItems(cats.map { "${it.emoji} ${it.name}" }.toTypedArray()) { _, idx ->
                    val cat = cats[idx]
                    if (cat.name in defaultCats) { Toast.makeText(requireContext(), "Default categories cannot be deleted", Toast.LENGTH_SHORT).show(); return@setItems }
                    AlertDialog.Builder(requireContext()).setTitle("Delete '${cat.name}'?").setMessage("Transactions will move to 'Others'.")
                        .setPositiveButton("Delete") { _, _ -> lifecycleScope.launch { repo.deleteCategory(cat.name); view?.findViewById<RecyclerView>(R.id.recyclerView)?.let { loadData(it) }; Toast.makeText(requireContext(), "'${cat.name}' deleted", Toast.LENGTH_SHORT).show() } }
                        .setNegativeButton("Cancel", null).show()
                }
                .setPositiveButton("➕ Add New") { _, _ -> showAddCategoryDialog() }.setNegativeButton("Close", null).show()
        }
    }
    private fun showAddCategoryDialog() {
        val v = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_category, null)
        AlertDialog.Builder(requireContext()).setTitle("Add New Category").setView(v)
            .setPositiveButton("Save") { _, _ ->
                val raw = v.findViewById<EditText>(R.id.etCatName).text.toString().trim()
                val name = raw.replace(Regex("[^\\w\\s&\\-]"), "").take(30).trim()
                val keywords = v.findViewById<EditText>(R.id.etKeywords).text.toString().take(500).trim()
                val emoji = v.findViewById<EditText>(R.id.etEmoji).text.toString().trim().ifEmpty { "📦" }
                if (name.isBlank()) { Toast.makeText(requireContext(), "Name required", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                lifecycleScope.launch { repo.addCategory(name, keywords.lowercase(), "#9E9E9E", emoji); view?.findViewById<RecyclerView>(R.id.recyclerView)?.let { loadData(it) }; Toast.makeText(requireContext(), "'$name' added!", Toast.LENGTH_SHORT).show() }
            }.setNegativeButton("Cancel", null).show()
    }
    override fun onResume() { super.onResume(); view?.findViewById<RecyclerView>(R.id.recyclerView)?.let { loadData(it) } }
}
