package com.example.fintracker.ui

import android.app.AlertDialog
import android.os.Bundle
import android.view.*
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.fintracker.R
import com.example.fintracker.data.FinanceRepository
import kotlinx.coroutines.launch

class BudgetsFragment : Fragment() {
    private lateinit var repo: FinanceRepository

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?) =
        i.inflate(R.layout.fragment_budgets, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        repo = FinanceRepository(requireContext())
        val rv = v.findViewById<RecyclerView>(R.id.recyclerView)
        rv.layoutManager = LinearLayoutManager(requireContext())
        loadData(rv)
    }

    private fun loadData(rv: RecyclerView) {
        lifecycleScope.launch {
            val cats = repo.getCategories()
            val progress = repo.getBudgetProgress()
            rv.adapter = BudgetAdapter(cats, progress) { cat ->
                val input = EditText(requireContext())
                input.hint = "Monthly limit (₹)"
                input.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
                progress[cat.name]?.third?.let { input.setText(it.toString()) }

                AlertDialog.Builder(requireContext())
                    .setTitle("${cat.emoji} ${cat.name} Budget")
                    .setView(input)
                    .setPositiveButton("Save") { _, _ ->
                        val v = input.text.toString().toDoubleOrNull()
                        if (v != null && v > 0) {
                            lifecycleScope.launch { repo.setBudget(cat.name, v); loadData(rv) }
                        }
                    }
                    .setNegativeButton("Remove") { _, _ ->
                        lifecycleScope.launch { repo.deleteBudget(cat.name); loadData(rv) }
                    }
                    .setNeutralButton("Cancel", null)
                    .show()
            }
        }
    }

    override fun onResume() { super.onResume(); view?.findViewById<RecyclerView>(R.id.recyclerView)?.let { loadData(it) } }
}
