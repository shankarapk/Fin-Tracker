package com.example.fintracker.ui

import android.app.AlertDialog
import android.os.Bundle
import android.view.*
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.fintracker.R
import com.example.fintracker.data.FinanceRepository
import com.example.fintracker.data.SenderCategoryMap
import kotlinx.coroutines.launch

class LearningFragment : Fragment() {

    private lateinit var repo: FinanceRepository

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?) =
        i.inflate(R.layout.fragment_learning, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        repo = FinanceRepository(requireContext())
        val rv = v.findViewById<RecyclerView>(R.id.recyclerView)
        rv.layoutManager = LinearLayoutManager(requireContext())
        loadData(v, rv)
    }

    private fun loadData(root: View, rv: RecyclerView) {
        lifecycleScope.launch {
            val mappings = repo.getSenderMappings().sortedBy { it.sender }
            val tvCount = root.findViewById<TextView>(R.id.tvCount)
            val tvEmpty = root.findViewById<TextView>(R.id.tvEmpty)

            if (mappings.isEmpty()) {
                rv.visibility = View.GONE
                tvEmpty.visibility = View.VISIBLE
                tvCount.text = ""
            } else {
                rv.visibility = View.VISIBLE
                tvEmpty.visibility = View.GONE
                tvCount.text = "${mappings.size} learned merchant → category mappings"
                rv.adapter = LearningAdapter(mappings) { mapping ->
                    AlertDialog.Builder(requireContext())
                        .setTitle("Delete mapping?")
                        .setMessage("'${mapping.sender}' → '${mapping.category}'\n\nFuture transactions from this merchant will use keyword matching instead.")
                        .setPositiveButton("Delete") { _, _ ->
                            lifecycleScope.launch {
                                repo.deleteSenderMapping(mapping.sender)
                                loadData(root, rv)
                                Toast.makeText(requireContext(), "Mapping deleted", Toast.LENGTH_SHORT).show()
                            }
                        }
                        .setNegativeButton("Cancel", null).show()
                }
            }
        }
    }

    override fun onResume() { super.onResume(); view?.let { v -> v.findViewById<RecyclerView>(R.id.recyclerView)?.let { loadData(v, it) } } }
}

class LearningAdapter(
    private val items: List<SenderCategoryMap>,
    private val onDelete: (SenderCategoryMap) -> Unit
) : RecyclerView.Adapter<LearningAdapter.VH>() {

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val payee: TextView    = v.findViewById(R.id.tvPayee)
        val category: TextView = v.findViewById(R.id.tvCategory)
        val btnDelete: ImageButton = v.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_learned, p, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        val m = items[pos]
        // Capitalize each word of payee name
        h.payee.text = m.sender.split(" ").joinToString(" ") { word ->
            word.replaceFirstChar { it.uppercase() }
        }
        h.category.text = m.category
        h.btnDelete.setOnClickListener { onDelete(m) }
    }

    override fun getItemCount() = items.size
}
