package com.example.fintracker.ui

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.*
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.fintracker.R
import com.example.fintracker.data.CsvExporter
import com.example.fintracker.data.FinanceRepository
import com.example.fintracker.data.SenderCategoryMap
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.launch

class LearningFragment : Fragment() {

    private lateinit var repo: FinanceRepository

    private val pickBackup = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@registerForActivityResult
        lifecycleScope.launch {
            try {
                val csv = requireContext().contentResolver.openInputStream(uri)
                    ?.bufferedReader()?.use { it.readText() } ?: return@launch
                val backup = CsvExporter.parseBackup(csv)
                val msg = repo.restoreBackup(backup)
                val reapplied = repo.reapplyLearnings()
                AlertDialog.Builder(requireContext())
                    .setTitle("✅ Restore complete")
                    .setMessage("$msg\n\n$reapplied existing transactions re-categorised.")
                    .setPositiveButton("OK", null).show()
                refresh()
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Restore failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?) =
        i.inflate(R.layout.fragment_learning, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        repo = FinanceRepository(requireContext())
        v.findViewById<RecyclerView>(R.id.recyclerView).layoutManager = LinearLayoutManager(requireContext())

        v.findViewById<MaterialButton>(R.id.btnExportTxns).setOnClickListener { exportTransactions() }
        v.findViewById<MaterialButton>(R.id.btnExportReports).setOnClickListener { exportReports() }
        v.findViewById<MaterialButton>(R.id.btnBackup).setOnClickListener { backupSettings() }
        v.findViewById<MaterialButton>(R.id.btnRestore).setOnClickListener { confirmRestore() }

        refresh()
    }

    // ── Export actions ───────────────────────────────────────────────────────

    private fun exportTransactions() {
        lifecycleScope.launch {
            val txns = repo.getAllTransactions()
            if (txns.isEmpty()) {
                Toast.makeText(requireContext(), "No transactions to export", Toast.LENGTH_SHORT).show()
                return@launch
            }
            ExportHelper.shareCsv(requireContext(),
                "transactions_${ExportHelper.timestamp()}.csv",
                CsvExporter.transactions(txns))
        }
    }

    private fun exportReports() {
        val options = arrayOf(
            "🗂️ Category summary",
            "📅 Monthly summary (12 months)",
            "📆 Weekly summary (12 weeks)",
            "🚩 Flag breakdown",
            "🏪 Top merchants"
        )
        AlertDialog.Builder(requireContext())
            .setTitle("Export which report?")
            .setItems(options) { _, idx ->
                lifecycleScope.launch {
                    val ts = ExportHelper.timestamp()
                    val (name, content) = when (idx) {
                        0 -> "category_report_$ts.csv" to
                             CsvExporter.categoryReport(repo.categoryTotals(repo.getReportTransactions()))
                        1 -> "monthly_report_$ts.csv" to
                             CsvExporter.periodReport("Month", repo.getLastNMonthsTotals(12))
                        2 -> "weekly_report_$ts.csv" to
                             CsvExporter.periodReport("Week", repo.getLastNWeeksTotals(12))
                        3 -> "flag_report_$ts.csv" to
                             CsvExporter.flagReport(repo.getReportTransactions())
                        else -> "merchant_report_$ts.csv" to
                             CsvExporter.merchantReport(repo.getReportTransactions())
                    }
                    ExportHelper.shareCsv(requireContext(), name, content)
                }
            }.show()
    }

    private fun backupSettings() {
        lifecycleScope.launch {
            val content = CsvExporter.settingsBackup(
                repo.getSenderMappings(),
                repo.getCategories(),
                repo.getAllSubCategories(),
                repo.getBudgets()
            )
            ExportHelper.shareCsv(requireContext(),
                "fintracker_backup_${ExportHelper.timestamp()}.csv", content)
        }
    }

    private fun confirmRestore() {
        AlertDialog.Builder(requireContext())
            .setTitle("♻️ Restore settings")
            .setMessage("Pick a backup CSV. This merges learned mappings, categories, sub-categories " +
                        "and budgets into the app, then re-categorises existing transactions.\n\n" +
                        "Nothing is deleted — existing entries with the same name are overwritten.")
            .setPositiveButton("Choose file") { _, _ -> pickBackup.launch("*/*") }
            .setNegativeButton("Cancel", null).show()
    }

    // ── Learned mappings list ────────────────────────────────────────────────

    private fun refresh() {
        val root = view ?: return
        val rv = root.findViewById<RecyclerView>(R.id.recyclerView)
        lifecycleScope.launch {
            val mappings = repo.getSenderMappings().sortedBy { it.sender }
            val tvCount = root.findViewById<TextView>(R.id.tvCount)
            val tvEmpty = root.findViewById<TextView>(R.id.tvEmpty)

            if (mappings.isEmpty()) {
                rv.visibility = View.GONE
                tvEmpty.visibility = View.VISIBLE
                tvCount.text = ""
            } else {
                rv.visibility = View.VISIBLE
                tvEmpty.visibility = View.GONE
                tvCount.text = "${mappings.size} learned merchant → category mappings"
                rv.adapter = LearningAdapter(mappings) { mapping ->
                    AlertDialog.Builder(requireContext())
                        .setTitle("Delete mapping?")
                        .setMessage("'${mapping.sender}' → '${mapping.category}'")
                        .setPositiveButton("Delete") { _, _ ->
                            lifecycleScope.launch {
                                repo.deleteSenderMapping(mapping.sender)
                                refresh()
                                Toast.makeText(requireContext(), "Mapping deleted", Toast.LENGTH_SHORT).show()
                            }
                        }
                        .setNegativeButton("Cancel", null).show()
                }
            }
        }
    }

    override fun onResume() { super.onResume(); refresh() }
}

class LearningAdapter(
    private val items: List<SenderCategoryMap>,
    private val onDelete: (SenderCategoryMap) -> Unit
) : RecyclerView.Adapter<LearningAdapter.VH>() {

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val payee: TextView        = v.findViewById(R.id.tvPayee)
        val category: TextView     = v.findViewById(R.id.tvCategory)
        val btnDelete: ImageButton = v.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_learned, p, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        val m = items[pos]
        h.payee.text = m.sender.split(" ").joinToString(" ") { w -> w.replaceFirstChar { it.uppercase() } }
        h.category.text = m.category
        h.btnDelete.setOnClickListener { onDelete(m) }
    }

    override fun getItemCount() = items.size
}
