package com.example.fintracker.ui

import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.cardview.widget.CardView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.fintracker.R
import com.example.fintracker.data.FinanceRepository
import com.example.fintracker.data.TransactionEntity
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.launch

class ReportsFragment : Fragment() {

    private lateinit var repo: FinanceRepository
    private lateinit var content: LinearLayout

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?) =
        i.inflate(R.layout.fragment_reports, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        repo = FinanceRepository(requireContext())
        content = v.findViewById(R.id.reportContent)

        val tabs = v.findViewById<TabLayout>(R.id.tabLayout)
        tabs.addTab(tabs.newTab().setText("📅 Weekly"))
        tabs.addTab(tabs.newTab().setText("🗓️ Monthly"))
        tabs.addTab(tabs.newTab().setText("🏷️ Category"))

        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(t: TabLayout.Tab) { loadTab(t.position) }
            override fun onTabUnselected(t: TabLayout.Tab) {}
            override fun onTabReselected(t: TabLayout.Tab) {}
        })

        loadTab(0)
    }

    private fun loadTab(pos: Int) {
        content.removeAllViews()
        lifecycleScope.launch {
            when (pos) {
                0 -> buildWeeklyReport()
                1 -> buildMonthlyReport()
                2 -> buildCategoryReport()
            }
        }
    }

    // ─── WEEKLY ──────────────────────────────────────────────────────────────

    private suspend fun buildWeeklyReport() {
        val thisWeek = repo.getCurrentWeekTransactions()
        addSummaryCard("This Week", thisWeek)
        addSectionTitle("Last 8 Weeks — Spend Trend")
        val weeks = repo.getLastNWeeksTotals(8)
        addBarChart(weeks.map { it.first }, weeks.map { it.second.toFloat() }, weeks.map { it.third.toFloat() })
        addSectionTitle("This Week by Category")
        addCategoryBreakdown(thisWeek)
    }

    // ─── MONTHLY ─────────────────────────────────────────────────────────────

    private suspend fun buildMonthlyReport() {
        val thisMonth = repo.getCurrentMonthTransactions()
        addSummaryCard("This Month", thisMonth)
        addSectionTitle("Last 6 Months — Spend Trend")
        val months = repo.getLastNMonthsTotals(6)
        addBarChart(months.map { it.first }, months.map { it.second.toFloat() }, months.map { it.third.toFloat() })
        addSectionTitle("This Month by Category")
        addCategoryBreakdown(thisMonth)
        addSectionTitle("Spending Distribution")
        addPieChart(thisMonth)
    }

    // ─── CATEGORY ────────────────────────────────────────────────────────────

    private suspend fun buildCategoryReport() {
        val all = repo.getAllTransactions()
        val cats = repo.getCategories().associateBy { it.name }

        addSectionTitle("All Time — Top Categories")
        val totals = repo.categoryTotals(all)
        val grandTotal = totals.sumOf { it.second }

        val card = makeCard()
        totals.forEach { (name, amt) ->
            val cat = cats[name]
            val row = layoutInflater.inflate(R.layout.item_cat_row, card, false)
            row.findViewById<TextView>(R.id.tvEmoji).text = cat?.emoji ?: "📦"
            row.findViewById<TextView>(R.id.tvCatName).text = name
            val pct = if (grandTotal > 0) ((amt / grandTotal) * 100).toInt() else 0
            row.findViewById<TextView>(R.id.tvPct).text = "$pct%"
            row.findViewById<TextView>(R.id.tvAmt).text = "₹${"%,.0f".format(amt)}"
            val bar = row.findViewById<ProgressBar>(R.id.bar)
            bar.progress = pct
            bar.progressTintList = ColorStateList.valueOf(
                Color.parseColor(cat?.colorHex ?: "#9E9E9E")
            )
            card.addView(row)
            card.addView(divider())
        }
        content.addView(wrapCard(card))

        addSectionTitle("This Month by Category")
        addCategoryBreakdown(repo.getCurrentMonthTransactions())
    }

    // ─── HELPERS ─────────────────────────────────────────────────────────────

    private fun addSummaryCard(title: String, txns: List<TransactionEntity>) {
        val v = layoutInflater.inflate(R.layout.card_report_summary, content, false)
        v.findViewById<TextView>(R.id.tvCardTitle).text = title
        val debit = txns.filter { it.type == "DEBIT" }.sumOf { it.amount }
        val credit = txns.filter { it.type == "CREDIT" }.sumOf { it.amount }
        val net = credit - debit
        v.findViewById<TextView>(R.id.tvDebit).text = "₹${"%,.0f".format(debit)}"
        v.findViewById<TextView>(R.id.tvCredit).text = "₹${"%,.0f".format(credit)}"
        val netView = v.findViewById<TextView>(R.id.tvNet)
        netView.text = "${if (net >= 0) "+" else ""}₹${"%,.0f".format(net)}"
        netView.setTextColor(if (net >= 0) Color.parseColor("#2E7D32") else Color.parseColor("#C62828"))
        content.addView(v)
    }

    private fun addSectionTitle(text: String) {
        val tv = TextView(requireContext())
        tv.text = text
        tv.textSize = 15f
        tv.setTextColor(Color.parseColor("#1A1A2E"))
        tv.typeface = android.graphics.Typeface.DEFAULT_BOLD
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = 16; lp.bottomMargin = 6
        tv.layoutParams = lp
        content.addView(tv)
    }

    private fun addBarChart(labels: List<String>, debits: List<Float>, credits: List<Float>) {
        val cardWrapper = androidx.cardview.widget.CardView(requireContext())
        val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 280.dp)
        params.bottomMargin = 12.dp
        cardWrapper.layoutParams = params
        cardWrapper.radius = 14.dp.toFloat()
        cardWrapper.cardElevation = 3.dp.toFloat()
        cardWrapper.setCardBackgroundColor(Color.WHITE)

        val chart = BarChart(requireContext())
        chart.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        val debitSet = BarDataSet(debits.mapIndexed { i, v -> BarEntry(i.toFloat() - 0.2f, v) }, "Debit")
        debitSet.color = Color.parseColor("#EF5350")
        debitSet.valueTextSize = 0f

        val creditSet = BarDataSet(credits.mapIndexed { i, v -> BarEntry(i.toFloat() + 0.2f, v) }, "Credit")
        creditSet.color = Color.parseColor("#66BB6A")
        creditSet.valueTextSize = 0f

        val data = BarData(debitSet, creditSet)
        data.barWidth = 0.35f

        chart.data = data
        chart.description.isEnabled = false
        chart.xAxis.valueFormatter = IndexAxisValueFormatter(labels)
        chart.xAxis.position = XAxis.XAxisPosition.BOTTOM
        chart.xAxis.granularity = 1f
        chart.xAxis.textSize = 10f
        chart.axisRight.isEnabled = false
        chart.axisLeft.textSize = 9f
        chart.legend.textSize = 11f
        chart.setFitBars(true)
        chart.animateY(500)

        cardWrapper.addView(chart)
        content.addView(cardWrapper)
    }

    private fun addPieChart(txns: List<TransactionEntity>) {
        val bycat = txns.filter { it.type == "DEBIT" }
            .groupBy { it.category }
            .mapValues { (_, l) -> l.sumOf { it.amount } }
        if (bycat.isEmpty()) return

        val cardWrapper = androidx.cardview.widget.CardView(requireContext())
        val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 300.dp)
        params.bottomMargin = 12.dp
        cardWrapper.layoutParams = params
        cardWrapper.radius = 14.dp.toFloat()
        cardWrapper.cardElevation = 3.dp.toFloat()
        cardWrapper.setCardBackgroundColor(Color.WHITE)

        val chart = PieChart(requireContext())
        chart.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        val colors = listOf("#FF7043","#AB47BC","#5C6BC0","#26A69A","#EC407A",
            "#42A5F5","#66BB6A","#FF9800","#9E9E9E","#8D6E63").map { Color.parseColor(it) }

        val entries = bycat.entries.sortedByDescending { it.value }
            .map { PieEntry(it.value.toFloat(), it.key) }

        val ds = PieDataSet(entries, "")
        ds.colors = colors
        ds.valueTextSize = 10f
        ds.valueTextColor = Color.WHITE
        chart.data = PieData(ds)
        chart.description.isEnabled = false
        chart.setUsePercentValues(true)
        chart.legend.textSize = 10f
        chart.setEntryLabelColor(Color.DKGRAY)
        chart.animateY(500)

        cardWrapper.addView(chart)
        content.addView(cardWrapper)
    }

    private suspend fun addCategoryBreakdown(txns: List<TransactionEntity>) {
        val cats = repo.getCategories().associateBy { it.name }
        val totals = repo.categoryTotals(txns)
        val grandTotal = totals.sumOf { it.second }
        if (totals.isEmpty()) {
            val tv = TextView(requireContext()); tv.text = "No debit transactions"
            tv.textSize = 13f; tv.setTextColor(Color.GRAY)
            content.addView(tv); return
        }

        val card = makeCard()
        totals.forEach { (name, amt) ->
            val cat = cats[name]
            val row = layoutInflater.inflate(R.layout.item_cat_row, card, false)
            row.findViewById<TextView>(R.id.tvEmoji).text = cat?.emoji ?: "📦"
            row.findViewById<TextView>(R.id.tvCatName).text = name
            val pct = if (grandTotal > 0) ((amt / grandTotal) * 100).toInt() else 0
            row.findViewById<TextView>(R.id.tvPct).text = "$pct%"
            row.findViewById<TextView>(R.id.tvAmt).text = "₹${"%,.0f".format(amt)}"
            val bar = row.findViewById<ProgressBar>(R.id.bar)
            bar.progress = pct
            bar.progressTintList = ColorStateList.valueOf(Color.parseColor(cat?.colorHex ?: "#9E9E9E"))
            card.addView(row)
            card.addView(divider())
        }
        content.addView(wrapCard(card))
    }

    private fun makeCard(): LinearLayout {
        val ll = LinearLayout(requireContext())
        ll.orientation = LinearLayout.VERTICAL
        ll.setPadding(16.dp, 12.dp, 16.dp, 4.dp)
        return ll
    }

    private fun wrapCard(inner: LinearLayout): CardView {
        val cv = CardView(requireContext())
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = 12.dp
        cv.layoutParams = lp
        cv.radius = 14.dp.toFloat()
        cv.cardElevation = 3.dp.toFloat()
        cv.setCardBackgroundColor(Color.WHITE)
        cv.addView(inner)
        return cv
    }

    private fun divider(): View {
        val v = View(requireContext())
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
        lp.topMargin = 4; lp.bottomMargin = 4
        v.layoutParams = lp
        v.setBackgroundColor(Color.parseColor("#F5F5F5"))
        return v
    }

    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()
}
