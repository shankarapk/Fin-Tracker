package com.example.fintracker.ui
import android.app.AlertDialog
import android.content.res.ColorStateList; import android.graphics.Color; import android.os.Bundle; import android.view.*; import android.widget.*
import androidx.cardview.widget.CardView; import androidx.fragment.app.Fragment; import androidx.lifecycle.lifecycleScope
import com.example.fintracker.R; import com.example.fintracker.data.*
import com.github.mikephil.charting.charts.*; import com.github.mikephil.charting.components.XAxis; import com.github.mikephil.charting.data.*; import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.google.android.material.tabs.TabLayout; import kotlinx.coroutines.launch; import java.text.SimpleDateFormat; import java.util.*

class ReportsFragment : Fragment() {
    private lateinit var repo: FinanceRepository; private lateinit var content: LinearLayout
    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?) = i.inflate(R.layout.fragment_reports, c, false)
    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s); repo = FinanceRepository(requireContext()); content = v.findViewById(R.id.reportContent)
        val tabs = v.findViewById<TabLayout>(R.id.tabLayout)
        tabs.addTab(tabs.newTab().setText("📅 Weekly")); tabs.addTab(tabs.newTab().setText("🗓️ Monthly")); tabs.addTab(tabs.newTab().setText("🏷️ Category"))
        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(t: TabLayout.Tab) { loadTab(t.position) }; override fun onTabUnselected(t: TabLayout.Tab) {}; override fun onTabReselected(t: TabLayout.Tab) {}
        }); loadTab(0)
    }
    private fun loadTab(pos: Int) {
        content.removeAllViews()
        lifecycleScope.launch {
            addCutoffBanner(pos)
            when (pos) { 0 -> buildWeekly(); 1 -> buildMonthly(); 2 -> buildCategory() }
        }
    }

    /** Banner showing the report cutoff date, tap to change it. */
    private fun addCutoffBanner(currentTab: Int) {
        val fmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        val cv = CardView(requireContext())
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = 10.dp
        cv.layoutParams = lp
        cv.radius = 12f.dp; cv.cardElevation = 2f.dp
        cv.setCardBackgroundColor(Color.parseColor("#FFF8E1"))

        val row = LinearLayout(requireContext())
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = android.view.Gravity.CENTER_VERTICAL
        row.setPadding(14.dp, 10.dp, 14.dp, 10.dp)

        val tv = TextView(requireContext())
        tv.text = "\u23F1 Reports start from ${fmt.format(Date(repo.reportStart))}"
        tv.textSize = 12f
        tv.setTextColor(Color.parseColor("#E65100"))
        tv.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)

        val btn = TextView(requireContext())
        btn.text = "Change"
        btn.textSize = 12f
        btn.setTextColor(Color.parseColor("#1976D2"))
        btn.typeface = android.graphics.Typeface.DEFAULT_BOLD
        btn.setPadding(10.dp, 4.dp, 4.dp, 4.dp)
        btn.setOnClickListener { showCutoffPicker(currentTab) }

        val exportBtn = TextView(requireContext())
        exportBtn.text = "\u2B07 Export"
        exportBtn.textSize = 12f
        exportBtn.setTextColor(Color.parseColor("#2E7D32"))
        exportBtn.typeface = android.graphics.Typeface.DEFAULT_BOLD
        exportBtn.setPadding(12.dp, 4.dp, 4.dp, 4.dp)
        exportBtn.setOnClickListener { showExportMenu() }

        row.addView(tv); row.addView(btn); row.addView(exportBtn)
        cv.addView(row)
        content.addView(cv)
    }

    /** Pick what to export, build the CSV, then hand it to the Android share sheet. */
    private fun showExportMenu() {
        val options = arrayOf(
            "\uD83D\uDCCB Transactions",
            "\uD83D\uDDC3 All transactions (no date cutoff)",
            "\uD83C\uDFF7 Category report",
            "\uD83D\uDCC2 Sub-category report",
            "\uD83D\uDDD3 Monthly trend",
            "\uD83D\uDCC5 Weekly trend",
            "\uD83D\uDEA9 Flag report",
            "\uD83C\uDFEA Merchant report",
            "\uD83D\uDCBE Settings backup"
        )
        AlertDialog.Builder(requireContext())
            .setTitle("Export as CSV")
            .setItems(options) { _, idx ->
                lifecycleScope.launch {
                    val stamp = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())
                    val (csv, name) = when (idx) {
                        0 -> CsvExporter.transactions(repo.getReportTransactions()) to "transactions_$stamp.csv"
                        1 -> CsvExporter.transactions(repo.getAllTransactions()) to "all_transactions_$stamp.csv"
                        2 -> CsvExporter.categoryReport(repo.categoryTotals(repo.getReportTransactions())) to "category_report_$stamp.csv"
                        3 -> CsvExporter.subCategoryReport(repo.getReportTransactions()) to "subcategory_report_$stamp.csv"
                        4 -> CsvExporter.trendReport(repo.getLastNMonthsTotals(12), "Month") to "monthly_report_$stamp.csv"
                        5 -> CsvExporter.trendReport(repo.getLastNWeeksTotals(12), "Week") to "weekly_report_$stamp.csv"
                        6 -> CsvExporter.flagReport(repo.getReportTransactions()) to "flag_report_$stamp.csv"
                        7 -> CsvExporter.merchantReport(repo.getReportTransactions()) to "merchant_report_$stamp.csv"
                        else -> CsvExporter.backup(repo.getCategories(), repo.getAllSubCategories(),
                                    repo.getBudgets(), repo.getSenderMappings()) to "fintracker_backup_$stamp.csv"
                    }
                    shareCsv(csv, name)
                }
            }.show()
    }

    /** Write CSV to cache and open the share sheet (save to Drive, email, Files, etc). */
    private fun shareCsv(csv: String, fileName: String) {
        try {
            val dir = java.io.File(requireContext().cacheDir, "exports").apply { mkdirs() }
            val file = java.io.File(dir, fileName)
            file.writeText(csv)

            val uri = androidx.core.content.FileProvider.getUriForFile(
                requireContext(), "${requireContext().packageName}.fileprovider", file)

            val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                putExtra(android.content.Intent.EXTRA_SUBJECT, fileName)
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(android.content.Intent.createChooser(intent, "Export $fileName"))
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "Export failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showCutoffPicker(currentTab: Int) {
        val c = Calendar.getInstance()
        c.timeInMillis = repo.reportStart
        android.app.DatePickerDialog(requireContext(), { _, y, m, d ->
            val nc = Calendar.getInstance()
            nc.set(y, m, d, 0, 0, 0); nc.set(Calendar.MILLISECOND, 0)
            repo.setReportStart(nc.timeInMillis)
            loadTab(currentTab)
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }
    private suspend fun buildWeekly() {
        val cal = Calendar.getInstance(); cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY); cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        val wStart = cal.timeInMillis; cal.add(Calendar.DAY_OF_YEAR, 6); cal.set(Calendar.HOUR_OF_DAY, 23); cal.set(Calendar.MINUTE, 59); val wEnd = cal.timeInMillis
        val fmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        addHeaderCard("📅 Current Week", "${fmt.format(Date(wStart))} – ${fmt.format(Date(wEnd))}")
        val txns = repo.getCurrentWeekTransactions(); addSummaryCard(txns)
        addSectionTitle("This Week by Category"); addCategoryBreakdown(txns)
        addSectionTitle("Last 8 Weeks Trend"); val weeks = repo.getLastNWeeksTotals(8)
        addBarChart(weeks.map { it.first }, weeks.map { it.second.toFloat() }, weeks.map { it.third.toFloat() })
    }
    private suspend fun buildMonthly() {
        val year = Calendar.getInstance().get(Calendar.YEAR); val curMonth = Calendar.getInstance().get(Calendar.MONTH)
        val monthNames = listOf("January","February","March","April","May","June","July","August","September","October","November","December")
        addMonthDropdown(monthNames, curMonth) { m -> content.removeAllViews(); lifecycleScope.launch { addCutoffBanner(1); rebuildMonthly(m, monthNames, year) } }
        rebuildMonthly(curMonth, monthNames, year)
    }
    private suspend fun rebuildMonthly(sel: Int, names: List<String>, year: Int) {
        val cal = Calendar.getInstance(); cal.set(Calendar.YEAR, year); cal.set(Calendar.MONTH, sel); cal.set(Calendar.DAY_OF_MONTH, 1); cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        val start = cal.timeInMillis; cal.add(Calendar.MONTH, 1); val end = cal.timeInMillis
        val fmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()); val endCal = Calendar.getInstance().apply { timeInMillis = end; add(Calendar.DAY_OF_YEAR, -1) }
        addHeaderCard("🗓️ ${names[sel]} $year", "01 ${names[sel]} $year – ${fmt.format(Date(endCal.timeInMillis))}")
        val txns = repo.getTransactionsBetween(start, end); addSummaryCard(txns)
        addSectionTitle("${names[sel]} by Category"); addCategoryBreakdown(txns); addSectionTitle("Distribution"); addPieChart(txns)
        addMonthDropdown(names, sel) { m -> content.removeAllViews(); lifecycleScope.launch { addCutoffBanner(1); rebuildMonthly(m, names, year) } }
    }
    private suspend fun buildCategory() {
        val year = Calendar.getInstance().get(Calendar.YEAR); val cur = Calendar.getInstance().get(Calendar.MONTH)
        val names = listOf("January","February","March","April","May","June","July","August","September","October","November","December")
        addMonthDropdown(names, cur) { m -> content.removeAllViews(); lifecycleScope.launch { addCutoffBanner(2); rebuildCategory(m, names, year) } }
        rebuildCategory(cur, names, year)
    }
    private suspend fun rebuildCategory(sel: Int, names: List<String>, year: Int) {
        val cal = Calendar.getInstance(); cal.set(Calendar.YEAR, year); cal.set(Calendar.MONTH, sel); cal.set(Calendar.DAY_OF_MONTH, 1); cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        val start = cal.timeInMillis; cal.add(Calendar.MONTH, 1); val end = cal.timeInMillis
        val fmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()); val endCal = Calendar.getInstance().apply { timeInMillis = end; add(Calendar.DAY_OF_YEAR, -1) }
        addHeaderCard("🏷️ ${names[sel]} $year", "01 ${names[sel]} $year – ${fmt.format(Date(endCal.timeInMillis))}")
        val txns = repo.getTransactionsBetween(start, end); addAllCategories(txns); addPieChart(txns)
        addMonthDropdown(names, sel) { m -> content.removeAllViews(); lifecycleScope.launch { addCutoffBanner(2); rebuildCategory(m, names, year) } }
    }
    private fun addHeaderCard(title: String, range: String) {
        val cv = CardView(requireContext()); val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT); lp.bottomMargin = 10.dp; cv.layoutParams = lp; cv.radius = 14f.dp; cv.cardElevation = 4f.dp; cv.setCardBackgroundColor(Color.parseColor("#1976D2"))
        val inner = LinearLayout(requireContext()); inner.orientation = LinearLayout.VERTICAL; inner.setPadding(16.dp, 14.dp, 16.dp, 14.dp)
        val t1 = TextView(requireContext()); t1.text = title; t1.textSize = 17f; t1.setTextColor(Color.WHITE); t1.typeface = android.graphics.Typeface.DEFAULT_BOLD
        val t2 = TextView(requireContext()); t2.text = "📆 $range"; t2.textSize = 12f; t2.setTextColor(Color.parseColor("#BBDEFB")); t2.setPadding(0, 4.dp, 0, 0)
        inner.addView(t1); inner.addView(t2); cv.addView(inner); content.addView(cv)
    }
    private fun addMonthDropdown(names: List<String>, sel: Int, onSelect: (Int) -> Unit) {
        val cv = CardView(requireContext()); val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT); lp.bottomMargin = 12.dp; cv.layoutParams = lp; cv.radius = 12f.dp; cv.cardElevation = 2f.dp; cv.setCardBackgroundColor(Color.WHITE)
        val row = LinearLayout(requireContext()); row.orientation = LinearLayout.HORIZONTAL; row.gravity = android.view.Gravity.CENTER_VERTICAL; row.setPadding(16.dp, 10.dp, 16.dp, 10.dp)
        val lbl = TextView(requireContext()); lbl.text = "Select Month: "; lbl.textSize = 13f; lbl.setTextColor(Color.parseColor("#424242"))
        val sp = Spinner(requireContext()); sp.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, names); sp.setSelection(sel)
        sp.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        var first = true; sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { if (first) { first = false; return }; onSelect(pos) }; override fun onNothingSelected(p: AdapterView<*>?) {}
        }; row.addView(lbl); row.addView(sp); cv.addView(row); content.addView(cv)
    }
    private fun addSummaryCard(txns: List<TransactionEntity>) {
        val v = layoutInflater.inflate(R.layout.card_report_summary, content, false)
        v.findViewById<TextView>(R.id.tvCardTitle).visibility = View.GONE
        val debit = txns.filter { it.type=="DEBIT" }.sumOf { it.amount }; val credit = txns.filter { it.type=="CREDIT" }.sumOf { it.amount }; val net = credit - debit
        v.findViewById<TextView>(R.id.tvDebit).text = "₹${"%,.0f".format(debit)}"; v.findViewById<TextView>(R.id.tvCredit).text = "₹${"%,.0f".format(credit)}"
        val nv = v.findViewById<TextView>(R.id.tvNet); nv.text = "${if (net >= 0) "+" else ""}₹${"%,.0f".format(net)}"; nv.setTextColor(if (net >= 0) Color.parseColor("#2E7D32") else Color.parseColor("#C62828")); content.addView(v)
    }
    private fun addSectionTitle(text: String) {
        val tv = TextView(requireContext()); tv.text = text; tv.textSize = 14f; tv.setTextColor(Color.parseColor("#424242")); tv.typeface = android.graphics.Typeface.DEFAULT_BOLD
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT); lp.topMargin = 14.dp; lp.bottomMargin = 6.dp; tv.layoutParams = lp; content.addView(tv)
    }
    private fun addBarChart(labels: List<String>, debits: List<Float>, credits: List<Float>) {
        val cv = CardView(requireContext()); val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 260.dp); lp.bottomMargin = 12.dp; cv.layoutParams = lp; cv.radius = 14f.dp; cv.cardElevation = 3f.dp; cv.setCardBackgroundColor(Color.WHITE)
        val chart = BarChart(requireContext()); chart.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        val ds = BarDataSet(debits.mapIndexed { i, v -> BarEntry(i.toFloat() - 0.2f, v) }, "Debit"); ds.color = Color.parseColor("#EF5350"); ds.valueTextSize = 0f
        val cs = BarDataSet(credits.mapIndexed { i, v -> BarEntry(i.toFloat() + 0.2f, v) }, "Credit"); cs.color = Color.parseColor("#66BB6A"); cs.valueTextSize = 0f
        val data = BarData(ds, cs); data.barWidth = 0.35f; chart.data = data; chart.description.isEnabled = false
        chart.xAxis.valueFormatter = IndexAxisValueFormatter(labels); chart.xAxis.position = XAxis.XAxisPosition.BOTTOM; chart.xAxis.granularity = 1f; chart.xAxis.textSize = 9f; chart.axisRight.isEnabled = false; chart.legend.textSize = 11f; chart.setFitBars(true); chart.animateY(500)
        cv.addView(chart); content.addView(cv)
    }
    private fun addPieChart(txns: List<TransactionEntity>) {
        val bycat = txns.filter { it.type=="DEBIT" }.groupBy { it.category }.mapValues { (_, l) -> l.sumOf { it.amount } }; if (bycat.isEmpty()) return
        val cv = CardView(requireContext()); val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 300.dp); lp.bottomMargin = 12.dp; cv.layoutParams = lp; cv.radius = 14f.dp; cv.cardElevation = 3f.dp; cv.setCardBackgroundColor(Color.WHITE)
        val chart = PieChart(requireContext()); chart.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        val colors = listOf("#FF7043","#AB47BC","#5C6BC0","#26A69A","#EC407A","#42A5F5","#66BB6A","#FF9800","#9E9E9E","#8D6E63").map { Color.parseColor(it) }
        val entries = bycat.entries.sortedByDescending { it.value }.map { PieEntry(it.value.toFloat(), it.key) }
        val ds = PieDataSet(entries, ""); ds.colors = colors; ds.valueTextSize = 10f; ds.valueTextColor = Color.WHITE
        chart.data = PieData(ds); chart.description.isEnabled = false; chart.setUsePercentValues(true); chart.legend.textSize = 10f; chart.setEntryLabelColor(Color.DKGRAY); chart.animateY(500)
        cv.addView(chart); content.addView(cv)
    }
    private suspend fun addCategoryBreakdown(txns: List<TransactionEntity>) {
        val cats = repo.getCategories().associateBy { it.name }; val totals = repo.categoryTotals(txns); val grand = totals.sumOf { it.second }
        if (totals.isEmpty()) { val tv = TextView(requireContext()); tv.text = "No debit transactions"; tv.textSize = 13f; tv.setTextColor(Color.GRAY); content.addView(tv); return }
        val card = LinearLayout(requireContext()); card.orientation = LinearLayout.VERTICAL; card.setPadding(16.dp, 12.dp, 16.dp, 4.dp)
        totals.forEach { (name, amt) ->
            val cat = cats[name]; val row = layoutInflater.inflate(R.layout.item_cat_row, card, false)
            row.findViewById<TextView>(R.id.tvEmoji).text = cat?.emoji ?: "📦"; row.findViewById<TextView>(R.id.tvCatName).text = name
            val pct = if (grand > 0) ((amt / grand) * 100).toInt() else 0; row.findViewById<TextView>(R.id.tvPct).text = "$pct%"; row.findViewById<TextView>(R.id.tvAmt).text = "₹${"%,.0f".format(amt)}"
            val bar = row.findViewById<ProgressBar>(R.id.bar); bar.progress = pct; bar.progressTintList = ColorStateList.valueOf(Color.parseColor(cat?.colorHex ?: "#9E9E9E"))
            card.addView(row)
        }
        val cv = CardView(requireContext()); val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT); lp.bottomMargin = 12.dp; cv.layoutParams = lp; cv.radius = 14f.dp; cv.cardElevation = 3f.dp; cv.setCardBackgroundColor(Color.WHITE); cv.addView(card); content.addView(cv)
    }
    private suspend fun addAllCategories(txns: List<TransactionEntity>) { addCategoryBreakdown(txns) }

    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()
    private val Float.dp get() = this * resources.displayMetrics.density
}
