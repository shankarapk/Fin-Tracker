package com.example.fintracker.ui

import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.cardview.widget.CardView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.fintracker.R
import com.example.fintracker.data.FinanceRepository
import com.example.fintracker.data.TransactionEntity
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class ReportsFragment : Fragment() {

    private lateinit var repo: FinanceRepository
    private lateinit var content: LinearLayout
    private var currentTab = 0

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?) =
        i.inflate(R.layout.fragment_reports, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        repo = FinanceRepository(requireContext())
        content = v.findViewById(R.id.reportContent)

        val tabs = v.findViewById<TabLayout>(R.id.tabLayout)
        tabs.addTab(tabs.newTab().setText("📅 Weekly"))
        tabs.addTab(tabs.newTab().setText("🗓️ Monthly"))
        tabs.addTab(tabs.newTab().setText("🏷️ Category"))

        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(t: TabLayout.Tab) { currentTab = t.position; loadTab(t.position) }
            override fun onTabUnselected(t: TabLayout.Tab) {}
            override fun onTabReselected(t: TabLayout.Tab) {}
        })

        loadTab(0)
    }

    private fun loadTab(pos: Int) {
        content.removeAllViews()
        lifecycleScope.launch {
            when (pos) {
                0 -> buildWeeklyReport()
                1 -> buildMonthlyReport()
                2 -> buildCategoryReport()
            }
        }
    }

    // ─── WEEKLY ──────────────────────────────────────────────────────────────

    private suspend fun buildWeeklyReport() {
        val cal = Calendar.getInstance()

        // Current week start (Monday) and end (Sunday)
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        val weekStart = cal.timeInMillis
        cal.add(Calendar.DAY_OF_YEAR, 6)
        cal.set(Calendar.HOUR_OF_DAY, 23); cal.set(Calendar.MINUTE, 59); cal.set(Calendar.SECOND, 59)
        val weekEnd = cal.timeInMillis

        val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        val dateRange = "${dateFmt.format(Date(weekStart))} – ${dateFmt.format(Date(weekEnd))}"

        // Header card with date range
        addHeaderCard("📅 Current Week", dateRange)

        val thisWeek = repo.getCurrentWeekTransactions()
        addSummaryCard(thisWeek)

        addSectionTitle("This Week by Category")
        addCategoryBreakdown(thisWeek)

        addSectionTitle("Last 8 Weeks — Spend Trend")
        val weeks = repo.getLastNWeeksTotals(8)
        addBarChart(weeks.map { it.first }, weeks.map { it.second.toFloat() }, weeks.map { it.third.toFloat() })
    }

    // ─── MONTHLY ─────────────────────────────────────────────────────────────

    private suspend fun buildMonthlyReport() {
        val currentYear = Calendar.getInstance().get(Calendar.YEAR)
        val currentMonth = Calendar.getInstance().get(Calendar.MONTH) // 0-based

        // Month dropdown
        val monthNames = listOf("January","February","March","April","May","June",
            "July","August","September","October","November","December")

        addMonthDropdown(monthNames, currentMonth) { selectedMonth ->
            content.removeAllViews()
            lifecycleScope.launch {
                val monthName = monthNames[selectedMonth]
                val cal = Calendar.getInstance()
                cal.set(Calendar.YEAR, currentYear)
                cal.set(Calendar.MONTH, selectedMonth)
                cal.set(Calendar.DAY_OF_MONTH, 1)
                cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
                val start = cal.timeInMillis
                cal.add(Calendar.MONTH, 1)
                val end = cal.timeInMillis

                val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
                val rangeEnd = Calendar.getInstance().apply {
                    timeInMillis = end; add(Calendar.DAY_OF_YEAR, -1)
                }
                val dateRange = "01 $monthName $currentYear – ${dateFmt.format(Date(rangeEnd.timeInMillis))}"

                addHeaderCard("🗓️ $monthName $currentYear", dateRange)
                val txns = repo.getTransactionsBetween(start, end)
                addSummaryCard(txns)

                addSectionTitle("$monthName by Category")
                addCategoryBreakdown(txns)

                addSectionTitle("Spending Distribution")
                addPieChart(txns)

                addMonthDropdown(monthNames, selectedMonth) { m ->
                    content.removeAllViews()
                    lifecycleScope.launch { rebuildMonthly(m, monthNames, currentYear) }
                }
            }
        }

        // Initial load for current month
        val cal = Calendar.getInstance()
        val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        val start = cal.timeInMillis
        cal.add(Calendar.MONTH, 1)
        val end = cal.timeInMillis
        val rangeEnd = Calendar.getInstance().apply { timeInMillis = end; add(Calendar.DAY_OF_YEAR, -1) }

        addHeaderCard("🗓️ ${monthNames[currentMonth]} $currentYear",
            "01 ${monthNames[currentMonth]} $currentYear – ${dateFmt.format(Date(rangeEnd.timeInMillis))}")

        val txns = repo.getCurrentMonthTransactions()
        addSummaryCard(txns)

        addSectionTitle("${monthNames[currentMonth]} by Category")
        addCategoryBreakdown(txns)

        addSectionTitle("Spending Distribution")
        addPieChart(txns)
    }

    private suspend fun rebuildMonthly(selectedMonth: Int, monthNames: List<String>, year: Int) {
        val cal = Calendar.getInstance()
        cal.set(Calendar.YEAR, year)
        cal.set(Calendar.MONTH, selectedMonth)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        val start = cal.timeInMillis
        cal.add(Calendar.MONTH, 1)
        val end = cal.timeInMillis
        val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        val rangeEnd = Calendar.getInstance().apply { timeInMillis = end; add(Calendar.DAY_OF_YEAR, -1) }
        val monthName = monthNames[selectedMonth]

        addHeaderCard("🗓️ $monthName $year",
            "01 $monthName $year – ${dateFmt.format(Date(rangeEnd.timeInMillis))}")

        val txns = repo.getTransactionsBetween(start, end)
        addSummaryCard(txns)
        addSectionTitle("$monthName by Category")
        addCategoryBreakdown(txns)
        addSectionTitle("Spending Distribution")
        addPieChart(txns)

        addMonthDropdown(monthNames, selectedMonth) { m ->
            content.removeAllViews()
            lifecycleScope.launch { rebuildMonthly(m, monthNames, year) }
        }
    }

    // ─── CATEGORY ────────────────────────────────────────────────────────────

    private suspend fun buildCategoryReport() {
        val currentYear = Calendar.getInstance().get(Calendar.YEAR)
        val currentMonth = Calendar.getInstance().get(Calendar.MONTH)
        val monthNames = listOf("January","February","March","April","May","June",
            "July","August","September","October","November","December")

        addMonthDropdown(monthNames, currentMonth) { selectedMonth ->
            content.removeAllViews()
            lifecycleScope.launch { rebuildCategory(selectedMonth, monthNames, currentYear) }
        }

        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        val start = cal.timeInMillis
        cal.add(Calendar.MONTH, 1)
        val end = cal.timeInMillis
        val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        val rangeEnd = Calendar.getInstance().apply { timeInMillis = end; add(Calendar.DAY_OF_YEAR, -1) }

        addHeaderCard("🏷️ ${monthNames[currentMonth]} $currentYear",
            "01 ${monthNames[currentMonth]} $currentYear – ${dateFmt.format(Date(rangeEnd.timeInMillis))}")

        val txns = repo.getCurrentMonthTransactions()
        addAllCategoryBreakdown(txns)
        addPieChart(txns)
    }

    private suspend fun rebuildCategory(selectedMonth: Int, monthNames: List<String>, year: Int) {
        val cal = Calendar.getInstance()
        cal.set(Calendar.YEAR, year)
        cal.set(Calendar.MONTH, selectedMonth)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        val start = cal.timeInMillis
        cal.add(Calendar.MONTH, 1)
        val end = cal.timeInMillis
        val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        val rangeEnd = Calendar.getInstance().apply { timeInMillis = end; add(Calendar.DAY_OF_YEAR, -1) }
        val monthName = monthNames[selectedMonth]

        addMonthDropdown(monthNames, selectedMonth) { m ->
            content.removeAllViews()
            lifecycleScope.launch { rebuildCategory(m, monthNames, year) }
        }

        addHeaderCard("🏷️ $monthName $year",
            "01 $monthName $year – ${dateFmt.format(Date(rangeEnd.timeInMillis))}")

        val txns = repo.getTransactionsBetween(start, end)
        addAllCategoryBreakdown(txns)
        addPieChart(txns)
    }

    // ─── UI HELPERS ──────────────────────────────────────────────────────────

    private fun addHeaderCard(title: String, dateRange: String) {
        val cv = CardView(requireContext())
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = 10.dp
        cv.layoutParams = lp
        cv.radius = 14.dp.toFloat()
        cv.cardElevation = 4.dp.toFloat()
        cv.setCardBackgroundColor(Color.parseColor("#1976D2"))

        val inner = LinearLayout(requireContext())
        inner.orientation = LinearLayout.VERTICAL
        inner.setPadding(16.dp, 14.dp, 16.dp, 14.dp)

        val tvTitle = TextView(requireContext())
        tvTitle.text = title
        tvTitle.textSize = 17f
        tvTitle.setTextColor(Color.WHITE)
        tvTitle.typeface = android.graphics.Typeface.DEFAULT_BOLD

        val tvRange = TextView(requireContext())
        tvRange.text = "📆 $dateRange"
        tvRange.textSize = 12f
        tvRange.setTextColor(Color.parseColor("#BBDEFB"))
        tvRange.setPadding(0, 4.dp, 0, 0)

        inner.addView(tvTitle)
        inner.addView(tvRange)
        cv.addView(inner)
        content.addView(cv)
    }

    private fun addMonthDropdown(monthNames: List<String>, selected: Int, onSelect: (Int) -> Unit) {
        val card = CardView(requireContext())
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = 12.dp
        card.layoutParams = lp
        card.radius = 12.dp.toFloat()
        card.cardElevation = 2.dp.toFloat()
        card.setCardBackgroundColor(Color.WHITE)

        val row = LinearLayout(requireContext())
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = android.view.Gravity.CENTER_VERTICAL
        row.setPadding(16.dp, 10.dp, 16.dp, 10.dp)

        val label = TextView(requireContext())
        label.text = "Select Month: "
        label.textSize = 13f
        label.setTextColor(Color.parseColor("#424242"))

        val spinner = Spinner(requireContext())
        val adapter = ArrayAdapter(requireContext(),
            android.R.layout.simple_spinner_dropdown_item, monthNames)
        spinner.adapter = adapter
        spinner.setSelection(selected)

        val spinnerLp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        spinner.layoutParams = spinnerLp

        var firstSelect = true
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (firstSelect) { firstSelect = false; return }
                onSelect(pos)
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        row.addView(label)
        row.addView(spinner)
        card.addView(row)
        content.addView(card)
    }

    private fun addSummaryCard(txns: List<TransactionEntity>) {
        val v = layoutInflater.inflate(R.layout.card_report_summary, content, false)
        v.findViewById<TextView>(R.id.tvCardTitle).visibility = View.GONE
        val debit = txns.filter { it.type == "DEBIT" }.sumOf { it.amount }
        val credit = txns.filter { it.type == "CREDIT" }.sumOf { it.amount }
        val net = credit - debit
        v.findViewById<TextView>(R.id.tvDebit).text = "₹${"%,.0f".format(debit)}"
        v.findViewById<TextView>(R.id.tvCredit).text = "₹${"%,.0f".format(credit)}"
        val netView = v.findViewById<TextView>(R.id.tvNet)
        netView.text = "${if (net >= 0) "+" else ""}₹${"%,.0f".format(net)}"
        netView.setTextColor(if (net >= 0) Color.parseColor("#2E7D32") else Color.parseColor("#C62828"))
        content.addView(v)
    }

    private fun addSectionTitle(text: String) {
        val tv = TextView(requireContext())
        tv.text = text
        tv.textSize = 14f
        tv.setTextColor(Color.parseColor("#424242"))
        tv.typeface = android.graphics.Typeface.DEFAULT_BOLD
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = 14.dp; lp.bottomMargin = 6.dp
        tv.layoutParams = lp
        content.addView(tv)
    }

    private fun addBarChart(labels: List<String>, debits: List<Float>, credits: List<Float>) {
        val cv = CardView(requireContext())
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 260.dp)
        lp.bottomMargin = 12.dp
        cv.layoutParams = lp
        cv.radius = 14.dp.toFloat()
        cv.cardElevation = 3.dp.toFloat()
        cv.setCardBackgroundColor(Color.WHITE)

        val chart = BarChart(requireContext())
        chart.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        val debitSet = BarDataSet(debits.mapIndexed { i, v -> BarEntry(i.toFloat() - 0.2f, v) }, "Debit")
        debitSet.color = Color.parseColor("#EF5350"); debitSet.valueTextSize = 0f

        val creditSet = BarDataSet(credits.mapIndexed { i, v -> BarEntry(i.toFloat() + 0.2f, v) }, "Credit")
        creditSet.color = Color.parseColor("#66BB6A"); creditSet.valueTextSize = 0f

        val data = BarData(debitSet, creditSet)
        data.barWidth = 0.35f
        chart.data = data
        chart.description.isEnabled = false
        chart.xAxis.valueFormatter = IndexAxisValueFormatter(labels)
        chart.xAxis.position = XAxis.XAxisPosition.BOTTOM
        chart.xAxis.granularity = 1f; chart.xAxis.textSize = 9f
        chart.axisRight.isEnabled = false
        chart.axisLeft.textSize = 9f
        chart.legend.textSize = 11f
        chart.setFitBars(true)
        chart.animateY(500)

        cv.addView(chart)
        content.addView(cv)
    }

    private fun addPieChart(txns: List<TransactionEntity>) {
        val bycat = txns.filter { it.type == "DEBIT" }
            .groupBy { it.category }.mapValues { (_, l) -> l.sumOf { it.amount } }
        if (bycat.isEmpty()) return

        val cv = CardView(requireContext())
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 300.dp)
        lp.bottomMargin = 12.dp
        cv.layoutParams = lp
        cv.radius = 14.dp.toFloat(); cv.cardElevation = 3.dp.toFloat()
        cv.setCardBackgroundColor(Color.WHITE)

        val chart = PieChart(requireContext())
        chart.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        val colors = listOf("#FF7043","#AB47BC","#5C6BC0","#26A69A","#EC407A",
            "#42A5F5","#66BB6A","#FF9800","#9E9E9E","#8D6E63").map { Color.parseColor(it) }
        val entries = bycat.entries.sortedByDescending { it.value }
            .map { PieEntry(it.value.toFloat(), it.key) }
        val ds = PieDataSet(entries, "")
        ds.colors = colors; ds.valueTextSize = 10f; ds.valueTextColor = Color.WHITE
        chart.data = PieData(ds)
        chart.description.isEnabled = false
        chart.setUsePercentValues(true)
        chart.legend.textSize = 10f
        chart.setEntryLabelColor(Color.DKGRAY)
        chart.animateY(500)

        cv.addView(chart)
        content.addView(cv)
    }

    private suspend fun addCategoryBreakdown(txns: List<TransactionEntity>) {
        val cats = repo.getCategories().associateBy { it.name }
        val totals = repo.categoryTotals(txns)
        val grand = totals.sumOf { it.second }
        if (totals.isEmpty()) {
            val tv = TextView(requireContext()); tv.text = "No debit transactions"
            tv.textSize = 13f; tv.setTextColor(Color.GRAY); content.addView(tv); return
        }
        val card = makeCard()
        totals.forEach { (name, amt) ->
            val cat = cats[name]
            val row = layoutInflater.inflate(R.layout.item_cat_row, card, false)
            row.findViewById<TextView>(R.id.tvEmoji).text = cat?.emoji ?: "📦"
            row.findViewById<TextView>(R.id.tvCatName).text = name
            val pct = if (grand > 0) ((amt / grand) * 100).toInt() else 0
            row.findViewById<TextView>(R.id.tvPct).text = "$pct%"
            row.findViewById<TextView>(R.id.tvAmt).text = "₹${"%,.0f".format(amt)}"
            val bar = row.findViewById<ProgressBar>(R.id.bar)
            bar.progress = pct
            bar.progressTintList = ColorStateList.valueOf(Color.parseColor(cat?.colorHex ?: "#9E9E9E"))
            card.addView(row); card.addView(divider())
        }
        content.addView(wrapCard(card))
    }

    private suspend fun addAllCategoryBreakdown(txns: List<TransactionEntity>) {
        val cats = repo.getCategories().associateBy { it.name }
        val totals = repo.categoryTotals(txns)
        val grand = totals.sumOf { it.second }

        if (totals.isEmpty()) {
            val tv = TextView(requireContext()); tv.text = "No transactions for this month"
            tv.textSize = 13f; tv.setTextColor(Color.GRAY); content.addView(tv); return
        }

        addSectionTitle("Spend by Category")
        val card = makeCard()
        totals.forEach { (name, amt) ->
            val cat = cats[name]
            val row = layoutInflater.inflate(R.layout.item_cat_row, card, false)
            row.findViewById<TextView>(R.id.tvEmoji).text = cat?.emoji ?: "📦"
            row.findViewById<TextView>(R.id.tvCatName).text = name
            val pct = if (grand > 0) ((amt / grand) * 100).toInt() else 0
            row.findViewById<TextView>(R.id.tvPct).text = "$pct%"
            row.findViewById<TextView>(R.id.tvAmt).text = "₹${"%,.0f".format(amt)}"
            val bar = row.findViewById<ProgressBar>(R.id.bar)
            bar.progress = pct
            bar.progressTintList = ColorStateList.valueOf(Color.parseColor(cat?.colorHex ?: "#9E9E9E"))
            card.addView(row); card.addView(divider())
        }
        content.addView(wrapCard(card))
    }

    private fun makeCard(): LinearLayout {
        val ll = LinearLayout(requireContext())
        ll.orientation = LinearLayout.VERTICAL
        ll.setPadding(16.dp, 12.dp, 16.dp, 4.dp)
        return ll
    }

    private fun wrapCard(inner: LinearLayout): CardView {
        val cv = CardView(requireContext())
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = 12.dp
        cv.layoutParams = lp; cv.radius = 14.dp.toFloat()
        cv.cardElevation = 3.dp.toFloat(); cv.setCardBackgroundColor(Color.WHITE)
        cv.addView(inner); return cv
    }

    private fun divider(): View {
        val v = View(requireContext())
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
        lp.topMargin = 4; lp.bottomMargin = 4
        v.layoutParams = lp; v.setBackgroundColor(Color.parseColor("#F5F5F5")); return v
    }

    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()
}
