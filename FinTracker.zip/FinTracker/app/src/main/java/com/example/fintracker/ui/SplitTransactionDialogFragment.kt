package com.example.fintracker.ui
import android.app.AlertDialog; import android.app.Dialog; import android.os.Bundle
import android.widget.*; import androidx.fragment.app.DialogFragment; import androidx.lifecycle.lifecycleScope
import com.example.fintracker.R; import com.example.fintracker.data.*
import com.google.android.material.button.MaterialButton; import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.launch

class SplitTransactionDialogFragment : DialogFragment() {
    companion object {
        fun newInstance(txn: TransactionEntity) = SplitTransactionDialogFragment().apply {
            arguments = Bundle().apply { putLong("id", txn.id); putDouble("amt", txn.amount); putString("desc", txn.rawMessage.take(60)) }
        }
    }
    private lateinit var repo: FinanceRepository; private lateinit var container: LinearLayout
    private lateinit var tvRemaining: TextView; private var totalAmount = 0.0; private var txnId = 0L
    private var categoryNames = listOf<String>(); private var categoryDisplay = listOf<String>()

    override fun onCreateDialog(s: Bundle?): Dialog {
        repo = FinanceRepository(requireContext()); txnId = arguments?.getLong("id") ?: 0L
        totalAmount = arguments?.getDouble("amt") ?: 0.0
        val view = layoutInflater.inflate(R.layout.dialog_split_transaction, null)
        container = view.findViewById(R.id.splitRowsContainer); tvRemaining = view.findViewById(R.id.tvRemaining)
        view.findViewById<TextView>(R.id.tvTotalAmount).text = "Total: ₹${"%,.2f".format(totalAmount)}\n${arguments?.getString("desc") ?: ""}"
        lifecycleScope.launch {
            val cats = repo.getCategories(); categoryNames = cats.map { it.name }; categoryDisplay = cats.map { "${it.emoji} ${it.name}" }
            val existing = repo.getSplitsForTransaction(txnId)
            if (existing.isNotEmpty()) existing.forEach { addRow(it.category, it.amount) } else addRow("", totalAmount)
            updateRemaining()
        }
        view.findViewById<MaterialButton>(R.id.btnAddSplitRow).setOnClickListener { addRow("", 0.0) }
        return AlertDialog.Builder(requireContext()).setTitle("✂️ Split Transaction").setView(view)
            .setPositiveButton("Save Splits") { _, _ -> saveSplits() }
            .setNegativeButton("Clear") { _, _ -> lifecycleScope.launch { repo.saveSplits(txnId, emptyList()); (parentFragment as? TransactionsFragment)?.loadList() } }
            .setNeutralButton("Cancel", null).create()
    }

    private fun addRow(selectedCat: String, amount: Double) {
        val row = layoutInflater.inflate(R.layout.item_split_row, container, false)
        val spinner = row.findViewById<Spinner>(R.id.spinnerCat)
        val etAmount = row.findViewById<TextInputEditText>(R.id.etSplitAmount)
        spinner.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, categoryDisplay)
        val idx = categoryNames.indexOf(selectedCat); if (idx >= 0) spinner.setSelection(idx)
        if (amount > 0) etAmount.setText("%.2f".format(amount))
        etAmount.setOnFocusChangeListener { _, _ -> updateRemaining() }
        row.findViewById<ImageButton>(R.id.btnRemoveRow).setOnClickListener { container.removeView(row); updateRemaining() }
        container.addView(row); updateRemaining()
    }

    private fun updateRemaining() {
        val used = getRows().sumOf { it.second }; val rem = totalAmount - used
        tvRemaining.text = "Remaining: ₹${"%,.2f".format(rem)}"
        tvRemaining.setTextColor(if (Math.abs(rem) < 0.01) android.graphics.Color.parseColor("#2E7D32") else android.graphics.Color.parseColor("#D32F2F"))
    }

    private fun getRows(): List<Pair<String, Double>> = (0 until container.childCount).map { i ->
        val row = container.getChildAt(i)
        (categoryNames.getOrNull(row.findViewById<Spinner>(R.id.spinnerCat).selectedItemPosition) ?: "Others") to
        (row.findViewById<TextInputEditText>(R.id.etSplitAmount).text?.toString()?.toDoubleOrNull() ?: 0.0)
    }

    private fun saveSplits() {
        val rows = getRows(); val total = rows.sumOf { it.second }
        if (Math.abs(total - totalAmount) > 0.5) { Toast.makeText(requireContext(), "Split total ₹${"%,.2f".format(total)} doesn't match ₹${"%,.2f".format(totalAmount)}", Toast.LENGTH_LONG).show(); return }
        lifecycleScope.launch {
            repo.saveSplits(txnId, rows.map { (cat, amt) -> SplitEntity(transactionId = txnId, category = cat, amount = amt) })
            (parentFragment as? TransactionsFragment)?.loadList()
            Toast.makeText(requireContext(), "✅ Splits saved!", Toast.LENGTH_SHORT).show()
        }
    }
}
