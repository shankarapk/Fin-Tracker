package com.example.fintracker.ui

import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.lifecycleScope
import com.example.fintracker.R
import com.example.fintracker.data.FinanceRepository
import com.example.fintracker.data.SplitEntity
import com.example.fintracker.data.TransactionEntity
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.launch

class SplitTransactionDialogFragment : DialogFragment() {

    companion object {
        private const val ARG_TXN_ID = "txn_id"
        private const val ARG_AMOUNT = "amount"
        private const val ARG_DESC = "desc"

        fun newInstance(txn: TransactionEntity): SplitTransactionDialogFragment {
            val f = SplitTransactionDialogFragment()
            f.arguments = Bundle().apply {
                putLong(ARG_TXN_ID, txn.id)
                putDouble(ARG_AMOUNT, txn.amount)
                putString(ARG_DESC, txn.rawMessage.take(60))
            }
            return f
        }
    }

    private lateinit var repo: FinanceRepository
    private lateinit var container: LinearLayout
    private lateinit var tvRemaining: TextView
    private var totalAmount = 0.0
    private var txnId = 0L
    private var categoryNames = listOf<String>()
    private var categoryDisplay = listOf<String>()

    override fun onCreateDialog(s: Bundle?): Dialog {
        repo = FinanceRepository(requireContext())
        txnId = arguments?.getLong(ARG_TXN_ID) ?: 0L
        totalAmount = arguments?.getDouble(ARG_AMOUNT) ?: 0.0
        val desc = arguments?.getString(ARG_DESC) ?: ""

        val view = layoutInflater.inflate(R.layout.dialog_split_transaction, null)
        container = view.findViewById(R.id.splitRowsContainer)
        tvRemaining = view.findViewById(R.id.tvRemaining)

        view.findViewById<TextView>(R.id.tvTotalAmount).text =
            "Total: ₹${"%,.2f".format(totalAmount)}\n$desc"

        lifecycleScope.launch {
            val cats = repo.getCategories()
            categoryNames = cats.map { it.name }
            categoryDisplay = cats.map { "${it.emoji} ${it.name}" }

            // Load existing splits if any
            val existing = repo.getSplitsForTransaction(txnId)
            if (existing.isNotEmpty()) {
                existing.forEach { addRow(it.category, it.amount) }
            } else {
                addRow("", totalAmount) // default: one row with full amount
            }
            updateRemaining()
        }

        view.findViewById<MaterialButton>(R.id.btnAddSplitRow).setOnClickListener {
            addRow("", 0.0)
        }

        return AlertDialog.Builder(requireContext())
            .setTitle("✂️ Split Transaction")
            .setView(view)
            .setPositiveButton("Save Splits") { _, _ -> saveSplits() }
            .setNegativeButton("Clear Splits") { _, _ ->
                lifecycleScope.launch {
                    repo.saveSplits(txnId, emptyList())
                    (parentFragment as? TransactionsFragment)?.loadList()
                    Toast.makeText(requireContext(), "Splits cleared", Toast.LENGTH_SHORT).show()
                }
            }
            .setNeutralButton("Cancel", null)
            .create()
    }

    private fun addRow(selectedCat: String, amount: Double) {
        val row = layoutInflater.inflate(R.layout.item_split_row, container, false)
        val spinner = row.findViewById<Spinner>(R.id.spinnerCat)
        val etAmount = row.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.etSplitAmount)
        val btnRemove = row.findViewById<ImageButton>(R.id.btnRemoveRow)

        spinner.adapter = ArrayAdapter(requireContext(),
            android.R.layout.simple_spinner_dropdown_item, categoryDisplay)

        val idx = categoryNames.indexOf(selectedCat)
        if (idx >= 0) spinner.setSelection(idx)
        if (amount > 0) etAmount.setText("%.2f".format(amount))

        etAmount.setOnFocusChangeListener { _, _ -> updateRemaining() }

        btnRemove.setOnClickListener {
            container.removeView(row)
            updateRemaining()
        }

        container.addView(row)
        updateRemaining()
    }

    private fun updateRemaining() {
        val used = getRows().sumOf { it.second }
        val remaining = totalAmount - used
        tvRemaining.text = "Remaining: ₹${"%,.2f".format(remaining)}"
        tvRemaining.setTextColor(
            if (Math.abs(remaining) < 0.01)
                android.graphics.Color.parseColor("#2E7D32")
            else
                android.graphics.Color.parseColor("#D32F2F")
        )
    }

    private fun getRows(): List<Pair<String, Double>> {
        val result = mutableListOf<Pair<String, Double>>()
        for (i in 0 until container.childCount) {
            val row = container.getChildAt(i)
            val spinner = row.findViewById<Spinner>(R.id.spinnerCat)
            val et = row.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.etSplitAmount)
            val cat = categoryNames.getOrNull(spinner.selectedItemPosition) ?: "Others"
            val amt = et.text?.toString()?.toDoubleOrNull() ?: 0.0
            result.add(cat to amt)
        }
        return result
    }

    private fun saveSplits() {
        val rows = getRows()
        val total = rows.sumOf { it.second }

        if (rows.isEmpty()) {
            Toast.makeText(requireContext(), "Add at least one split row", Toast.LENGTH_SHORT).show()
            return
        }
        if (Math.abs(total - totalAmount) > 0.5) {
            Toast.makeText(requireContext(),
                "Split total ₹${"%,.2f".format(total)} doesn't match ₹${"%,.2f".format(totalAmount)}",
                Toast.LENGTH_LONG).show()
            return
        }

        lifecycleScope.launch {
            val splits = rows.map { (cat, amt) ->
                SplitEntity(transactionId = txnId, category = cat, amount = amt)
            }
            repo.saveSplits(txnId, splits)
            (parentFragment as? TransactionsFragment)?.loadList()
            Toast.makeText(requireContext(), "✅ Splits saved!", Toast.LENGTH_SHORT).show()
        }
    }
}
