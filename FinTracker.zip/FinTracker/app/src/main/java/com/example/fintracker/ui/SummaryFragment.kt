package com.example.fintracker.ui

import android.graphics.Color
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.fintracker.R
import com.example.fintracker.data.FinanceRepository
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import kotlinx.coroutines.launch

class SummaryFragment : Fragment() {
    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?) =
        i.inflate(R.layout.fragment_summary, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        val repo = FinanceRepository(requireContext())
        lifecycleScope.launch {
            setupPie(v.findViewById(R.id.pieChart), repo)
            setupBar(v.findViewById(R.id.barChart), repo)
        }
    }

    private suspend fun setupPie(chart: PieChart, repo: FinanceRepository) {
        val txns = repo.getCurrentMonthTransactions().filter { it.type == "DEBIT" }
        val bycat = txns.groupBy { it.category }.mapValues { (_, l) -> l.sumOf { it.amount } }
        if (bycat.isEmpty()) return

        val colors = listOf("#FF7043","#AB47BC","#5C6BC0","#26A69A","#EC407A",
            "#42A5F5","#66BB6A","#FF9800","#9E9E9E","#8D6E63").map { Color.parseColor(it) }

        val entries = bycat.entries.sortedByDescending { it.value }
            .map { PieEntry(it.value.toFloat(), it.key) }

        val ds = PieDataSet(entries, "")
        ds.colors = colors
        ds.valueTextSize = 10f
        ds.valueTextColor = Color.WHITE

        chart.data = PieData(ds)
        chart.description.isEnabled = false
        chart.setUsePercentValues(true)
        chart.legend.textSize = 11f
        chart.setEntryLabelColor(Color.DKGRAY)
        chart.animateY(600)
        chart.invalidate()
    }

    private suspend fun setupBar(chart: BarChart, repo: FinanceRepository) {
        val monthly = repo.getLastNMonthsTotals(6)
        val entries = monthly.mapIndexed { i, t -> BarEntry(i.toFloat(), t.second.toFloat()) }
        val labels = monthly.map { it.first }

        val ds = BarDataSet(entries, "Debit")
        ds.color = Color.parseColor("#1976D2")
        ds.valueTextSize = 10f

        chart.data = BarData(ds)
        chart.description.isEnabled = false
        chart.legend.isEnabled = false
        chart.xAxis.valueFormatter = IndexAxisValueFormatter(labels)
        chart.xAxis.position = XAxis.XAxisPosition.BOTTOM
        chart.xAxis.granularity = 1f
        chart.axisRight.isEnabled = false
        chart.animateY(600)
        chart.invalidate()
    }
}
