package com.example.fintracker.ui
import android.app.AlertDialog
import android.graphics.*
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.fintracker.*
import com.example.fintracker.data.*
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.launch

class TransactionsFragment : Fragment() {
    private lateinit var repo: FinanceRepository
    private lateinit var rv: RecyclerView
    private lateinit var tvDebit: android.widget.TextView
    private lateinit var tvCredit: android.widget.TextView
    private lateinit var tvCount: android.widget.TextView
    private var adapter: TransactionAdapter? = null

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?) = i.inflate(R.layout.fragment_transactions, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        repo = FinanceRepository(requireContext())
        rv = v.findViewById(R.id.recyclerView)
        rv.layoutManager = LinearLayoutManager(requireContext())
        tvDebit = v.findViewById(R.id.tvTotalDebit)
        tvCredit = v.findViewById(R.id.tvTotalCredit)
        tvCount = v.findViewById(R.id.tvCount)
        v.findViewById<View>(R.id.btnScan).setOnClickListener { scanSms() }
        v.findViewById<FloatingActionButton>(R.id.fabAdd).setOnClickListener {
            AddTransactionDialogFragment().show(childFragmentManager, "add")
        }
        setupSwipeToDelete()
        loadList()
    }

    private fun setupSwipeToDelete() {
        val swipe = object : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {
            override fun onMove(rv: RecyclerView, vh: RecyclerView.ViewHolder, t: RecyclerView.ViewHolder) = false
            override fun onSwiped(vh: RecyclerView.ViewHolder, dir: Int) {
                val pos = vh.adapterPosition
                val txn = adapter?.items?.getOrNull(pos) ?: return
                confirmDelete(txn, pos)
            }
            override fun onChildDraw(c: Canvas, rv: RecyclerView, vh: RecyclerView.ViewHolder, dX: Float, dY: Float, state: Int, active: Boolean) {
                val item = vh.itemView
                val paint = Paint().apply { color = Color.parseColor("#D32F2F") }
                c.drawRect(item.right + dX, item.top.toFloat(), item.right.toFloat(), item.bottom.toFloat(), paint)
                if (dX < -80) {
                    val tp = Paint().apply { color = Color.WHITE; textSize = 38f; textAlign = Paint.Align.CENTER }
                    c.drawText("🗑", item.right - 60f, (item.top + item.bottom) / 2f + 14f, tp)
                }
                super.onChildDraw(c, rv, vh, dX, dY, state, active)
            }
        }
        ItemTouchHelper(swipe).attachToRecyclerView(rv)
    }

    private fun confirmDelete(txn: TransactionEntity, pos: Int) {
        AlertDialog.Builder(requireContext())
            .setTitle("Delete Transaction?")
            .setMessage("₹${"%,.2f".format(txn.amount)} — ${txn.category}\n\nThis cannot be undone.")
            .setPositiveButton("Delete") { _, _ ->
                lifecycleScope.launch {
                    repo.deleteTransaction(txn.id)
                    adapter?.removeAt(pos); updateSummary()
                    Toast.makeText(requireContext(), "Deleted", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel") { _, _ -> adapter?.notifyItemChanged(pos) }
            .setCancelable(false).show()
    }

    private fun showOptionsMenu(txn: TransactionEntity, pos: Int) {
        val currentFlag = txn.flag.ifEmpty { "None" }
        val options = arrayOf(
            "✂️ Split into categories",
            "🏷️ Change category / sub-category",
            "🚩 Set flag  (now: $currentFlag)",
            "🗑️ Delete transaction"
        )
        AlertDialog.Builder(requireContext())
            .setTitle("₹${"%,.2f".format(txn.amount)} — ${txn.sender}")
            .setItems(options) { _, idx ->
                when (idx) {
                    0 -> SplitTransactionDialogFragment.newInstance(txn).show(childFragmentManager, "split")
                    1 -> showCategorySubCategoryPicker(txn)
                    2 -> showFlagPicker(txn)
                    3 -> confirmDelete(txn, pos)
                }
            }.show()
    }

    private fun showFlagPicker(txn: TransactionEntity) {
        val flags = arrayOf(
            "💸 Spend — regular expense",
            "💰 Savings — money set aside",
            "📈 Investment — SIP/stocks/FD",
            "✅ Need — essential expense",
            "🛍️ Want — discretionary spend",
            "🔄 Transfer — own account",
            "❌ Clear flag"
        )
        val flagValues = listOf("SPEND", "SAVINGS", "INVESTMENT", "NEED", "WANT", "TRANSFER", "")
        AlertDialog.Builder(requireContext())
            .setTitle("Set Flag for this transaction")
            .setItems(flags) { _, idx ->
                lifecycleScope.launch {
                    repo.setFlag(txn.id, flagValues[idx])
                    loadList()
                }
            }.show()
    }

    private fun showCategorySubCategoryPicker(txn: TransactionEntity) {
        lifecycleScope.launch {
            val cats = repo.getCategories()
            val catNames = cats.map { "${it.emoji} ${it.name}" }.toTypedArray()
            AlertDialog.Builder(requireContext())
                .setTitle("Select Category")
                .setItems(catNames) { _, catIdx ->
                    val selectedCat = cats[catIdx]
                    lifecycleScope.launch {
                        val subCats = repo.getSubCategories(selectedCat.name)
                        if (subCats.isEmpty()) {
                            // No sub-categories — just update category
                            repo.updateCategory(txn.id, selectedCat.name)
                            loadList()
                        } else {
                            // Show sub-category picker
                            val subNames = (listOf("— None —") + subCats.map { "${it.emoji} ${it.name}" }).toTypedArray()
                            AlertDialog.Builder(requireContext())
                                .setTitle("Sub-category for ${selectedCat.name}")
                                .setItems(subNames) { _, subIdx ->
                                    val subCat = if (subIdx == 0) "" else subCats[subIdx - 1].name
                                    lifecycleScope.launch {
                                        repo.updateTransactionFull(txn.id, selectedCat.name, subCat, txn.type)
                                        loadList()
                                    }
                                }.show()
                        }
                    }
                }.show()
        }
    }

    fun scanSms() {
        val act = activity as? MainActivity ?: return
        if (!act.hasSmsPermission()) { act.requestSms(); return }
        lifecycleScope.launch {
            val added = repo.scanSms()
            Toast.makeText(requireContext(),
                if (added > 0) "Imported $added new transaction(s)" else "No new transactions", Toast.LENGTH_SHORT).show()
            loadList()
        }
    }

    fun loadList() {
        lifecycleScope.launch {
            val txns = repo.getAllTransactions().toMutableList()
            val splitIds = repo.getAllSplits().map { it.transactionId }.toSet()
            adapter = TransactionAdapter(txns, splitIds,
                onCategoryClick = { txn -> showCategorySubCategoryPicker(txn) },
                onLongPress = { txn, pos -> showOptionsMenu(txn, pos) }
            )
            rv.adapter = adapter
            updateSummary()
        }
    }

    private fun updateSummary() {
        val items = adapter?.items ?: return
        tvDebit.text = "₹${"%,.0f".format(items.filter { it.type=="DEBIT" }.sumOf { it.amount })}"
        tvCredit.text = "₹${"%,.0f".format(items.filter { it.type=="CREDIT" }.sumOf { it.amount })}"
        tvCount.text = "${items.size} transactions"
    }

    override fun onResume() { super.onResume(); loadList() }
}
