package com.example.fintracker.ui

import android.app.AlertDialog
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.fintracker.MainActivity
import com.example.fintracker.R
import com.example.fintracker.TransactionAdapter
import com.example.fintracker.data.FinanceRepository
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.launch

class TransactionsFragment : Fragment() {
    private lateinit var repo: FinanceRepository
    private lateinit var rv: RecyclerView
    private lateinit var tvDebit: android.widget.TextView
    private lateinit var tvCredit: android.widget.TextView
    private lateinit var tvCount: android.widget.TextView

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?) =
        i.inflate(R.layout.fragment_transactions, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        repo = FinanceRepository(requireContext())
        rv = v.findViewById(R.id.recyclerView)
        rv.layoutManager = LinearLayoutManager(requireContext())
        tvDebit = v.findViewById(R.id.tvTotalDebit)
        tvCredit = v.findViewById(R.id.tvTotalCredit)
        tvCount = v.findViewById(R.id.tvCount)

        v.findViewById<View>(R.id.btnScan).setOnClickListener { scanSms() }
        v.findViewById<FloatingActionButton>(R.id.fabAdd).setOnClickListener {
            AddTransactionDialogFragment().show(childFragmentManager, "add")
        }
        loadList()
    }

    fun scanSms() {
        val act = activity as? MainActivity ?: return
        if (!act.hasSmsPermission()) { act.requestSms(); return }
        lifecycleScope.launch {
            val added = repo.scanSms()
            Toast.makeText(requireContext(),
                if (added > 0) "Imported $added new transaction(s)" else "No new transactions found",
                Toast.LENGTH_SHORT).show()
            loadList()
        }
    }

    fun loadList() {
        lifecycleScope.launch {
            val txns = repo.getAllTransactions()
            val cats = repo.getCategories()
            rv.adapter = TransactionAdapter(txns) { txn ->
                // Show category picker dialog
                val names = cats.map { "${it.emoji} ${it.name}" }.toTypedArray()
                AlertDialog.Builder(requireContext())
                    .setTitle("Change Category")
                    .setItems(names) { _, idx ->
                        lifecycleScope.launch {
                            repo.updateCategory(txn.id, cats[idx].name)
                            loadList()
                        }
                    }.show()
            }
            val debit = txns.filter { it.type == "DEBIT" }.sumOf { it.amount }
            val credit = txns.filter { it.type == "CREDIT" }.sumOf { it.amount }
            tvDebit.text = "₹${"%,.0f".format(debit)}"
            tvCredit.text = "₹${"%,.0f".format(credit)}"
            tvCount.text = "${txns.size} transactions"
        }
    }

    override fun onResume() { super.onResume(); loadList() }
}
