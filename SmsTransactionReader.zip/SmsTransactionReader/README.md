# Finance Tracker (Android)

A personal finance tracker (Kotlin) that auto-imports bank/UPI SMS alerts,
categorizes spending, tracks budgets, and shows summary charts — **entirely
on-device, with no internet access at all.**

## Privacy guarantee

`AndroidManifest.xml` does **not** request the `INTERNET` permission. This
isn't just a policy — without that permission, Android blocks the app from
opening any network socket at the OS level. So even though this is true
today, it stays true even as the app grows, because the OS enforces it.
All data is stored locally in a Room (SQLite) database on the device.

## Features

- **Auto-import**: reads the SMS inbox and parses debit/credit amounts
  from bank/UPI alerts (`SmsParser.kt`).
- **Categorization**: keyword-based auto-categorization (Food, Shopping,
  Bills, Transport, Entertainment, Transfer, Salary/Income, Others) —
  editable via the keyword list in `AppDatabase.kt`.
- **Manual entries**: add cash transactions that don't come via SMS.
- **Summary**: pie chart of this month's spend by category, bar chart of
  the last 6 months' totals.
- **Budgets**: set a monthly limit per category; progress bar turns
  orange at 80% and red when over budget.

## Project structure

```
app/src/main/java/com/example/smsreader/
  MainActivity.kt              - bottom nav host
  SmsParser.kt                 - regex-based debit/credit/amount extraction
  Transaction.kt                - lightweight parse result
  TransactionAdapter.kt
  data/
    Entities.kt                 - Room entities (Transaction, Category, Budget)
    Daos.kt
    AppDatabase.kt               - DB + default categories
    Categorizer.kt               - keyword matching
    FinanceRepository.kt         - SMS scan, manual entry, summaries, budgets
  ui/
    TransactionsFragment.kt
    AddTransactionDialogFragment.kt
    SummaryFragment.kt           - charts (MPAndroidChart)
    BudgetsFragment.kt
    BudgetAdapter.kt
```

## How to get an installable APK (no computer needed)

This repo includes a GitHub Actions workflow (`.github/workflows/build.yml`)
that builds the APK in the cloud whenever you push the code — you only need
a phone browser.

1. Create a free GitHub account at github.com (if you don't have one).
2. Create a new repository (e.g. `finance-tracker`).
3. On the repo page: **Add file → Upload files**, upload everything from
   this project folder (or the zip, then use "Add file → Upload files" and
   drop the zip — GitHub will let you upload it, but for the Action to run
   it needs the actual files, not a zip, so prefer extracting first and
   uploading the folder contents via the GitHub mobile web upload screen).
4. Commit directly to the `main` branch.
5. Go to the **Actions** tab → you'll see "Build APK" running automatically.
   Wait for it to finish (a few minutes).
6. Open the finished run → under **Artifacts**, download
   `finance-tracker-debug-apk` (downloads as a .zip).
7. Open that zip with your phone's file manager app to extract `app-debug.apk`.
8. Tap the APK to install. Android will prompt you to allow installs from
   that app (Settings → allow this source) the first time — this is normal
   for any app installed outside the Play Store.

## Notes & limitations

- Bank SMS formats vary by bank; extend the keyword lists in
  `SmsParser.kt` / `Categorizer.kt` for ones it misses.
- Only reads the SMS **inbox**, not sent messages.
- Debug builds are unsigned/self-signed — fine for personal use on your
  own device.
