# SMS Transaction Reader (Android)

A minimal Android app (Kotlin) that reads SMS messages from the inbox and
identifies **debit** and **credit** amounts from bank/UPI alert texts.

## How it works

1. **Permission**: requests `READ_SMS` at runtime (Android 6+).
2. **Reading**: queries `content://sms/inbox` via `ContentResolver`.
3. **Parsing** (`SmsParser.kt`): for each message body, uses regex to:
   - find a currency amount (`Rs.`, `INR`, `₹` followed by a number)
   - classify it as **DEBIT** or **CREDIT** based on keywords
     (debited/spent/paid/withdrawn vs credited/received/deposited/refund)
   - optionally extract available balance and a partial account/card number
   - skip OTP messages and non-transactional texts
4. **Display**: shows a scrollable list (RecyclerView) with each
   transaction's sender, amount (colored red for debit, green for credit),
   date, balance, and original message text, plus a running total at the top.

## Project structure

```
app/src/main/java/com/example/smsreader/
  MainActivity.kt        - permission flow + SMS query + list binding
  SmsParser.kt            - regex-based debit/credit/amount extraction
  Transaction.kt          - data model
  TransactionAdapter.kt   - RecyclerView adapter
app/src/main/res/layout/
  activity_main.xml
  item_transaction.xml
```

## How to run

1. Open the `SmsTransactionReader` folder in Android Studio (Hedgehog or
   newer recommended).
2. Let Gradle sync (it will download the AndroidX/Material dependencies).
3. Run on a real device or an emulator that has SMS messages
   (emulators can receive test SMS via `adb emu sms send <number> <text>`,
   e.g. `adb emu sms send +911234567890 "Rs.500 debited from A/c XX1234 on 21-Jun-26. Avl Bal Rs.4,500.00"`).
4. Grant the SMS permission prompt; tap **Refresh** to (re)scan the inbox.

## Notes & limitations

- Bank SMS formats vary widely between banks and UPI apps. The regex
  patterns in `SmsParser.kt` cover common phrasing (debited/credited,
  Rs./INR/₹ amounts, "Avl Bal", "A/c XXxxxx") but you'll likely want to
  add bank-specific patterns over time — that's the main place to extend.
- This only reads the **inbox**, not sent messages.
- Google Play restricts `READ_SMS` for apps not in specific categories
  (default SMS handler, etc.). If you intend to publish this on the Play
  Store, review Google's [SMS/Call Log permissions policy](https://support.google.com/googleplay/android-developer/answer/9047303)
  — for personal/sideloaded use this isn't an issue.
- No data leaves the device; everything is parsed and stored locally in
  memory only (nothing is persisted or sent anywhere).
