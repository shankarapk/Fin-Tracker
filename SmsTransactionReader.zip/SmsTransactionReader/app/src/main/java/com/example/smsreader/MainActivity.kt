package com.example.smsreader

import android.Manifest
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.smsreader.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val transactions = mutableListOf<Transaction>()

    private val permissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            loadSmsTransactions()
        } else {
            Toast.makeText(
                this,
                "SMS permission is required to read transactions",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recyclerView.layoutManager = LinearLayoutManager(this)

        binding.btnRefresh.setOnClickListener { checkPermissionAndLoad() }

        checkPermissionAndLoad()
    }

    private fun checkPermissionAndLoad() {
        when {
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.READ_SMS
            ) == PackageManager.PERMISSION_GRANTED -> loadSmsTransactions()

            else -> permissionLauncher.launch(Manifest.permission.READ_SMS)
        }
    }

    private fun loadSmsTransactions() {
        transactions.clear()

        val uri: Uri = Uri.parse("content://sms/inbox")
        val projection = arrayOf("address", "body", "date")

        val cursor: Cursor? = contentResolver.query(
            uri, projection, null, null, "date DESC"
        )

        cursor?.use {
            val addressIdx = it.getColumnIndexOrThrow("address")
            val bodyIdx = it.getColumnIndexOrThrow("body")
            val dateIdx = it.getColumnIndexOrThrow("date")

            while (it.moveToNext()) {
                val sender = it.getString(addressIdx) ?: "Unknown"
                val body = it.getString(bodyIdx) ?: continue
                val date = it.getLong(dateIdx)

                val txn = SmsParser.parse(sender, body, date)
                if (txn != null) transactions.add(txn)
            }
        }

        binding.recyclerView.adapter = TransactionAdapter(transactions)
        updateSummary()
    }

    private fun updateSummary() {
        val totalDebit = transactions
            .filter { it.type == TransactionType.DEBIT }
            .sumOf { it.amount }
        val totalCredit = transactions
            .filter { it.type == TransactionType.CREDIT }
            .sumOf { it.amount }

        binding.tvSummary.text =
            "Found ${transactions.size} transactions\n" +
            "Total Debit: ₹${"%,.2f".format(totalDebit)}   " +
            "Total Credit: ₹${"%,.2f".format(totalCredit)}"
    }
}
