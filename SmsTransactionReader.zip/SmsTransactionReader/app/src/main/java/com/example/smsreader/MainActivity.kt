package com.example.smsreader

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.smsreader.ui.BudgetsFragment
import com.example.smsreader.ui.SummaryFragment
import com.example.smsreader.ui.TransactionsFragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    private val permissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            (supportFragmentManager.findFragmentById(R.id.fragmentContainer) as? TransactionsFragment)
                ?.scanSms()
        } else {
            Toast.makeText(this, "SMS permission is needed to auto-import transactions", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, TransactionsFragment())
                .commit()
        }

        findViewById<BottomNavigationView>(R.id.bottomNav).setOnItemSelectedListener { item ->
            val fragment = when (item.itemId) {
                R.id.nav_transactions -> TransactionsFragment()
                R.id.nav_summary -> SummaryFragment()
                R.id.nav_budgets -> BudgetsFragment()
                else -> TransactionsFragment()
            }
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .commit()
            true
        }

        requestSmsPermissionIfNeeded()
    }

    fun requestSmsPermissionIfNeeded() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(Manifest.permission.READ_SMS)
        }
    }

    fun hasSmsPermission(): Boolean = ContextCompat.checkSelfPermission(
        this, Manifest.permission.READ_SMS
    ) == PackageManager.PERMISSION_GRANTED
}
