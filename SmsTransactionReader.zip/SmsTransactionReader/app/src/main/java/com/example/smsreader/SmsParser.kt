package com.example.smsreader

import java.util.regex.Pattern

/**
 * Parses raw SMS bodies (mainly bank/payment-app alerts) and extracts
 * transaction type (debit/credit), amount, balance and account info.
 *
 * Bank SMS formats vary a lot, so this uses a set of common patterns
 * seen across Indian banks (SBI, HDFC, ICICI, Axis, Kotak, etc.) and
 * UPI apps. Add more patterns to KEYWORD lists / regexes as needed for
 * banks not covered.
 */
object SmsParser {

    // Words that indicate money leaving the account
    private val DEBIT_KEYWORDS = listOf(
        "debited", "debit", "spent", "paid", "withdrawn", "purchase of",
        "sent", "deducted"
    )

    // Words that indicate money entering the account
    private val CREDIT_KEYWORDS = listOf(
        "credited", "credit", "received", "deposited", "refund"
    )

    // Matches amounts like: Rs.1,234.50  INR 500  Rs 1200.00  ₹999
    private val AMOUNT_PATTERN = Pattern.compile(
        "(?:rs\\.?|inr|₹)\\s?([0-9][0-9,]*(?:\\.\\d{1,2})?)",
        Pattern.CASE_INSENSITIVE
    )

    // Matches "Avl Bal Rs.12,345.67" / "Avbl Bal: 5000" / "available balance is Rs 200"
    private val BALANCE_PATTERN = Pattern.compile(
        "(?:avl|available|avbl)\\.?\\s*bal(?:ance)?\\.?:?\\s*(?:rs\\.?|inr|₹)?\\s?([0-9][0-9,]*(?:\\.\\d{1,2})?)",
        Pattern.CASE_INSENSITIVE
    )

    // Matches account references like "A/c XX1234", "a/c no. 5678", "card ending 4321"
    private val ACCOUNT_PATTERN = Pattern.compile(
        "(?:a/?c|account|card)\\s*(?:no\\.?)?\\s*[:xX*]*\\s*([0-9]{3,6})",
        Pattern.CASE_INSENSITIVE
    )

    /**
     * Returns null if the message does not look like a transaction alert at all
     * (i.e. no currency amount was found).
     */
    fun parse(sender: String, body: String, date: Long): Transaction? {
        val amountMatcher = AMOUNT_PATTERN.matcher(body)
        if (!amountMatcher.find()) return null

        val amount = amountMatcher.group(1)?.replace(",", "")?.toDoubleOrNull() ?: return null

        val lowerBody = body.lowercase()
        val type = when {
            DEBIT_KEYWORDS.any { lowerBody.contains(it) } -> TransactionType.DEBIT
            CREDIT_KEYWORDS.any { lowerBody.contains(it) } -> TransactionType.CREDIT
            else -> TransactionType.UNKNOWN
        }

        // Skip messages that mention money but aren't actual transaction alerts
        // (OTPs, promos, balance-check requests, etc.)
        if (type == TransactionType.UNKNOWN && !looksLikeBankAlert(lowerBody)) return null
        if (lowerBody.contains("otp") || lowerBody.contains("one time password")) return null

        val balanceMatcher = BALANCE_PATTERN.matcher(body)
        val balance = if (balanceMatcher.find()) {
            balanceMatcher.group(1)?.replace(",", "")?.toDoubleOrNull()
        } else null

        val accountMatcher = ACCOUNT_PATTERN.matcher(body)
        val account = if (accountMatcher.find()) accountMatcher.group(1) else null

        return Transaction(
            sender = sender,
            date = date,
            type = type,
            amount = amount,
            balance = balance,
            account = account,
            rawMessage = body
        )
    }

    private fun looksLikeBankAlert(lowerBody: String): Boolean {
        val bankHints = listOf("a/c", "account", "txn", "transaction", "upi", "bal")
        return bankHints.any { lowerBody.contains(it) }
    }
}
