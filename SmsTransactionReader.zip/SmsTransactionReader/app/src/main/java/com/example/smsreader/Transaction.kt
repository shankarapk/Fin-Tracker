package com.example.smsreader

/**
 * Represents a single parsed transaction extracted from an SMS.
 */
data class Transaction(
    val sender: String,
    val date: Long,
    val type: TransactionType,
    val amount: Double,
    val balance: Double?,
    val account: String?,
    val rawMessage: String
)

enum class TransactionType {
    DEBIT, CREDIT, UNKNOWN
}
