package com.example.smsreader

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TransactionAdapter(private val items: List<Transaction>) :
    RecyclerView.Adapter<TransactionAdapter.ViewHolder>() {

    private val dateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val sender: TextView = view.findViewById(R.id.tvSender)
        val amount: TextView = view.findViewById(R.id.tvAmount)
        val date: TextView = view.findViewById(R.id.tvDate)
        val balance: TextView = view.findViewById(R.id.tvBalance)
        val message: TextView = view.findViewById(R.id.tvMessage)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_transaction, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val txn = items[position]
        holder.sender.text = txn.sender

        val sign = when (txn.type) {
            TransactionType.DEBIT -> "- "
            TransactionType.CREDIT -> "+ "
            TransactionType.UNKNOWN -> ""
        }
        holder.amount.text = "$sign₹${"%,.2f".format(txn.amount)}"
        holder.amount.setTextColor(
            when (txn.type) {
                TransactionType.DEBIT -> Color.parseColor("#D32F2F")
                TransactionType.CREDIT -> Color.parseColor("#388E3C")
                TransactionType.UNKNOWN -> Color.parseColor("#757575")
            }
        )

        holder.date.text = dateFormat.format(Date(txn.date))
        holder.balance.text = txn.balance?.let { "Bal: ₹${"%,.2f".format(it)}" } ?: ""
        holder.message.text = txn.rawMessage
    }

    override fun getItemCount(): Int = items.size
}
