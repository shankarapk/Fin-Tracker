package com.example.smsreader.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [TransactionEntity::class, CategoryEntity::class, BudgetEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun transactionDao(): TransactionDao
    abstract fun categoryDao(): CategoryDao
    abstract fun budgetDao(): BudgetDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        // name, keywords (comma-separated), color
        val DEFAULT_CATEGORIES = listOf(
            CategoryEntity("Food", "swiggy,zomato,restaurant,cafe,food,dine,eatery,bakery", "#FF7043"),
            CategoryEntity("Shopping", "amazon,flipkart,myntra,mall,store,retail,shop", "#AB47BC"),
            CategoryEntity("Bills & Utilities", "electricity,recharge,broadband,dth,gas,water bill,bill payment,postpaid", "#5C6BC0"),
            CategoryEntity("Transport", "uber,ola,fuel,petrol,diesel,metro,irctc,fastag,parking", "#26A69A"),
            CategoryEntity("Entertainment", "netflix,prime,hotstar,spotify,movie,bookmyshow,cinema", "#EC407A"),
            CategoryEntity("Transfer", "upi,neft,imps,rtgs,transfer,sent to,p2p", "#42A5F5"),
            CategoryEntity("Salary/Income", "salary,credited interest,refund,cashback,reversal", "#66BB6A"),
            CategoryEntity("Others", "", "#9E9E9E")
        )

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "finance_tracker.db"
                ).build()
                INSTANCE = instance

                CoroutineScope(Dispatchers.IO).launch {
                    if (instance.categoryDao().getAll().isEmpty()) {
                        instance.categoryDao().insertAll(DEFAULT_CATEGORIES)
                    }
                }
                instance
            }
        }
    }
}
