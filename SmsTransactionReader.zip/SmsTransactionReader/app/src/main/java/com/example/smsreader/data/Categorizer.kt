package com.example.smsreader.data

object Categorizer {

    /**
     * Picks the best-matching category for a transaction based on its
     * message text and sender, using each category's keyword list.
     * Falls back to "Uncategorized" if nothing matches.
     */
    fun categorize(text: String, sender: String, categories: List<CategoryEntity>): String {
        val haystack = (text + " " + sender).lowercase()
        for (cat in categories) {
            if (cat.keywords.isBlank()) continue
            val keywords = cat.keywords.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            if (keywords.any { haystack.contains(it) }) {
                return cat.name
            }
        }
        return "Uncategorized"
    }
}
