package com.example.smsreader.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sender: String,
    val date: Long,
    val type: String,          // DEBIT, CREDIT, UNKNOWN
    val amount: Double,
    val balance: Double?,
    val account: String?,
    val rawMessage: String,
    val category: String = "Uncategorized",
    val source: String = "SMS" // SMS or MANUAL
)

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey val name: String,
    val keywords: String,   // comma-separated lowercase keywords used for auto-categorization
    val colorHex: String
)

@Entity(tableName = "budgets")
data class BudgetEntity(
    @PrimaryKey val category: String,
    val monthlyLimit: Double
)
