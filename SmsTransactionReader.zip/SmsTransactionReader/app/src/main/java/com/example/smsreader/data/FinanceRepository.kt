package com.example.smsreader.data

import android.content.Context
import android.net.Uri
import com.example.smsreader.SmsParser
import java.util.Calendar

class FinanceRepository(context: Context) {

    private val db = AppDatabase.getInstance(context)
    private val appContext = context.applicationContext

    // ---------- Categories ----------

    suspend fun getCategories(): List<CategoryEntity> = db.categoryDao().getAll()

    suspend fun addOrUpdateCategory(name: String, keywords: String, colorHex: String) {
        db.categoryDao().insert(CategoryEntity(name, keywords, colorHex))
    }

    suspend fun deleteCategory(name: String) {
        db.categoryDao().delete(name)
        db.budgetDao().delete(name)
    }

    // ---------- SMS scanning ----------

    /** Reads the SMS inbox, parses new messages, categorizes and stores them. Returns count added. */
    suspend fun scanSms(): Int {
        val existingRaw = db.transactionDao().getAllSmsRawMessages().toHashSet()
        val categories = db.categoryDao().getAll()

        val uri = Uri.parse("content://sms/inbox")
        val projection = arrayOf("address", "body", "date")
        val cursor = appContext.contentResolver.query(uri, projection, null, null, "date DESC")

        val newEntities = mutableListOf<TransactionEntity>()
        cursor?.use {
            val addressIdx = it.getColumnIndexOrThrow("address")
            val bodyIdx = it.getColumnIndexOrThrow("body")
            val dateIdx = it.getColumnIndexOrThrow("date")

            while (it.moveToNext()) {
                val sender = it.getString(addressIdx) ?: "Unknown"
                val body = it.getString(bodyIdx) ?: continue
                if (body in existingRaw) continue // already imported

                val date = it.getLong(dateIdx)
                val parsed = SmsParser.parse(sender, body, date) ?: continue
                val category = Categorizer.categorize(body, sender, categories)

                newEntities.add(
                    TransactionEntity(
                        sender = parsed.sender,
                        date = parsed.date,
                        type = parsed.type.name,
                        amount = parsed.amount,
                        balance = parsed.balance,
                        account = parsed.account,
                        rawMessage = parsed.rawMessage,
                        category = category,
                        source = "SMS"
                    )
                )
            }
        }

        if (newEntities.isNotEmpty()) db.transactionDao().insertAll(newEntities)
        return newEntities.size
    }

    // ---------- Manual entries ----------

    suspend fun addManualTransaction(
        type: String,
        amount: Double,
        category: String,
        note: String,
        date: Long = System.currentTimeMillis()
    ) {
        db.transactionDao().insert(
            TransactionEntity(
                sender = "Manual",
                date = date,
                type = type,
                amount = amount,
                balance = null,
                account = null,
                rawMessage = note,
                category = category,
                source = "MANUAL"
            )
        )
    }

    suspend fun updateCategory(id: Long, category: String) {
        db.transactionDao().setCategory(id, category)
    }

    // ---------- Queries ----------

    suspend fun getAllTransactions(): List<TransactionEntity> = db.transactionDao().getAll()

    suspend fun getCurrentMonthTransactions(): List<TransactionEntity> {
        val (start, end) = currentMonthRange()
        return db.transactionDao().getBetween(start, end)
    }

    suspend fun getLastNMonthsTotals(n: Int): List<Pair<String, Double>> {
        val cal = Calendar.getInstance()
        val results = mutableListOf<Pair<String, Double>>()
        for (i in (n - 1) downTo 0) {
            val c = cal.clone() as Calendar
            c.add(Calendar.MONTH, -i)
            c.set(Calendar.DAY_OF_MONTH, 1)
            c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0)
            val start = c.timeInMillis
            val label = android.text.format.DateFormat.format("MMM", c).toString()
            c.add(Calendar.MONTH, 1)
            val end = c.timeInMillis

            val txns = db.transactionDao().getBetween(start, end)
            val total = txns.filter { it.type == "DEBIT" }.sumOf { it.amount }
            results.add(label to total)
        }
        return results
    }

    // ---------- Budgets ----------

    suspend fun getBudgets(): List<BudgetEntity> = db.budgetDao().getAll()

    suspend fun setBudget(category: String, monthlyLimit: Double) {
        db.budgetDao().upsert(BudgetEntity(category, monthlyLimit))
    }

    suspend fun deleteBudget(category: String) = db.budgetDao().delete(category)

    /** Returns category -> (spent this month, budget limit or null) */
    suspend fun getBudgetProgress(): Map<String, Pair<Double, Double?>> {
        val monthTxns = getCurrentMonthTransactions().filter { it.type == "DEBIT" }
        val spendByCategory = monthTxns.groupBy { it.category }
            .mapValues { (_, list) -> list.sumOf { it.amount } }
        val budgets = getBudgets().associateBy { it.category }
        val categories = getCategories().map { it.name }

        val result = mutableMapOf<String, Pair<Double, Double?>>()
        categories.forEach { cat ->
            val spent = spendByCategory[cat] ?: 0.0
            val limit = budgets[cat]?.monthlyLimit
            if (spent > 0 || limit != null) result[cat] = spent to limit
        }
        return result
    }

    private fun currentMonthRange(): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        val start = cal.timeInMillis
        cal.add(Calendar.MONTH, 1)
        val end = cal.timeInMillis
        return start to end
    }
}
