package com.example.smsreader.ui

import android.app.Dialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.lifecycleScope
import com.example.smsreader.R
import com.example.smsreader.data.FinanceRepository
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.bottomsheet.BottomSheetDialog
import kotlinx.coroutines.launch

class AddTransactionDialogFragment : DialogFragment() {

    private lateinit var repo: FinanceRepository

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        repo = FinanceRepository(requireContext())
        val view = layoutInflater.inflate(R.layout.dialog_add_transaction, null)
        val dialog = BottomSheetDialog(requireContext())
        dialog.setContentView(view)

        val spinner = view.findViewById<Spinner>(R.id.spinnerCategory)
        val etAmount = view.findViewById<TextInputEditText>(R.id.etAmount)
        val etNote = view.findViewById<TextInputEditText>(R.id.etNote)
        val rbDebit = view.findViewById<android.widget.RadioButton>(R.id.rbDebit)

        lifecycleScope.launch {
            val categories = repo.getCategories().map { it.name }
            spinner.adapter = ArrayAdapter(
                requireContext(), android.R.layout.simple_spinner_dropdown_item, categories
            )
        }

        view.findViewById<android.widget.Button>(R.id.btnSave).setOnClickListener {
            val amount = etAmount.text?.toString()?.toDoubleOrNull()
            if (amount == null || amount <= 0) {
                Toast.makeText(requireContext(), "Enter a valid amount", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val type = if (rbDebit.isChecked) "DEBIT" else "CREDIT"
            val category = spinner.selectedItem as? String ?: "Uncategorized"
            val note = etNote.text?.toString()?.takeIf { it.isNotBlank() } ?: "Manual $type entry"

            lifecycleScope.launch {
                repo.addManualTransaction(type, amount, category, note)
                (parentFragment as? TransactionsFragment)?.loadList()
                dialog.dismiss()
            }
        }

        return dialog
    }
}
