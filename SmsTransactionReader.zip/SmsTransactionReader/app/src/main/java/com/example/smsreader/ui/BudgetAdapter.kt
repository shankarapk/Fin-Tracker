package com.example.smsreader.ui

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.smsreader.R
import com.example.smsreader.data.CategoryEntity

class BudgetAdapter(
    private val categories: List<CategoryEntity>,
    private val progress: Map<String, Pair<Double, Double?>>,
    private val onClick: (CategoryEntity) -> Unit
) : RecyclerView.Adapter<BudgetAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val category: TextView = view.findViewById(R.id.tvCategory)
        val amounts: TextView = view.findViewById(R.id.tvAmounts)
        val progressBar: ProgressBar = view.findViewById(R.id.progressBar)
        val alert: TextView = view.findViewById(R.id.tvAlert)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_budget, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val cat = categories[position]
        val (spent, limit) = progress[cat.name] ?: (0.0 to null)

        holder.category.text = cat.name

        if (limit != null) {
            val pct = ((spent / limit) * 100).toInt().coerceIn(0, 100)
            holder.progressBar.visibility = View.VISIBLE
            holder.progressBar.progress = pct
            holder.amounts.text = "₹${"%,.0f".format(spent)} / ₹${"%,.0f".format(limit)}"

            if (spent > limit) {
                holder.alert.visibility = View.VISIBLE
                holder.alert.text = "Over budget by ₹${"%,.0f".format(spent - limit)}"
                holder.progressBar.progressTintList =
                    android.content.res.ColorStateList.valueOf(Color.parseColor("#D32F2F"))
            } else if (pct >= 80) {
                holder.alert.visibility = View.VISIBLE
                holder.alert.setTextColor(Color.parseColor("#F57C00"))
                holder.alert.text = "Approaching limit (${pct}% used)"
                holder.progressBar.progressTintList =
                    android.content.res.ColorStateList.valueOf(Color.parseColor("#F57C00"))
            } else {
                holder.alert.visibility = View.GONE
                holder.progressBar.progressTintList =
                    android.content.res.ColorStateList.valueOf(Color.parseColor("#388E3C"))
            }
        } else {
            holder.progressBar.visibility = if (spent > 0) View.VISIBLE else View.GONE
            holder.progressBar.progress = 0
            holder.amounts.text = if (spent > 0) "₹${"%,.0f".format(spent)} spent • no limit set" else "No limit set"
            holder.alert.visibility = View.GONE
        }

        holder.itemView.setOnClickListener { onClick(cat) }
    }

    override fun getItemCount(): Int = categories.size
}
