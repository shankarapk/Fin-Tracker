package com.example.smsreader.ui

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.smsreader.R
import com.example.smsreader.data.CategoryEntity
import com.example.smsreader.data.FinanceRepository
import kotlinx.coroutines.launch

class BudgetsFragment : Fragment() {

    private lateinit var repo: FinanceRepository
    private lateinit var recyclerView: RecyclerView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_budgets, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        repo = FinanceRepository(requireContext())
        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        loadData()
    }

    private fun loadData() {
        lifecycleScope.launch {
            val categories = repo.getCategories()
            val progress = repo.getBudgetProgress()
            recyclerView.adapter = BudgetAdapter(categories, progress) { category ->
                showSetBudgetDialog(category, progress[category.name]?.second)
            }
        }
    }

    private fun showSetBudgetDialog(category: CategoryEntity, currentLimit: Double?) {
        val input = EditText(requireContext())
        input.hint = "Monthly limit (₹)"
        input.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        currentLimit?.let { input.setText(it.toString()) }

        AlertDialog.Builder(requireContext())
            .setTitle("Budget for ${category.name}")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val value = input.text.toString().toDoubleOrNull()
                if (value != null && value > 0) {
                    lifecycleScope.launch {
                        repo.setBudget(category.name, value)
                        loadData()
                    }
                }
            }
            .setNegativeButton("Remove limit") { _, _ ->
                lifecycleScope.launch {
                    repo.deleteBudget(category.name)
                    loadData()
                }
            }
            .setNeutralButton("Cancel", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        loadData()
    }
}
