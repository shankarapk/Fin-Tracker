package com.example.smsreader.ui

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.smsreader.R
import com.example.smsreader.data.FinanceRepository
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import kotlinx.coroutines.launch

class SummaryFragment : Fragment() {

    private lateinit var repo: FinanceRepository

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_summary, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        repo = FinanceRepository(requireContext())

        val pieChart = view.findViewById<PieChart>(R.id.pieChart)
        val barChart = view.findViewById<BarChart>(R.id.barChart)

        lifecycleScope.launch {
            loadPieChart(pieChart)
            loadBarChart(barChart)
        }
    }

    private suspend fun loadPieChart(chart: PieChart) {
        val txns = repo.getCurrentMonthTransactions().filter { it.type == "DEBIT" }
        val byCategory = txns.groupBy { it.category }.mapValues { (_, list) -> list.sumOf { it.amount } }

        val entries = byCategory.entries
            .sortedByDescending { it.value }
            .map { PieEntry(it.value.toFloat(), it.key) }

        if (entries.isEmpty()) {
            chart.clear()
            chart.invalidate()
            return
        }

        val colors = listOf(
            "#FF7043", "#AB47BC", "#5C6BC0", "#26A69A", "#EC407A",
            "#42A5F5", "#66BB6A", "#9E9E9E", "#FFCA28", "#8D6E63"
        ).map { Color.parseColor(it) }

        val dataSet = PieDataSet(entries, "")
        dataSet.colors = colors
        dataSet.valueTextSize = 11f

        chart.data = PieData(dataSet)
        chart.description.isEnabled = false
        chart.setUsePercentValues(true)
        chart.legend.textSize = 11f
        chart.animateY(500)
        chart.invalidate()
    }

    private suspend fun loadBarChart(chart: BarChart) {
        val monthly = repo.getLastNMonthsTotals(6)

        val entries = monthly.mapIndexed { index, pair -> BarEntry(index.toFloat(), pair.second.toFloat()) }
        val labels = monthly.map { it.first }

        val dataSet = BarDataSet(entries, "Spend")
        dataSet.color = Color.parseColor("#1976D2")
        dataSet.valueTextSize = 10f

        chart.data = BarData(dataSet)
        chart.description.isEnabled = false
        chart.legend.isEnabled = false
        chart.xAxis.valueFormatter = IndexAxisValueFormatter(labels)
        chart.xAxis.position = XAxis.XAxisPosition.BOTTOM
        chart.xAxis.granularity = 1f
        chart.axisRight.isEnabled = false
        chart.animateY(500)
        chart.invalidate()
    }
}
