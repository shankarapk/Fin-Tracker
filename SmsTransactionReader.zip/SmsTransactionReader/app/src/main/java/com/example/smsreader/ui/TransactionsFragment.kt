package com.example.smsreader.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.smsreader.MainActivity
import com.example.smsreader.R
import com.example.smsreader.TransactionAdapter
import com.example.smsreader.data.FinanceRepository
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.launch

class TransactionsFragment : Fragment() {

    private lateinit var repo: FinanceRepository
    private lateinit var recyclerView: RecyclerView
    private lateinit var summaryText: android.widget.TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_transactions, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        repo = FinanceRepository(requireContext())

        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        summaryText = view.findViewById(R.id.tvSummary)

        view.findViewById<View>(R.id.btnRefresh).setOnClickListener { scanSms() }
        view.findViewById<FloatingActionButton>(R.id.fabAdd).setOnClickListener {
            AddTransactionDialogFragment().show(childFragmentManager, "add_txn")
        }

        loadList()

        val activity = activity as? MainActivity
        if (activity?.hasSmsPermission() == true) {
            scanSms()
        }
    }

    fun scanSms() {
        val activity = activity as? MainActivity ?: return
        if (!activity.hasSmsPermission()) {
            activity.requestSmsPermissionIfNeeded()
            return
        }
        lifecycleScope.launch {
            val added = repo.scanSms()
            if (added > 0) Toast.makeText(requireContext(), "Imported $added new transaction(s)", Toast.LENGTH_SHORT).show()
            loadList()
        }
    }

    fun loadList() {
        lifecycleScope.launch {
            val txns = repo.getAllTransactions()
            recyclerView.adapter = TransactionAdapter(txns)

            val debit = txns.filter { it.type == "DEBIT" }.sumOf { it.amount }
            val credit = txns.filter { it.type == "CREDIT" }.sumOf { it.amount }
            summaryText.text = "${txns.size} transactions  •  Debit: ₹${"%,.2f".format(debit)}  •  Credit: ₹${"%,.2f".format(credit)}"
        }
    }

    override fun onResume() {
        super.onResume()
        loadList()
    }
}
